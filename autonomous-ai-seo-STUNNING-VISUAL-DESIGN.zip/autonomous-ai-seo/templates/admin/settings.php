<?php
/**
 * Admin Settings Template
 *
 * @package Autonomous_AI_SEO
 * @since 2.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Get current tab
$current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'general';
?>

<div class="wrap aaiseo-settings">
    <h1 class="wp-heading-inline">
        <?php esc_html_e('AI SEO Pro Settings', 'autonomous-ai-seo'); ?>
    </h1>
    
    <nav class="nav-tab-wrapper wp-clearfix">
        <a href="<?php echo esc_url(admin_url('admin.php?page=aaiseo-settings&tab=general')); ?>" 
           class="nav-tab <?php echo $current_tab === 'general' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e('General', 'autonomous-ai-seo'); ?>
        </a>
        <a href="<?php echo esc_url(admin_url('admin.php?page=aaiseo-settings&tab=api')); ?>" 
           class="nav-tab <?php echo $current_tab === 'api' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e('API Settings', 'autonomous-ai-seo'); ?>
        </a>
        <a href="<?php echo esc_url(admin_url('admin.php?page=aaiseo-settings&tab=social')); ?>" 
           class="nav-tab <?php echo $current_tab === 'social' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e('Social Media', 'autonomous-ai-seo'); ?>
        </a>
        <a href="<?php echo esc_url(admin_url('admin.php?page=aaiseo-settings&tab=technical')); ?>" 
           class="nav-tab <?php echo $current_tab === 'technical' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e('Technical', 'autonomous-ai-seo'); ?>
        </a>
        <a href="<?php echo esc_url(admin_url('admin.php?page=aaiseo-settings&tab=advanced')); ?>" 
           class="nav-tab <?php echo $current_tab === 'advanced' ? 'nav-tab-active' : ''; ?>">
            <?php esc_html_e('Advanced', 'autonomous-ai-seo'); ?>
        </a>
    </nav>

    <form method="post" action="options.php" class="aaiseo-settings-form">
        <?php
        // Output security fields
        settings_fields('aaiseo_settings_' . $current_tab);
        do_settings_sections('aaiseo_settings_' . $current_tab);
        ?>

        <div class="aaiseo-settings-content">
            <?php
            switch ($current_tab) {
                case 'general':
                    include_once 'settings-general.php';
                    break;
                case 'api':
                    include_once 'settings-api.php';
                    break;
                case 'social':
                    include_once 'settings-social.php';
                    break;
                case 'technical':
                    include_once 'settings-technical.php';
                    break;
                case 'advanced':
                    include_once 'settings-advanced.php';
                    break;
                default:
                    include_once 'settings-general.php';
                    break;
            }
            ?>
        </div>

        <div class="aaiseo-settings-footer">
            <?php submit_button(__('Save Settings', 'autonomous-ai-seo'), 'primary', 'submit', false); ?>
            <button type="button" class="button button-secondary" id="reset-settings">
                <?php esc_html_e('Reset to Defaults', 'autonomous-ai-seo'); ?>
            </button>
        </div>
    </form>
</div>

<script type="text/javascript">
jQuery(document).ready(function($) {
    // Initialize settings page
    AAISEO.Settings.init();
    
    // Handle reset button
    $('#reset-settings').on('click', function(e) {
        e.preventDefault();
        if (confirm('<?php esc_html_e('Are you sure you want to reset all settings to defaults?', 'autonomous-ai-seo'); ?>')) {
            AAISEO.Settings.resetToDefaults();
        }
    });
    
    // Auto-save settings
    $('.aaiseo-settings-form input, .aaiseo-settings-form select, .aaiseo-settings-form textarea').on('change', function() {
        AAISEO.Settings.autoSave();
    });
});
</script>

