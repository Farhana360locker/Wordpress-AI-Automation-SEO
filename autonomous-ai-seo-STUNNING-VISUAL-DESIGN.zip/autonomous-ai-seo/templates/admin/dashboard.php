<?php
/**
 * Admin Dashboard Template
 *
 * @package Autonomous_AI_SEO
 * @since 2.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap aaiseo-dashboard">
    <h1 class="wp-heading-inline">
        <?php esc_html_e('AI SEO Pro Dashboard', 'autonomous-ai-seo'); ?>
        <span class="title-count theme-count"><?php echo esc_html(get_option('aaiseo_version', '2.0.0')); ?></span>
    </h1>
    
    <div class="aaiseo-dashboard-grid">
        <!-- SEO Overview Card -->
        <div class="aaiseo-card aaiseo-overview-card">
            <div class="aaiseo-card-header">
                <h2><?php esc_html_e('SEO Overview', 'autonomous-ai-seo'); ?></h2>
                <div class="aaiseo-card-actions">
                    <button class="button button-secondary" id="refresh-overview">
                        <span class="dashicons dashicons-update"></span>
                        <?php esc_html_e('Refresh', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
            <div class="aaiseo-card-body">
                <div class="aaiseo-metrics-grid">
                    <div class="aaiseo-metric">
                        <div class="aaiseo-metric-value" id="overall-score">
                            <span class="score-circle" data-score="85">85</span>
                        </div>
                        <div class="aaiseo-metric-label"><?php esc_html_e('Overall SEO Score', 'autonomous-ai-seo'); ?></div>
                    </div>
                    <div class="aaiseo-metric">
                        <div class="aaiseo-metric-value" id="indexed-pages">
                            <span class="metric-number">1,247</span>
                        </div>
                        <div class="aaiseo-metric-label"><?php esc_html_e('Indexed Pages', 'autonomous-ai-seo'); ?></div>
                    </div>
                    <div class="aaiseo-metric">
                        <div class="aaiseo-metric-value" id="tracked-keywords">
                            <span class="metric-number">156</span>
                        </div>
                        <div class="aaiseo-metric-label"><?php esc_html_e('Tracked Keywords', 'autonomous-ai-seo'); ?></div>
                    </div>
                    <div class="aaiseo-metric">
                        <div class="aaiseo-metric-value" id="avg-position">
                            <span class="metric-number">12.4</span>
                        </div>
                        <div class="aaiseo-metric-label"><?php esc_html_e('Avg. Position', 'autonomous-ai-seo'); ?></div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Performance Chart Card -->
        <div class="aaiseo-card aaiseo-chart-card">
            <div class="aaiseo-card-header">
                <h2><?php esc_html_e('Performance Trends', 'autonomous-ai-seo'); ?></h2>
                <div class="aaiseo-card-actions">
                    <select id="chart-period">
                        <option value="7"><?php esc_html_e('Last 7 days', 'autonomous-ai-seo'); ?></option>
                        <option value="30" selected><?php esc_html_e('Last 30 days', 'autonomous-ai-seo'); ?></option>
                        <option value="90"><?php esc_html_e('Last 90 days', 'autonomous-ai-seo'); ?></option>
                    </select>
                </div>
            </div>
            <div class="aaiseo-card-body">
                <canvas id="performance-chart" width="400" height="200"></canvas>
            </div>
        </div>

        <!-- Recent Activity Card -->
        <div class="aaiseo-card aaiseo-activity-card">
            <div class="aaiseo-card-header">
                <h2><?php esc_html_e('Recent Activity', 'autonomous-ai-seo'); ?></h2>
                <div class="aaiseo-card-actions">
                    <a href="#" class="button button-secondary"><?php esc_html_e('View All', 'autonomous-ai-seo'); ?></a>
                </div>
            </div>
            <div class="aaiseo-card-body">
                <div class="aaiseo-activity-list" id="recent-activity">
                    <div class="aaiseo-activity-item">
                        <div class="activity-icon success">
                            <span class="dashicons dashicons-yes-alt"></span>
                        </div>
                        <div class="activity-content">
                            <div class="activity-title"><?php esc_html_e('SEO analysis completed', 'autonomous-ai-seo'); ?></div>
                            <div class="activity-meta"><?php esc_html_e('2 minutes ago', 'autonomous-ai-seo'); ?></div>
                        </div>
                    </div>
                    <div class="aaiseo-activity-item">
                        <div class="activity-icon info">
                            <span class="dashicons dashicons-chart-line"></span>
                        </div>
                        <div class="activity-content">
                            <div class="activity-title"><?php esc_html_e('Keyword rankings updated', 'autonomous-ai-seo'); ?></div>
                            <div class="activity-meta"><?php esc_html_e('15 minutes ago', 'autonomous-ai-seo'); ?></div>
                        </div>
                    </div>
                    <div class="aaiseo-activity-item">
                        <div class="activity-icon warning">
                            <span class="dashicons dashicons-warning"></span>
                        </div>
                        <div class="activity-content">
                            <div class="activity-title"><?php esc_html_e('Technical issue detected', 'autonomous-ai-seo'); ?></div>
                            <div class="activity-meta"><?php esc_html_e('1 hour ago', 'autonomous-ai-seo'); ?></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Quick Actions Card -->
        <div class="aaiseo-card aaiseo-actions-card">
            <div class="aaiseo-card-header">
                <h2><?php esc_html_e('Quick Actions', 'autonomous-ai-seo'); ?></h2>
            </div>
            <div class="aaiseo-card-body">
                <div class="aaiseo-quick-actions">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=aaiseo-content-optimizer')); ?>" class="aaiseo-action-button">
                        <span class="dashicons dashicons-edit"></span>
                        <span><?php esc_html_e('Optimize Content', 'autonomous-ai-seo'); ?></span>
                    </a>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=aaiseo-keyword-research')); ?>" class="aaiseo-action-button">
                        <span class="dashicons dashicons-search"></span>
                        <span><?php esc_html_e('Research Keywords', 'autonomous-ai-seo'); ?></span>
                    </a>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=aaiseo-technical-seo')); ?>" class="aaiseo-action-button">
                        <span class="dashicons dashicons-admin-tools"></span>
                        <span><?php esc_html_e('Technical Audit', 'autonomous-ai-seo'); ?></span>
                    </a>
                    <a href="<?php echo esc_url(admin_url('admin.php?page=aaiseo-competitor-analysis')); ?>" class="aaiseo-action-button">
                        <span class="dashicons dashicons-chart-bar"></span>
                        <span><?php esc_html_e('Analyze Competitors', 'autonomous-ai-seo'); ?></span>
                    </a>
                </div>
            </div>
        </div>

        <!-- Top Keywords Card -->
        <div class="aaiseo-card aaiseo-keywords-card">
            <div class="aaiseo-card-header">
                <h2><?php esc_html_e('Top Keywords', 'autonomous-ai-seo'); ?></h2>
                <div class="aaiseo-card-actions">
                    <a href="<?php echo esc_url(admin_url('admin.php?page=aaiseo-rank-tracker')); ?>" class="button button-secondary">
                        <?php esc_html_e('View All', 'autonomous-ai-seo'); ?>
                    </a>
                </div>
            </div>
            <div class="aaiseo-card-body">
                <div class="aaiseo-keywords-table">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th><?php esc_html_e('Keyword', 'autonomous-ai-seo'); ?></th>
                                <th><?php esc_html_e('Position', 'autonomous-ai-seo'); ?></th>
                                <th><?php esc_html_e('Change', 'autonomous-ai-seo'); ?></th>
                                <th><?php esc_html_e('Volume', 'autonomous-ai-seo'); ?></th>
                            </tr>
                        </thead>
                        <tbody id="top-keywords-list">
                            <tr>
                                <td><strong>wordpress seo</strong></td>
                                <td><span class="position-badge position-3">3</span></td>
                                <td><span class="change-badge change-up">+2</span></td>
                                <td>12,000</td>
                            </tr>
                            <tr>
                                <td><strong>seo optimization</strong></td>
                                <td><span class="position-badge position-7">7</span></td>
                                <td><span class="change-badge change-down">-1</span></td>
                                <td>8,500</td>
                            </tr>
                            <tr>
                                <td><strong>content marketing</strong></td>
                                <td><span class="position-badge position-12">12</span></td>
                                <td><span class="change-badge change-same">0</span></td>
                                <td>15,200</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- SEO Issues Card -->
        <div class="aaiseo-card aaiseo-issues-card">
            <div class="aaiseo-card-header">
                <h2><?php esc_html_e('SEO Issues', 'autonomous-ai-seo'); ?></h2>
                <div class="aaiseo-card-actions">
                    <button class="button button-primary" id="run-audit">
                        <?php esc_html_e('Run Audit', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
            <div class="aaiseo-card-body">
                <div class="aaiseo-issues-summary">
                    <div class="issue-count critical">
                        <span class="count">2</span>
                        <span class="label"><?php esc_html_e('Critical', 'autonomous-ai-seo'); ?></span>
                    </div>
                    <div class="issue-count warning">
                        <span class="count">5</span>
                        <span class="label"><?php esc_html_e('Warning', 'autonomous-ai-seo'); ?></span>
                    </div>
                    <div class="issue-count info">
                        <span class="count">12</span>
                        <span class="label"><?php esc_html_e('Info', 'autonomous-ai-seo'); ?></span>
                    </div>
                </div>
                <div class="aaiseo-issues-list" id="seo-issues-list">
                    <div class="issue-item critical">
                        <span class="issue-icon dashicons dashicons-warning"></span>
                        <span class="issue-text"><?php esc_html_e('Missing meta descriptions on 15 pages', 'autonomous-ai-seo'); ?></span>
                        <a href="#" class="issue-action"><?php esc_html_e('Fix', 'autonomous-ai-seo'); ?></a>
                    </div>
                    <div class="issue-item warning">
                        <span class="issue-icon dashicons dashicons-info"></span>
                        <span class="issue-text"><?php esc_html_e('Images without alt text found', 'autonomous-ai-seo'); ?></span>
                        <a href="#" class="issue-action"><?php esc_html_e('Review', 'autonomous-ai-seo'); ?></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript">
jQuery(document).ready(function($) {
    // Initialize dashboard
    AAISEO.Dashboard.init();
    
    // Load performance chart
    AAISEO.Dashboard.loadPerformanceChart();
    
    // Setup auto-refresh
    setInterval(function() {
        AAISEO.Dashboard.refreshMetrics();
    }, 300000); // Refresh every 5 minutes
});
</script>

