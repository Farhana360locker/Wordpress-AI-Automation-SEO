<?php
/**
 * Frontend Meta Tags Template
 *
 * @package Autonomous_AI_SEO
 * @since 2.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Get current post/page data
global $post;
$post_id = is_object($post) ? $post->ID : 0;

// Get SEO data
$seo_title = get_post_meta($post_id, '_aaiseo_title', true);
$seo_description = get_post_meta($post_id, '_aaiseo_description', true);
$focus_keyword = get_post_meta($post_id, '_aaiseo_focus_keyword', true);
$canonical_url = get_post_meta($post_id, '_aaiseo_canonical_url', true);
$robots_meta = get_post_meta($post_id, '_aaiseo_robots_meta', true);

// Fallback to defaults if empty
if (empty($seo_title)) {
    $seo_title = get_the_title($post_id);
}

if (empty($seo_description)) {
    $seo_description = wp_trim_words(get_the_excerpt($post_id), 25);
}

if (empty($canonical_url)) {
    $canonical_url = get_permalink($post_id);
}

// Get site settings
$site_name = get_bloginfo('name');
$separator = get_option('aaiseo_title_separator', '|');

// Build full title
$full_title = $seo_title;
if (!empty($site_name) && strpos($seo_title, $site_name) === false) {
    $full_title .= ' ' . $separator . ' ' . $site_name;
}
?>

<!-- AI SEO Pro Meta Tags -->
<title><?php echo esc_html($full_title); ?></title>
<meta name="description" content="<?php echo esc_attr($seo_description); ?>" />

<?php if (!empty($focus_keyword)): ?>
<meta name="keywords" content="<?php echo esc_attr($focus_keyword); ?>" />
<?php endif; ?>

<?php if (!empty($canonical_url)): ?>
<link rel="canonical" href="<?php echo esc_url($canonical_url); ?>" />
<?php endif; ?>

<?php if (!empty($robots_meta)): ?>
<meta name="robots" content="<?php echo esc_attr($robots_meta); ?>" />
<?php else: ?>
<meta name="robots" content="index, follow, max-snippet:-1, max-image-preview:large, max-video-preview:-1" />
<?php endif; ?>

<!-- Open Graph Meta Tags -->
<meta property="og:type" content="<?php echo is_single() ? 'article' : 'website'; ?>" />
<meta property="og:title" content="<?php echo esc_attr($seo_title); ?>" />
<meta property="og:description" content="<?php echo esc_attr($seo_description); ?>" />
<meta property="og:url" content="<?php echo esc_url($canonical_url); ?>" />
<meta property="og:site_name" content="<?php echo esc_attr($site_name); ?>" />

<?php if (has_post_thumbnail($post_id)): ?>
<meta property="og:image" content="<?php echo esc_url(get_the_post_thumbnail_url($post_id, 'large')); ?>" />
<meta property="og:image:width" content="1200" />
<meta property="og:image:height" content="630" />
<?php endif; ?>

<?php if (is_single()): ?>
<meta property="article:published_time" content="<?php echo esc_attr(get_the_date('c', $post_id)); ?>" />
<meta property="article:modified_time" content="<?php echo esc_attr(get_the_modified_date('c', $post_id)); ?>" />
<?php endif; ?>

<!-- Twitter Card Meta Tags -->
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="<?php echo esc_attr($seo_title); ?>" />
<meta name="twitter:description" content="<?php echo esc_attr($seo_description); ?>" />

<?php if (has_post_thumbnail($post_id)): ?>
<meta name="twitter:image" content="<?php echo esc_url(get_the_post_thumbnail_url($post_id, 'large')); ?>" />
<?php endif; ?>

<?php
// Get Twitter username from settings
$twitter_username = get_option('aaiseo_twitter_username', '');
if (!empty($twitter_username)):
?>
<meta name="twitter:site" content="@<?php echo esc_attr(ltrim($twitter_username, '@')); ?>" />
<meta name="twitter:creator" content="@<?php echo esc_attr(ltrim($twitter_username, '@')); ?>" />
<?php endif; ?>

<!-- Additional SEO Meta Tags -->
<meta name="generator" content="AI SEO Pro <?php echo esc_attr(AAISEO_VERSION); ?>" />

<?php if (is_single() && !empty($focus_keyword)): ?>
<meta name="news_keywords" content="<?php echo esc_attr($focus_keyword); ?>" />
<?php endif; ?>

<!-- Schema.org JSON-LD -->
<script type="application/ld+json">
{
    "@context": "https://schema.org",
    "@type": "<?php echo is_single() ? 'Article' : 'WebPage'; ?>",
    "headline": "<?php echo esc_js($seo_title); ?>",
    "description": "<?php echo esc_js($seo_description); ?>",
    "url": "<?php echo esc_url($canonical_url); ?>",
    <?php if (has_post_thumbnail($post_id)): ?>
    "image": {
        "@type": "ImageObject",
        "url": "<?php echo esc_url(get_the_post_thumbnail_url($post_id, 'large')); ?>",
        "width": 1200,
        "height": 630
    },
    <?php endif; ?>
    <?php if (is_single()): ?>
    "datePublished": "<?php echo esc_js(get_the_date('c', $post_id)); ?>",
    "dateModified": "<?php echo esc_js(get_the_modified_date('c', $post_id)); ?>",
    "author": {
        "@type": "Person",
        "name": "<?php echo esc_js(get_the_author_meta('display_name', get_post_field('post_author', $post_id))); ?>"
    },
    <?php endif; ?>
    "publisher": {
        "@type": "Organization",
        "name": "<?php echo esc_js($site_name); ?>",
        "url": "<?php echo esc_url(home_url()); ?>"
        <?php
        $logo_url = get_option('aaiseo_site_logo', '');
        if (!empty($logo_url)):
        ?>
        ,
        "logo": {
            "@type": "ImageObject",
            "url": "<?php echo esc_url($logo_url); ?>"
        }
        <?php endif; ?>
    }
}
</script>

<?php
// Additional custom meta tags from settings
$custom_meta = get_option('aaiseo_custom_meta_tags', '');
if (!empty($custom_meta)) {
    echo wp_kses($custom_meta, array(
        'meta' => array(
            'name' => array(),
            'property' => array(),
            'content' => array(),
            'http-equiv' => array()
        ),
        'link' => array(
            'rel' => array(),
            'href' => array(),
            'type' => array(),
            'sizes' => array()
        )
    ));
}
?>
<!-- /AI SEO Pro Meta Tags -->

