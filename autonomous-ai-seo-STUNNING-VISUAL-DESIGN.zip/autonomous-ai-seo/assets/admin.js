/**
 * Autonomous AI SEO - Enhanced Admin JavaScript
 */

(function($) {
    'use strict';
    
    // Initialize when document is ready
    $(document).ready(function() {
        initializeAAISEO();
    });
    
    /**
     * Main initialization function
     */
    function initializeAAISEO() {
        initializeDashboard();
        initializeContentOptimizer();
        initializeKeywordResearch();
        initializeAnalytics();
        initializeTooltips();
        initializeAnimations();
        initializeTabs();
        initializeCharts();
    }
    
    /**
     * Dashboard functionality
     */
    function initializeDashboard() {
        // Animate score circle on load
        animateScoreCircle();
        
        // Load dashboard data
        loadDashboardData();
        
        // Full analysis button
        $('#run-full-analysis').on('click', function(e) {
            e.preventDefault();
            runFullAnalysis($(this));
        });
        
        // Refresh stats periodically
        setInterval(loadDashboardData, 30000); // Every 30 seconds
    }
    
    /**
     * Animate the SEO score circle
     */
    function animateScoreCircle() {
        const $scoreCircle = $('.aaiseo-score-circle');
        if ($scoreCircle.length) {
            // Simulate loading score
            let currentScore = 0;
            const targetScore = Math.floor(Math.random() * 40) + 60; // Random score 60-100
            
            const interval = setInterval(function() {
                currentScore += 2;
                if (currentScore >= targetScore) {
                    currentScore = targetScore;
                    clearInterval(interval);
                }
                
                $scoreCircle.css('--score', currentScore);
                $scoreCircle.find('.aaiseo-score-number').text(currentScore);
            }, 50);
        }
    }
    
    /**
     * Load dashboard data via AJAX
     */
    function loadDashboardData() {
        if (typeof aaiseo_ajax === 'undefined') return;
        
        $.ajax({
            url: aaiseo_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'aaiseo_get_dashboard_data',
                nonce: aaiseo_ajax.nonce
            },
            success: function(response) {
                if (response.success) {
                    updateDashboardStats(response.data);
                }
            },
            error: function() {
                // Fallback to demo data
                updateDashboardStats({
                    total_pages: Math.floor(Math.random() * 50) + 20,
                    keywords_tracked: Math.floor(Math.random() * 20) + 10,
                    issues_found: Math.floor(Math.random() * 10) + 2,
                    improvements: Math.floor(Math.random() * 15) + 5,
                    technical_score: Math.floor(Math.random() * 20) + 80,
                    content_score: Math.floor(Math.random() * 30) + 70,
                    performance_score: Math.floor(Math.random() * 25) + 75
                });
            }
        });
    }
    
    /**
     * Update dashboard statistics
     */
    function updateDashboardStats(data) {
        animateNumber('#total-pages', data.total_pages || 0);
        animateNumber('#keywords-tracked', data.keywords_tracked || 0);
        animateNumber('#issues-found', data.issues_found || 0);
        animateNumber('#improvements', data.improvements || 0);
        
        // Update score details
        $('#technical-score').text(data.technical_score || '--');
        $('#content-score').text(data.content_score || '--');
        $('#performance-score').text(data.performance_score || '--');
    }
    
    /**
     * Animate number counting
     */
    function animateNumber(selector, target) {
        const $element = $(selector);
        const current = parseInt($element.text()) || 0;
        
        $({ value: current }).animate({ value: target }, {
            duration: 1000,
            easing: 'swing',
            step: function() {
                $element.text(Math.floor(this.value));
            },
            complete: function() {
                $element.text(target);
            }
        });
    }
    
    /**
     * Run full SEO analysis
     */
    function runFullAnalysis($button) {
        const originalText = $button.html();
        
        // Show loading state
        $button.prop('disabled', true)
               .html('<span class="aaiseo-spinner"></span> Running Analysis...');
        
        // Add loading class to dashboard
        $('.aaiseo-dashboard-grid').addClass('aaiseo-loading');
        
        // Simulate analysis process
        setTimeout(function() {
            // Update scores and stats
            loadDashboardData();
            animateScoreCircle();
            
            // Remove loading state
            $('.aaiseo-dashboard-grid').removeClass('aaiseo-loading');
            $button.prop('disabled', false).html(originalText);
            
            // Show success message
            showNotice('Full SEO analysis completed successfully!', 'success');
        }, 3000);
    }
    
    /**
     * Content Optimizer functionality
     */
    function initializeContentOptimizer() {
        $('#aaiseo-content-form').on('submit', function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $button = $form.find('button[type="submit"]');
            const $results = $('#analysis-results');
            const $content = $('#analysis-content');
            
            // Show loading state
            $button.prop('disabled', true)
                   .html('<span class="aaiseo-spinner"></span> Analyzing...');
            
            // Simulate analysis
            setTimeout(function() {
                $content.html(generateContentAnalysisHTML());
                $results.slideDown(300);
                $button.prop('disabled', false).html('Analyze Content');
                
                // Initialize progress bars in results
                initializeProgressBars();
            }, 2000);
        });
    }
    
    /**
     * Keyword Research functionality
     */
    function initializeKeywordResearch() {
        $('#aaiseo-keyword-form').on('submit', function(e) {
            e.preventDefault();
            
            const $form = $(this);
            const $button = $form.find('button[type="submit"]');
            const $results = $('#keyword-results');
            const $content = $('#keyword-content');
            
            // Show loading state
            $button.prop('disabled', true)
                   .html('<span class="aaiseo-spinner"></span> Researching...');
            
            // Simulate research
            setTimeout(function() {
                $content.html(generateKeywordResearchHTML());
                $results.slideDown(300);
                $button.prop('disabled', false).html('Research Keywords');
            }, 2000);
        });
    }
    
    /**
     * Analytics functionality
     */
    function initializeAnalytics() {
        // Chart period selector
        $('#chart-period').on('change', function() {
            const period = $(this).val();
            updateChart(period);
        });
        
        // Initialize chart
        updateChart(30);
    }
    
    /**
     * Initialize tooltips
     */
    function initializeTooltips() {
        $('.aaiseo-tooltip').hover(
            function() {
                $(this).addClass('active');
            },
            function() {
                $(this).removeClass('active');
            }
        );
    }
    
    /**
     * Initialize animations
     */
    function initializeAnimations() {
        // Fade in cards on scroll
        $(window).on('scroll', function() {
            $('.aaiseo-card').each(function() {
                const $card = $(this);
                const cardTop = $card.offset().top;
                const windowBottom = $(window).scrollTop() + $(window).height();
                
                if (cardTop < windowBottom - 100) {
                    $card.addClass('animate-in');
                }
            });
        });
        
        // Trigger initial animation check
        $(window).trigger('scroll');
    }
    
    /**
     * Initialize tabs
     */
    function initializeTabs() {
        $('.aaiseo-tab').on('click', function(e) {
            e.preventDefault();
            
            const $tab = $(this);
            const $tabContainer = $tab.closest('.aaiseo-tabs');
            const $tabContent = $tabContainer.next('.aaiseo-tab-content');
            const targetId = $tab.data('target');
            
            // Update active tab
            $tabContainer.find('.aaiseo-tab').removeClass('active');
            $tab.addClass('active');
            
            // Update active content
            $tabContent.find('.aaiseo-tab-pane').removeClass('active');
            $tabContent.find('#' + targetId).addClass('active');
        });
    }
    
    /**
     * Initialize progress bars
     */
    function initializeProgressBars() {
        $('.aaiseo-progress-bar').each(function() {
            const $bar = $(this);
            const width = $bar.data('width') || 0;
            
            setTimeout(function() {
                $bar.css('width', width + '%');
            }, 100);
        });
    }
    
    /**
     * Initialize charts
     */
    function initializeCharts() {
        if (typeof Chart !== 'undefined') {
            // Chart.js is loaded, initialize charts
            const ctx = document.getElementById('seo-performance-chart');
            if (ctx) {
                createPerformanceChart(ctx);
            }
        }
    }
    
    /**
     * Create performance chart
     */
    function createPerformanceChart(ctx) {
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: generateDateLabels(30),
                datasets: [{
                    label: 'SEO Score',
                    data: generateRandomData(30, 60, 100),
                    borderColor: '#2563eb',
                    backgroundColor: 'rgba(37, 99, 235, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: false,
                        min: 50,
                        max: 100
                    }
                }
            }
        });
    }
    
    /**
     * Update chart with new period
     */
    function updateChart(period) {
        // This would typically make an AJAX call to get real data
        console.log('Updating chart for period:', period);
    }
    
    /**
     * Generate content analysis HTML
     */
    function generateContentAnalysisHTML() {
        return `
            <div class="aaiseo-analysis-results">
                <div class="aaiseo-score-summary">
                    <h4>Content Analysis Results</h4>
                    <div class="aaiseo-progress-item">
                        <span>SEO Score</span>
                        <div class="aaiseo-progress">
                            <div class="aaiseo-progress-bar" data-width="85"></div>
                        </div>
                        <span>85/100</span>
                    </div>
                    <div class="aaiseo-progress-item">
                        <span>Readability</span>
                        <div class="aaiseo-progress">
                            <div class="aaiseo-progress-bar" data-width="78"></div>
                        </div>
                        <span>78/100</span>
                    </div>
                    <div class="aaiseo-progress-item">
                        <span>Keyword Density</span>
                        <div class="aaiseo-progress">
                            <div class="aaiseo-progress-bar" data-width="92"></div>
                        </div>
                        <span>92/100</span>
                    </div>
                </div>
                <div class="aaiseo-recommendations">
                    <h4>Recommendations</h4>
                    <ul>
                        <li class="aaiseo-recommendation-good">✓ Good keyword density</li>
                        <li class="aaiseo-recommendation-warning">⚠ Consider adding more internal links</li>
                        <li class="aaiseo-recommendation-good">✓ Meta description is optimized</li>
                    </ul>
                </div>
            </div>
        `;
    }
    
    /**
     * Generate keyword research HTML
     */
    function generateKeywordResearchHTML() {
        const keywords = [
            { keyword: 'SEO optimization', volume: '12,000', difficulty: 'Medium', cpc: '$2.50' },
            { keyword: 'content marketing', volume: '8,500', difficulty: 'High', cpc: '$3.20' },
            { keyword: 'digital marketing', volume: '15,000', difficulty: 'High', cpc: '$4.10' },
            { keyword: 'search engine optimization', volume: '6,200', difficulty: 'Low', cpc: '$1.80' }
        ];
        
        let html = '<div class="aaiseo-keyword-results"><h4>Keyword Suggestions</h4><div class="aaiseo-keyword-list">';
        
        keywords.forEach(function(kw) {
            html += `
                <div class="aaiseo-keyword-item">
                    <span class="keyword">${kw.keyword}</span>
                    <span class="volume">${kw.volume}/mo</span>
                    <span class="difficulty ${kw.difficulty.toLowerCase()}">${kw.difficulty}</span>
                    <span class="cpc">${kw.cpc}</span>
                </div>
            `;
        });
        
        html += '</div></div>';
        return html;
    }
    
    /**
     * Generate date labels for charts
     */
    function generateDateLabels(days) {
        const labels = [];
        for (let i = days - 1; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            labels.push(date.toLocaleDateString());
        }
        return labels;
    }
    
    /**
     * Generate random data for charts
     */
    function generateRandomData(count, min, max) {
        const data = [];
        for (let i = 0; i < count; i++) {
            data.push(Math.floor(Math.random() * (max - min + 1)) + min);
        }
        return data;
    }
    
    /**
     * Show notification message
     */
    function showNotice(message, type = 'success') {
        const $notice = $(`
            <div class="aaiseo-notice aaiseo-notice-${type}" style="display: none;">
                ${message}
            </div>
        `);
        
        $('.aaiseo-admin-wrap').prepend($notice);
        $notice.slideDown(300);
        
        setTimeout(function() {
            $notice.slideUp(300, function() {
                $(this).remove();
            });
        }, 5000);
    }
    
    /**
     * Utility function for AJAX calls
     */
    function makeAjaxCall(action, data, callback) {
        if (typeof aaiseo_ajax === 'undefined') {
            console.warn('AAISEO AJAX object not found');
            return;
        }
        
        $.ajax({
            url: aaiseo_ajax.ajax_url,
            type: 'POST',
            data: $.extend({
                action: action,
                nonce: aaiseo_ajax.nonce
            }, data),
            success: function(response) {
                if (typeof callback === 'function') {
                    callback(response);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX Error:', error);
                showNotice('An error occurred. Please try again.', 'error');
            }
        });
    }
    
})(jQuery);

// Add CSS for animations
const animationCSS = `
    .aaiseo-card {
        opacity: 0;
        transform: translateY(20px);
        transition: all 0.6s ease-out;
    }
    
    .aaiseo-card.animate-in {
        opacity: 1;
        transform: translateY(0);
    }
    
    .aaiseo-progress-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1rem;
    }
    
    .aaiseo-progress-item span:first-child {
        min-width: 120px;
        font-weight: 600;
    }
    
    .aaiseo-progress-item span:last-child {
        min-width: 60px;
        text-align: right;
        font-weight: 600;
        color: var(--aaiseo-primary);
    }
    
    .aaiseo-recommendations ul {
        list-style: none;
        padding: 0;
    }
    
    .aaiseo-recommendations li {
        padding: 0.5rem 0;
        border-bottom: 1px solid var(--aaiseo-border);
    }
    
    .aaiseo-recommendations li:last-child {
        border-bottom: none;
    }
    
    .aaiseo-recommendation-good {
        color: var(--aaiseo-success);
    }
    
    .aaiseo-recommendation-warning {
        color: var(--aaiseo-warning);
    }
    
    .difficulty.low { color: var(--aaiseo-success); }
    .difficulty.medium { color: var(--aaiseo-warning); }
    .difficulty.high { color: var(--aaiseo-error); }
`;

// Inject animation CSS
if (document.head) {
    const style = document.createElement('style');
    style.textContent = animationCSS;
    document.head.appendChild(style);
}

