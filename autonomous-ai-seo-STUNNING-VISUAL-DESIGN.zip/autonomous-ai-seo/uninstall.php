<?php
/**
 * Uninstall script for Autonomous AI SEO
 * 
 * This file is executed when the plugin is deleted from WordPress admin.
 * It cleans up all plugin data including database tables and options.
 */

// Prevent direct access
if (!defined('WP_UNINSTALL_PLUGIN')) {
    exit;
}

// Check if user has permission to delete plugins
if (!current_user_can('delete_plugins')) {
    exit;
}

/**
 * Clean up plugin data
 */
function aaiseo_cleanup_plugin_data() {
    global $wpdb;
    
    // Remove database tables
    $tables = array(
        $wpdb->prefix . 'aaiseo_audit_results',
        $wpdb->prefix . 'aaiseo_analytics',
        $wpdb->prefix . 'aaiseo_competitive',
        $wpdb->prefix . 'aaiseo_content_optimization',
        $wpdb->prefix . 'aaiseo_settings'
    );
    
    foreach ($tables as $table) {
        $wpdb->query("DROP TABLE IF EXISTS $table");
    }
    
    // Remove plugin options
    $options = array(
        'aaiseo_version',
        'aaiseo_db_version',
        'aaiseo_openai_api_key',
        'aaiseo_google_api_key',
        'aaiseo_auto_optimize',
        'aaiseo_technical_audit',
        'aaiseo_competitive_monitoring',
        'aaiseo_ai_suggestions',
        'aaiseo_performance_tracking',
        'aaiseo_auto_fix_technical',
        'aaiseo_auto_apply_optimizations',
        'aaiseo_structured_data_enabled',
        'aaiseo_create_robots_txt',
        'aaiseo_create_sitemap'
    );
    
    foreach ($options as $option) {
        delete_option($option);
    }
    
    // Remove post meta data
    $meta_keys = array(
        '_aaiseo_page_views',
        '_aaiseo_last_analyzed',
        '_aaiseo_optimized_title',
        '_aaiseo_optimized_meta_desc',
        '_aaiseo_seo_score',
        '_aaiseo_optimization_status'
    );
    
    foreach ($meta_keys as $meta_key) {
        delete_post_meta_by_key($meta_key);
    }
    
    // Clear scheduled events
    wp_clear_scheduled_hook('aaiseo_daily_audit');
    wp_clear_scheduled_hook('aaiseo_competitive_check');
    
    // Remove user meta data
    $user_meta_keys = array(
        'aaiseo_dashboard_preferences',
        'aaiseo_notification_settings'
    );
    
    foreach ($user_meta_keys as $meta_key) {
        delete_metadata('user', 0, $meta_key, '', true);
    }
    
    // Clean up transients
    $transients = array(
        'aaiseo_technical_audit_cache',
        'aaiseo_competitive_data_cache',
        'aaiseo_analytics_cache',
        'aaiseo_content_suggestions_cache'
    );
    
    foreach ($transients as $transient) {
        delete_transient($transient);
    }
    
    // Remove any uploaded files (if any)
    $upload_dir = wp_upload_dir();
    $aaiseo_dir = $upload_dir['basedir'] . '/aaiseo/';
    
    if (is_dir($aaiseo_dir)) {
        aaiseo_remove_directory($aaiseo_dir);
    }
    
    // Flush rewrite rules
    flush_rewrite_rules();
}

/**
 * Recursively remove directory and its contents
 */
function aaiseo_remove_directory($dir) {
    if (!is_dir($dir)) {
        return false;
    }
    
    $files = array_diff(scandir($dir), array('.', '..'));
    
    foreach ($files as $file) {
        $path = $dir . DIRECTORY_SEPARATOR . $file;
        if (is_dir($path)) {
            aaiseo_remove_directory($path);
        } else {
            unlink($path);
        }
    }
    
    return rmdir($dir);
}

/**
 * Log uninstall event (optional)
 */
function aaiseo_log_uninstall() {
    $log_data = array(
        'timestamp' => current_time('mysql'),
        'site_url' => get_site_url(),
        'wp_version' => get_bloginfo('version'),
        'php_version' => PHP_VERSION,
        'plugin_version' => '1.0.0'
    );
    
    // You could send this to an analytics endpoint if needed
    // wp_remote_post('https://your-analytics-endpoint.com/uninstall', array(
    //     'body' => json_encode($log_data),
    //     'headers' => array('Content-Type' => 'application/json')
    // ));
}

// Execute cleanup
try {
    aaiseo_cleanup_plugin_data();
    aaiseo_log_uninstall();
} catch (Exception $e) {
    // Log error but don't prevent uninstall
    error_log('AAISEO Uninstall Error: ' . $e->getMessage());
}

