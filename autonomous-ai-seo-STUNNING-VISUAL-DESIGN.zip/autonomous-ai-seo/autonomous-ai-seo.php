<?php
/**
 * Plugin Name: Autonomous AI SEO Pro
 * Plugin URI: https://autonomousaiseo.com
 * Description: Complete AI-powered SEO optimization plugin with real-time analysis, content optimization, competitor intelligence, and automated SEO improvements.
 * Version: 2.0.0
 * Author: Autonomous AI SEO Team
 * Author URI: https://autonomousaiseo.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: autonomous-ai-seo
 * Domain Path: /languages
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.4
 * Network: false
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('AAISEO_VERSION', '2.0.0');
define('AAISEO_PLUGIN_FILE', __FILE__);
define('AAISEO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('AAISEO_PLUGIN_URL', plugin_dir_url(__FILE__));
define('AAISEO_TABLE_PREFIX', 'aaiseo_');

/**
 * Load all required classes immediately
 */
function aaiseo_load_all_classes() {
    // Core classes
    require_once AAISEO_PLUGIN_DIR . 'includes/class-aaiseo-database.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/class-aaiseo-core.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/class-aaiseo-settings.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/class-aaiseo-seo-analyzer.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/class-aaiseo-content-optimizer.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/class-aaiseo-technical-seo.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/class-aaiseo-ai-engine.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/class-aaiseo-schema-generator.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/class-aaiseo-link-builder.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/class-aaiseo-performance-monitor.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/class-aaiseo-meta-boxes.php';
    
    // Admin classes (always load to prevent errors)
    require_once AAISEO_PLUGIN_DIR . 'includes/admin/class-aaiseo-admin.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/admin/class-aaiseo-dashboard.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/admin/class-aaiseo-keyword-research.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/admin/class-aaiseo-competitive-intelligence.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/admin/class-aaiseo-rank-tracker.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/admin/class-aaiseo-analytics.php';
    
    // API classes
    require_once AAISEO_PLUGIN_DIR . 'includes/api/class-aaiseo-api-manager.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/api/class-aaiseo-google-api.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/api/class-aaiseo-openai-api.php';
    
    // Utility classes
    require_once AAISEO_PLUGIN_DIR . 'includes/utils/class-aaiseo-utils.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/utils/class-aaiseo-cache.php';
    require_once AAISEO_PLUGIN_DIR . 'includes/utils/class-aaiseo-logger.php';
    
    // Enterprise classes (if available)
    if (file_exists(AAISEO_PLUGIN_DIR . 'includes/enterprise/class-ai-content-generator.php')) {
        require_once AAISEO_PLUGIN_DIR . 'includes/enterprise/class-ai-content-generator.php';
        require_once AAISEO_PLUGIN_DIR . 'includes/enterprise/class-competitor-intelligence-pro.php';
    }
}

// Load all classes immediately
aaiseo_load_all_classes();

/**
 * Main plugin class
 */
class Autonomous_AI_SEO {
    
    /**
     * Single instance of the plugin
     */
    private static $instance = null;
    
    /**
     * Plugin components
     */
    public $database;
    public $core;
    public $admin;
    public $seo_analyzer;
    public $content_optimizer;
    public $technical_seo;
    public $ai_engine;
    public $schema_generator;
    public $link_builder;
    public $performance_monitor;
    public $meta_boxes;
    public $keyword_research;
    public $competitor_intelligence;
    public $rank_tracker;
    public $analytics;
    
    /**
     * Get single instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('plugins_loaded', array($this, 'init'), 10);
    }
    
    /**
     * Initialize plugin
     */
    public function init() {
        // Initialize components
        $this->init_components();
        
        // Register hooks
        $this->register_hooks();
        
        // Schedule cron tasks
        $this->schedule_cron_tasks();
    }
    
    /**
     * Initialize components
     */
    private function init_components() {
        // Core components
        $this->database = new AAISEO_Database();
        $this->core = new AAISEO_Core();
        $this->seo_analyzer = new AAISEO_SEO_Analyzer();
        $this->content_optimizer = new AAISEO_Content_Optimizer();
        $this->technical_seo = new AAISEO_Technical_SEO();
        $this->ai_engine = new AAISEO_AI_Engine();
        $this->schema_generator = new AAISEO_Schema_Generator();
        $this->link_builder = new AAISEO_Link_Builder();
        $this->performance_monitor = new AAISEO_Performance_Monitor();
        $this->meta_boxes = new AAISEO_Meta_Boxes();
        
        // Admin components (always initialize to prevent errors)
        $this->admin = new AAISEO_Admin();
        $this->keyword_research = new AAISEO_Keyword_Research();
        $this->competitor_intelligence = new AAISEO_Competitive_Intelligence();
        $this->rank_tracker = new AAISEO_Rank_Tracker();
        $this->analytics = new AAISEO_Analytics();
    }
    
    /**
     * Register WordPress hooks
     */
    private function register_hooks() {
        // SEO hooks
        add_action('wp_head', array($this, 'output_seo_meta'), 1);
        add_action('wp_head', array($this, 'output_schema_markup'), 5);
        
        // Content hooks
        add_filter('the_content', array($this, 'optimize_content'), 10);
        add_filter('the_title', array($this, 'optimize_title'), 10, 2);
        
        // Admin hooks
        add_action('save_post', array($this, 'save_post_seo_data'), 10, 2);
        add_action('delete_post', array($this, 'delete_post_seo_data'));
        
        // AJAX hooks (main plugin level - non-admin specific)
        add_action('wp_ajax_aaiseo_analyze_content', array($this, 'ajax_analyze_content'));
        add_action('wp_ajax_nopriv_aaiseo_analyze_content', array($this, 'ajax_analyze_content'));
        add_action('wp_ajax_aaiseo_save_settings', array($this, 'ajax_save_settings'));
        
        // Cron hooks
        add_action('aaiseo_hourly_tasks', array($this, 'run_hourly_tasks'));
        add_action('aaiseo_daily_tasks', array($this, 'run_daily_tasks'));
        add_action('aaiseo_weekly_tasks', array($this, 'run_weekly_tasks'));
        
        // REST API hooks
        add_action('rest_api_init', array($this, 'register_rest_routes'));
    }
    
    /**
     * Output SEO meta tags
     */
    public function output_seo_meta() {
        if (is_admin() || is_feed()) {
            return;
        }
        
        global $post;
        if (!is_object($post)) {
            return;
        }
        
        // Get SEO data
        $seo_title = get_post_meta($post->ID, '_aaiseo_title', true);
        $seo_description = get_post_meta($post->ID, '_aaiseo_description', true);
        $focus_keyword = get_post_meta($post->ID, '_aaiseo_focus_keyword', true);
        
        // Output meta tags
        if (!empty($seo_title)) {
            echo '<title>' . esc_html($seo_title) . '</title>' . "\n";
        }
        
        if (!empty($seo_description)) {
            echo '<meta name="description" content="' . esc_attr($seo_description) . '">' . "\n";
        }
        
        if (!empty($focus_keyword)) {
            echo '<meta name="keywords" content="' . esc_attr($focus_keyword) . '">' . "\n";
        }
        
        // Open Graph tags
        echo '<meta property="og:title" content="' . esc_attr($seo_title ?: get_the_title()) . '">' . "\n";
        echo '<meta property="og:description" content="' . esc_attr($seo_description ?: wp_trim_words(get_the_excerpt(), 20)) . '">' . "\n";
        echo '<meta property="og:url" content="' . esc_url(get_permalink()) . '">' . "\n";
        echo '<meta property="og:type" content="article">' . "\n";
        
        // Twitter Card tags
        echo '<meta name="twitter:card" content="summary_large_image">' . "\n";
        echo '<meta name="twitter:title" content="' . esc_attr($seo_title ?: get_the_title()) . '">' . "\n";
        echo '<meta name="twitter:description" content="' . esc_attr($seo_description ?: wp_trim_words(get_the_excerpt(), 20)) . '">' . "\n";
    }
    
    /**
     * Output schema markup
     */
    public function output_schema_markup() {
        if (is_admin() || is_feed()) {
            return;
        }
        
        global $post;
        if (!is_object($post)) {
            return;
        }
        
        $schema_data = array(
            '@context' => 'https://schema.org',
            '@type' => 'Article',
            'headline' => get_the_title(),
            'description' => wp_trim_words(get_the_excerpt(), 20),
            'url' => get_permalink(),
            'datePublished' => get_the_date('c'),
            'dateModified' => get_the_modified_date('c'),
            'author' => array(
                '@type' => 'Person',
                'name' => get_the_author()
            )
        );
        
        echo '<script type="application/ld+json">' . json_encode($schema_data) . '</script>' . "\n";
    }
    
    /**
     * Optimize content
     */
    public function optimize_content($content) {
        if (is_admin() || is_feed()) {
            return $content;
        }
        
        // Add internal links if enabled
        $auto_link = get_option('aaiseo_auto_internal_links', 0);
        if ($auto_link && $this->link_builder) {
            $content = $this->link_builder->add_internal_links($content);
        }
        
        return $content;
    }
    
    /**
     * Optimize title
     */
    public function optimize_title($title, $id = null) {
        if (is_admin() || is_feed()) {
            return $title;
        }
        
        if ($id) {
            $seo_title = get_post_meta($id, '_aaiseo_title', true);
            if (!empty($seo_title)) {
                return $seo_title;
            }
        }
        
        return $title;
    }
    
    /**
     * Save post SEO data
     */
    public function save_post_seo_data($post_id, $post) {
        // Skip autosaves and revisions
        if (wp_is_post_autosave($post_id) || wp_is_post_revision($post_id)) {
            return;
        }
        
        // Check permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Save SEO data
        if (isset($_POST['aaiseo_title'])) {
            update_post_meta($post_id, '_aaiseo_title', sanitize_text_field($_POST['aaiseo_title']));
        }
        
        if (isset($_POST['aaiseo_description'])) {
            update_post_meta($post_id, '_aaiseo_description', sanitize_textarea_field($_POST['aaiseo_description']));
        }
        
        if (isset($_POST['aaiseo_focus_keyword'])) {
            update_post_meta($post_id, '_aaiseo_focus_keyword', sanitize_text_field($_POST['aaiseo_focus_keyword']));
        }
        
        // Run SEO analysis
        if ($this->seo_analyzer) {
            $score = $this->seo_analyzer->analyze_post($post_id);
            update_post_meta($post_id, '_aaiseo_score', $score);
        }
    }
    
    /**
     * Delete post SEO data
     */
    public function delete_post_seo_data($post_id) {
        delete_post_meta($post_id, '_aaiseo_title');
        delete_post_meta($post_id, '_aaiseo_description');
        delete_post_meta($post_id, '_aaiseo_focus_keyword');
        delete_post_meta($post_id, '_aaiseo_score');
    }
    
    /**
     * AJAX analyze content
     */
    public function ajax_analyze_content() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        $content = sanitize_textarea_field($_POST['content']);
        $keyword = sanitize_text_field($_POST['keyword']);
        
        if ($this->seo_analyzer) {
            $analysis = $this->seo_analyzer->analyze_content($content, $keyword);
            wp_send_json_success($analysis);
        } else {
            wp_send_json_error('SEO analyzer not available');
        }
    }
    
    /**
     * AJAX save settings
     */
    public function ajax_save_settings() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }
        
        $settings = $_POST['settings'];
        
        foreach ($settings as $key => $value) {
            update_option('aaiseo_' . $key, sanitize_text_field($value));
        }
        
        wp_send_json_success('Settings saved');
    }
    
    /**
     * Schedule cron tasks
     */
    private function schedule_cron_tasks() {
        // Schedule hourly tasks
        if (!wp_next_scheduled('aaiseo_hourly_tasks')) {
            wp_schedule_event(time(), 'hourly', 'aaiseo_hourly_tasks');
        }
        
        // Schedule daily tasks
        if (!wp_next_scheduled('aaiseo_daily_tasks')) {
            wp_schedule_event(time(), 'daily', 'aaiseo_daily_tasks');
        }
        
        // Schedule weekly tasks
        if (!wp_next_scheduled('aaiseo_weekly_tasks')) {
            wp_schedule_event(time(), 'weekly', 'aaiseo_weekly_tasks');
        }
    }
    
    /**
     * Run hourly tasks
     */
    public function run_hourly_tasks() {
        // Update rankings
        if ($this->rank_tracker) {
            $this->rank_tracker->update_rankings();
        }
        
        // Update competitor data
        if ($this->competitor_intelligence) {
            $this->competitor_intelligence->update_competitor_data();
        }
    }
    
    /**
     * Run daily tasks
     */
    public function run_daily_tasks() {
        // Run technical SEO checks
        if ($this->technical_seo) {
            $this->technical_seo->run_automated_checks();
        }
        
        // Generate daily reports
        if ($this->analytics) {
            $this->analytics->generate_daily_report();
        }
    }
    
    /**
     * Run weekly tasks
     */
    public function run_weekly_tasks() {
        // Generate weekly reports
        if ($this->analytics) {
            $this->analytics->generate_weekly_report();
        }
        
        // Clean up old data
        if ($this->database) {
            $this->database->cleanup_old_data();
        }
    }
    
    /**
     * Register REST API routes
     */
    public function register_rest_routes() {
        register_rest_route('aaiseo/v1', '/analyze', array(
            'methods' => 'POST',
            'callback' => array($this, 'rest_analyze_content'),
            'permission_callback' => array($this, 'rest_permission_check')
        ));
        
        register_rest_route('aaiseo/v1', '/keywords', array(
            'methods' => 'GET',
            'callback' => array($this, 'rest_get_keywords'),
            'permission_callback' => array($this, 'rest_permission_check')
        ));
    }
    
    /**
     * REST permission check
     */
    public function rest_permission_check() {
        return current_user_can('edit_posts');
    }
    
    /**
     * REST analyze content
     */
    public function rest_analyze_content($request) {
        $content = $request->get_param('content');
        $keyword = $request->get_param('keyword');
        
        if ($this->seo_analyzer) {
            $analysis = $this->seo_analyzer->analyze_content($content, $keyword);
            return rest_ensure_response($analysis);
        }
        
        return new WP_Error('analyzer_error', 'SEO analyzer not available', array('status' => 500));
    }
    
    /**
     * REST get keywords
     */
    public function rest_get_keywords($request) {
        if ($this->keyword_research) {
            $keywords = $this->keyword_research->get_tracked_keywords();
            return rest_ensure_response($keywords);
        }
        
        return new WP_Error('keywords_error', 'Keyword research not available', array('status' => 500));
    }
    
    /**
     * Plugin activation
     */
    public static function activate() {
        // Create database tables
        self::create_database_tables();
        
        // Set default options
        self::set_default_options();
        
        // Schedule cron events
        self::schedule_activation_cron();
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Plugin deactivation
     */
    public static function deactivate() {
        // Clear scheduled events
        wp_clear_scheduled_hook('aaiseo_hourly_tasks');
        wp_clear_scheduled_hook('aaiseo_daily_tasks');
        wp_clear_scheduled_hook('aaiseo_weekly_tasks');
        
        // Flush rewrite rules
        flush_rewrite_rules();
    }
    
    /**
     * Create database tables
     */
    private static function create_database_tables() {
        if (class_exists('AAISEO_Database')) {
            $database = new AAISEO_Database();
            $database->create_tables();
        }
    }
    
    /**
     * Set default options
     */
    private static function set_default_options() {
        // General settings
        $general_defaults = array(
            'auto_optimize' => 1,
            'technical_audit' => 1,
            'competitive_monitoring' => 0,
            'auto_internal_links' => 1
        );
        add_option('aaiseo_general_settings', $general_defaults);
        
        // API settings
        $api_defaults = array(
            'openai_api_key' => '',
            'google_api_key' => '',
            'enable_ai_features' => 0
        );
        add_option('aaiseo_api_settings', $api_defaults);
        
        // Social settings
        $social_defaults = array(
            'facebook_app_id' => '',
            'twitter_username' => '',
            'enable_open_graph' => 1,
            'enable_twitter_cards' => 1
        );
        add_option('aaiseo_social_settings', $social_defaults);
    }
    
    /**
     * Schedule activation cron events
     */
    private static function schedule_activation_cron() {
        // Schedule hourly tasks
        if (!wp_next_scheduled('aaiseo_hourly_tasks')) {
            wp_schedule_event(time(), 'hourly', 'aaiseo_hourly_tasks');
        }
        
        // Schedule daily tasks
        if (!wp_next_scheduled('aaiseo_daily_tasks')) {
            wp_schedule_event(time(), 'daily', 'aaiseo_daily_tasks');
        }
        
        // Schedule weekly tasks
        if (!wp_next_scheduled('aaiseo_weekly_tasks')) {
            wp_schedule_event(time(), 'weekly', 'aaiseo_weekly_tasks');
        }
    }
}

// Initialize the plugin
Autonomous_AI_SEO::get_instance();

// Activation hook
register_activation_hook(__FILE__, array('Autonomous_AI_SEO', 'activate'));

// Deactivation hook  
register_deactivation_hook(__FILE__, array('Autonomous_AI_SEO', 'deactivate'));

