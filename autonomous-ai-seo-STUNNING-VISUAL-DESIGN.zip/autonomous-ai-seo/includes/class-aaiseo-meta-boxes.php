<?php
/**
 * Meta Boxes Class
 * Handles SEO meta boxes on post/page edit screens
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Meta_Boxes {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('add_meta_boxes', array($this, 'add_meta_boxes'));
        add_action('save_post', array($this, 'save_meta_boxes'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
    }
    
    /**
     * Add meta boxes
     */
    public function add_meta_boxes() {
        $post_types = get_post_types(array('public' => true));
        
        foreach ($post_types as $post_type) {
            add_meta_box(
                'aaiseo-seo-meta',
                __('AI SEO Optimization', 'autonomous-ai-seo'),
                array($this, 'render_seo_meta_box'),
                $post_type,
                'normal',
                'high'
            );
            
            add_meta_box(
                'aaiseo-content-analysis',
                __('Content Analysis', 'autonomous-ai-seo'),
                array($this, 'render_content_analysis_box'),
                $post_type,
                'side',
                'default'
            );
        }
    }
    
    /**
     * Render SEO meta box
     */
    public function render_seo_meta_box($post) {
        wp_nonce_field('aaiseo_meta_box_nonce', 'aaiseo_meta_box_nonce');
        
        // Get existing values
        $meta_title = get_post_meta($post->ID, '_aaiseo_meta_title', true);
        $meta_description = get_post_meta($post->ID, '_aaiseo_meta_description', true);
        $focus_keyword = get_post_meta($post->ID, '_aaiseo_focus_keyword', true);
        $secondary_keywords = get_post_meta($post->ID, '_aaiseo_secondary_keywords', true);
        $canonical_url = get_post_meta($post->ID, '_aaiseo_canonical_url', true);
        $noindex = get_post_meta($post->ID, '_aaiseo_noindex', true);
        $nofollow = get_post_meta($post->ID, '_aaiseo_nofollow', true);
        
        ?>
        <div class="aaiseo-meta-box">
            <div class="aaiseo-tabs">
                <ul class="aaiseo-tab-nav">
                    <li><a href="#aaiseo-general" class="active"><?php _e('General', 'autonomous-ai-seo'); ?></a></li>
                    <li><a href="#aaiseo-social"><?php _e('Social', 'autonomous-ai-seo'); ?></a></li>
                    <li><a href="#aaiseo-advanced"><?php _e('Advanced', 'autonomous-ai-seo'); ?></a></li>
                </ul>
                
                <div id="aaiseo-general" class="aaiseo-tab-content active">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="aaiseo_focus_keyword"><?php _e('Focus Keyword', 'autonomous-ai-seo'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="aaiseo_focus_keyword" name="aaiseo_focus_keyword" 
                                       value="<?php echo esc_attr($focus_keyword); ?>" class="regular-text" />
                                <p class="description"><?php _e('The main keyword you want this content to rank for.', 'autonomous-ai-seo'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="aaiseo_secondary_keywords"><?php _e('Secondary Keywords', 'autonomous-ai-seo'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="aaiseo_secondary_keywords" name="aaiseo_secondary_keywords" 
                                       value="<?php echo esc_attr($secondary_keywords); ?>" class="regular-text" />
                                <p class="description"><?php _e('Additional keywords separated by commas.', 'autonomous-ai-seo'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="aaiseo_meta_title"><?php _e('SEO Title', 'autonomous-ai-seo'); ?></label>
                            </th>
                            <td>
                                <input type="text" id="aaiseo_meta_title" name="aaiseo_meta_title" 
                                       value="<?php echo esc_attr($meta_title); ?>" class="large-text" maxlength="60" />
                                <div class="aaiseo-title-preview">
                                    <div class="aaiseo-preview-label"><?php _e('Preview:', 'autonomous-ai-seo'); ?></div>
                                    <div class="aaiseo-preview-title"><?php echo esc_html($meta_title ?: $post->post_title); ?></div>
                                    <div class="aaiseo-preview-url"><?php echo esc_url(get_permalink($post->ID)); ?></div>
                                </div>
                                <div class="aaiseo-char-count">
                                    <span class="current"><?php echo strlen($meta_title); ?></span> / 60 <?php _e('characters', 'autonomous-ai-seo'); ?>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row">
                                <label for="aaiseo_meta_description"><?php _e('Meta Description', 'autonomous-ai-seo'); ?></label>
                            </th>
                            <td>
                                <textarea id="aaiseo_meta_description" name="aaiseo_meta_description" 
                                          rows="3" class="large-text" maxlength="160"><?php echo esc_textarea($meta_description); ?></textarea>
                                <div class="aaiseo-description-preview">
                                    <div class="aaiseo-preview-description"><?php echo esc_html($meta_description ?: wp_trim_words($post->post_content, 25)); ?></div>
                                </div>
                                <div class="aaiseo-char-count">
                                    <span class="current"><?php echo strlen($meta_description); ?></span> / 160 <?php _e('characters', 'autonomous-ai-seo'); ?>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
                
                <div id="aaiseo-social" class="aaiseo-tab-content">
                    <?php $this->render_social_tab($post); ?>
                </div>
                
                <div id="aaiseo-advanced" class="aaiseo-tab-content">
                    <table class="form-table">
                        <tr>
                            <th scope="row">
                                <label for="aaiseo_canonical_url"><?php _e('Canonical URL', 'autonomous-ai-seo'); ?></label>
                            </th>
                            <td>
                                <input type="url" id="aaiseo_canonical_url" name="aaiseo_canonical_url" 
                                       value="<?php echo esc_attr($canonical_url); ?>" class="large-text" />
                                <p class="description"><?php _e('Leave empty to use the default URL.', 'autonomous-ai-seo'); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <th scope="row"><?php _e('Robots Meta', 'autonomous-ai-seo'); ?></th>
                            <td>
                                <label>
                                    <input type="checkbox" name="aaiseo_noindex" value="1" <?php checked($noindex, 1); ?> />
                                    <?php _e('No Index', 'autonomous-ai-seo'); ?>
                                </label>
                                <br>
                                <label>
                                    <input type="checkbox" name="aaiseo_nofollow" value="1" <?php checked($nofollow, 1); ?> />
                                    <?php _e('No Follow', 'autonomous-ai-seo'); ?>
                                </label>
                                <p class="description"><?php _e('Control how search engines crawl this page.', 'autonomous-ai-seo'); ?></p>
                            </td>
                        </tr>
                    </table>
                </div>
            </div>
        </div>
        
        <style>
        .aaiseo-meta-box {
            margin: 0 -12px;
        }
        .aaiseo-tabs {
            border: 1px solid #ccd0d4;
            background: #fff;
        }
        .aaiseo-tab-nav {
            margin: 0;
            padding: 0;
            list-style: none;
            border-bottom: 1px solid #ccd0d4;
            background: #f9f9f9;
        }
        .aaiseo-tab-nav li {
            display: inline-block;
            margin: 0;
        }
        .aaiseo-tab-nav a {
            display: block;
            padding: 12px 20px;
            text-decoration: none;
            color: #555;
            border-right: 1px solid #ccd0d4;
        }
        .aaiseo-tab-nav a.active,
        .aaiseo-tab-nav a:hover {
            background: #fff;
            color: #0073aa;
        }
        .aaiseo-tab-content {
            display: none;
            padding: 20px;
        }
        .aaiseo-tab-content.active {
            display: block;
        }
        .aaiseo-preview-label {
            font-weight: 600;
            margin-bottom: 8px;
            color: #555;
        }
        .aaiseo-preview-title {
            color: #1a0dab;
            font-size: 18px;
            line-height: 1.2;
            margin-bottom: 4px;
        }
        .aaiseo-preview-url {
            color: #006621;
            font-size: 14px;
            margin-bottom: 4px;
        }
        .aaiseo-preview-description {
            color: #545454;
            font-size: 13px;
            line-height: 1.4;
        }
        .aaiseo-char-count {
            font-size: 12px;
            color: #666;
            margin-top: 4px;
        }
        .aaiseo-char-count .current {
            font-weight: 600;
        }
        .aaiseo-char-count.over-limit .current {
            color: #d63638;
        }
        </style>
        <?php
    }
    
    /**
     * Render social tab
     */
    private function render_social_tab($post) {
        $og_title = get_post_meta($post->ID, '_aaiseo_og_title', true);
        $og_description = get_post_meta($post->ID, '_aaiseo_og_description', true);
        $og_image = get_post_meta($post->ID, '_aaiseo_og_image', true);
        $twitter_title = get_post_meta($post->ID, '_aaiseo_twitter_title', true);
        $twitter_description = get_post_meta($post->ID, '_aaiseo_twitter_description', true);
        $twitter_image = get_post_meta($post->ID, '_aaiseo_twitter_image', true);
        
        ?>
        <h4><?php _e('Open Graph (Facebook)', 'autonomous-ai-seo'); ?></h4>
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="aaiseo_og_title"><?php _e('OG Title', 'autonomous-ai-seo'); ?></label>
                </th>
                <td>
                    <input type="text" id="aaiseo_og_title" name="aaiseo_og_title" 
                           value="<?php echo esc_attr($og_title); ?>" class="large-text" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="aaiseo_og_description"><?php _e('OG Description', 'autonomous-ai-seo'); ?></label>
                </th>
                <td>
                    <textarea id="aaiseo_og_description" name="aaiseo_og_description" 
                              rows="3" class="large-text"><?php echo esc_textarea($og_description); ?></textarea>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="aaiseo_og_image"><?php _e('OG Image', 'autonomous-ai-seo'); ?></label>
                </th>
                <td>
                    <input type="url" id="aaiseo_og_image" name="aaiseo_og_image" 
                           value="<?php echo esc_attr($og_image); ?>" class="large-text" />
                    <button type="button" class="button aaiseo-upload-image"><?php _e('Upload Image', 'autonomous-ai-seo'); ?></button>
                </td>
            </tr>
        </table>
        
        <h4><?php _e('Twitter Cards', 'autonomous-ai-seo'); ?></h4>
        <table class="form-table">
            <tr>
                <th scope="row">
                    <label for="aaiseo_twitter_title"><?php _e('Twitter Title', 'autonomous-ai-seo'); ?></label>
                </th>
                <td>
                    <input type="text" id="aaiseo_twitter_title" name="aaiseo_twitter_title" 
                           value="<?php echo esc_attr($twitter_title); ?>" class="large-text" />
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="aaiseo_twitter_description"><?php _e('Twitter Description', 'autonomous-ai-seo'); ?></label>
                </th>
                <td>
                    <textarea id="aaiseo_twitter_description" name="aaiseo_twitter_description" 
                              rows="3" class="large-text"><?php echo esc_textarea($twitter_description); ?></textarea>
                </td>
            </tr>
            <tr>
                <th scope="row">
                    <label for="aaiseo_twitter_image"><?php _e('Twitter Image', 'autonomous-ai-seo'); ?></label>
                </th>
                <td>
                    <input type="url" id="aaiseo_twitter_image" name="aaiseo_twitter_image" 
                           value="<?php echo esc_attr($twitter_image); ?>" class="large-text" />
                    <button type="button" class="button aaiseo-upload-image"><?php _e('Upload Image', 'autonomous-ai-seo'); ?></button>
                </td>
            </tr>
        </table>
        <?php
    }
    
    /**
     * Render content analysis box
     */
    public function render_content_analysis_box($post) {
        ?>
        <div id="aaiseo-content-analysis">
            <div class="aaiseo-analysis-loading">
                <p><?php _e('Analyzing content...', 'autonomous-ai-seo'); ?></p>
                <div class="aaiseo-spinner"></div>
            </div>
            
            <div class="aaiseo-analysis-results" style="display: none;">
                <div class="aaiseo-score-circle">
                    <div class="aaiseo-score-number">0</div>
                    <div class="aaiseo-score-label"><?php _e('SEO Score', 'autonomous-ai-seo'); ?></div>
                </div>
                
                <div class="aaiseo-analysis-breakdown">
                    <div class="aaiseo-analysis-item">
                        <span class="aaiseo-analysis-label"><?php _e('Title', 'autonomous-ai-seo'); ?></span>
                        <span class="aaiseo-analysis-score">0/100</span>
                        <div class="aaiseo-analysis-bar">
                            <div class="aaiseo-analysis-fill" style="width: 0%"></div>
                        </div>
                    </div>
                    
                    <div class="aaiseo-analysis-item">
                        <span class="aaiseo-analysis-label"><?php _e('Content', 'autonomous-ai-seo'); ?></span>
                        <span class="aaiseo-analysis-score">0/100</span>
                        <div class="aaiseo-analysis-bar">
                            <div class="aaiseo-analysis-fill" style="width: 0%"></div>
                        </div>
                    </div>
                    
                    <div class="aaiseo-analysis-item">
                        <span class="aaiseo-analysis-label"><?php _e('Keywords', 'autonomous-ai-seo'); ?></span>
                        <span class="aaiseo-analysis-score">0/100</span>
                        <div class="aaiseo-analysis-bar">
                            <div class="aaiseo-analysis-fill" style="width: 0%"></div>
                        </div>
                    </div>
                </div>
                
                <div class="aaiseo-recommendations">
                    <h4><?php _e('Recommendations', 'autonomous-ai-seo'); ?></h4>
                    <ul class="aaiseo-recommendations-list"></ul>
                </div>
                
                <button type="button" class="button button-primary aaiseo-analyze-button">
                    <?php _e('Re-analyze Content', 'autonomous-ai-seo'); ?>
                </button>
            </div>
        </div>
        
        <style>
        #aaiseo-content-analysis {
            padding: 12px;
        }
        .aaiseo-analysis-loading {
            text-align: center;
            padding: 20px;
        }
        .aaiseo-spinner {
            width: 20px;
            height: 20px;
            border: 2px solid #f3f3f3;
            border-top: 2px solid #0073aa;
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin: 10px auto;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        .aaiseo-score-circle {
            text-align: center;
            margin-bottom: 20px;
        }
        .aaiseo-score-number {
            font-size: 36px;
            font-weight: bold;
            color: #0073aa;
        }
        .aaiseo-score-label {
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
        }
        .aaiseo-analysis-item {
            margin-bottom: 12px;
        }
        .aaiseo-analysis-label {
            display: inline-block;
            width: 60px;
            font-size: 12px;
            color: #666;
        }
        .aaiseo-analysis-score {
            float: right;
            font-size: 12px;
            color: #666;
        }
        .aaiseo-analysis-bar {
            height: 6px;
            background: #f0f0f0;
            border-radius: 3px;
            margin-top: 4px;
            overflow: hidden;
        }
        .aaiseo-analysis-fill {
            height: 100%;
            background: #0073aa;
            transition: width 0.3s ease;
        }
        .aaiseo-recommendations {
            margin-top: 20px;
        }
        .aaiseo-recommendations h4 {
            margin: 0 0 10px 0;
            font-size: 13px;
            color: #333;
        }
        .aaiseo-recommendations-list {
            margin: 0;
            padding: 0;
            list-style: none;
        }
        .aaiseo-recommendations-list li {
            padding: 6px 0;
            font-size: 12px;
            border-bottom: 1px solid #f0f0f0;
        }
        .aaiseo-analyze-button {
            width: 100%;
            margin-top: 15px;
        }
        </style>
        <?php
    }
    
    /**
     * Save meta boxes
     */
    public function save_meta_boxes($post_id) {
        // Check nonce
        if (!isset($_POST['aaiseo_meta_box_nonce']) || !wp_verify_nonce($_POST['aaiseo_meta_box_nonce'], 'aaiseo_meta_box_nonce')) {
            return;
        }
        
        // Check permissions
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Skip autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Save meta fields
        $meta_fields = array(
            '_aaiseo_focus_keyword',
            '_aaiseo_secondary_keywords',
            '_aaiseo_meta_title',
            '_aaiseo_meta_description',
            '_aaiseo_canonical_url',
            '_aaiseo_og_title',
            '_aaiseo_og_description',
            '_aaiseo_og_image',
            '_aaiseo_twitter_title',
            '_aaiseo_twitter_description',
            '_aaiseo_twitter_image'
        );
        
        foreach ($meta_fields as $field) {
            $key = str_replace('_aaiseo_', 'aaiseo_', $field);
            
            if (isset($_POST[$key])) {
                $value = sanitize_text_field($_POST[$key]);
                update_post_meta($post_id, $field, $value);
            }
        }
        
        // Save checkbox fields
        $checkbox_fields = array(
            '_aaiseo_noindex',
            '_aaiseo_nofollow'
        );
        
        foreach ($checkbox_fields as $field) {
            $key = str_replace('_aaiseo_', 'aaiseo_', $field);
            $value = isset($_POST[$key]) ? 1 : 0;
            update_post_meta($post_id, $field, $value);
        }
        
        // Trigger content analysis if focus keyword is set
        if (isset($_POST['aaiseo_focus_keyword']) && !empty($_POST['aaiseo_focus_keyword'])) {
            $this->schedule_content_analysis($post_id);
        }
    }
    
    /**
     * Schedule content analysis
     */
    private function schedule_content_analysis($post_id) {
        // Schedule analysis to run after save
        wp_schedule_single_event(time() + 10, 'aaiseo_analyze_post_content', array($post_id));
    }
    
    /**
     * Enqueue scripts
     */
    public function enqueue_scripts($hook) {
        global $post_type;
        
        if (!in_array($hook, array('post.php', 'post-new.php'))) {
            return;
        }
        
        wp_enqueue_script('aaiseo-meta-boxes', AAISEO_PLUGIN_URL . 'assets/js/meta-boxes.js', array('jquery'), AAISEO_VERSION, true);
        wp_enqueue_style('aaiseo-meta-boxes', AAISEO_PLUGIN_URL . 'assets/css/meta-boxes.css', array(), AAISEO_VERSION);
        
        wp_localize_script('aaiseo-meta-boxes', 'aaiseoMetaBoxes', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('aaiseo_admin_nonce'),
            'postId' => get_the_ID(),
            'strings' => array(
                'analyzing' => __('Analyzing...', 'autonomous-ai-seo'),
                'error' => __('Analysis failed. Please try again.', 'autonomous-ai-seo'),
                'noKeyword' => __('Please enter a focus keyword first.', 'autonomous-ai-seo')
            )
        ));
    }
}

