<?php
/**
 * Core functionality for Autonomous AI SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Core {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize core functionality
     */
    public function init() {
        // Setup database tables if needed
        $this->maybe_upgrade_database();
        
        // Schedule events
        $this->schedule_events();
    }
    
    /**
     * Create database tables
     */
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // SEO audit results table
        $table_audit = $wpdb->prefix . 'aaiseo_audit_results';
        $sql_audit = "CREATE TABLE $table_audit (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) NOT NULL,
            audit_type varchar(50) NOT NULL,
            score int(3) NOT NULL DEFAULT 0,
            issues longtext,
            recommendations longtext,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY audit_type (audit_type)
        ) $charset_collate;";
        
        // Analytics data table
        $table_analytics = $wpdb->prefix . 'aaiseo_analytics';
        $sql_analytics = "CREATE TABLE $table_analytics (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) NOT NULL,
            metric_type varchar(50) NOT NULL,
            metric_value text,
            date_recorded date NOT NULL,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY metric_type (metric_type),
            KEY date_recorded (date_recorded)
        ) $charset_collate;";
        
        // Competitive intelligence table
        $table_competitive = $wpdb->prefix . 'aaiseo_competitive';
        $sql_competitive = "CREATE TABLE $table_competitive (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            competitor_url varchar(255) NOT NULL,
            keyword varchar(255) NOT NULL,
            ranking_position int(3),
            content_analysis longtext,
            last_checked datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY competitor_url (competitor_url),
            KEY keyword (keyword)
        ) $charset_collate;";
        
        // Content optimization table
        $table_content = $wpdb->prefix . 'aaiseo_content_optimization';
        $sql_content = "CREATE TABLE $table_content (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            post_id bigint(20) NOT NULL,
            optimization_type varchar(50) NOT NULL,
            original_content longtext,
            optimized_content longtext,
            ai_suggestions longtext,
            status varchar(20) DEFAULT 'pending',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY post_id (post_id),
            KEY optimization_type (optimization_type),
            KEY status (status)
        ) $charset_collate;";
        
        // Settings table
        $table_settings = $wpdb->prefix . 'aaiseo_settings';
        $sql_settings = "CREATE TABLE $table_settings (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            setting_name varchar(100) NOT NULL,
            setting_value longtext,
            autoload varchar(20) DEFAULT 'yes',
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            UNIQUE KEY setting_name (setting_name)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql_audit);
        dbDelta($sql_analytics);
        dbDelta($sql_competitive);
        dbDelta($sql_content);
        dbDelta($sql_settings);
        
        // Update database version
        update_option('aaiseo_db_version', '1.0.0');
    }
    
    /**
     * Check if database needs upgrade
     */
    private function maybe_upgrade_database() {
        $current_version = get_option('aaiseo_db_version', '0.0.0');
        if (version_compare($current_version, '1.0.0', '<')) {
            $this->create_tables();
        }
    }
    
    /**
     * Schedule recurring events
     */
    private function schedule_events() {
        if (!wp_next_scheduled('aaiseo_daily_audit')) {
            wp_schedule_event(time(), 'daily', 'aaiseo_daily_audit');
        }
        
        if (!wp_next_scheduled('aaiseo_competitive_check')) {
            wp_schedule_event(time(), 'twicedaily', 'aaiseo_competitive_check');
        }
    }
    
    /**
     * Get plugin setting
     */
    public function get_setting($setting_name, $default = '') {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_settings';
        $result = $wpdb->get_var($wpdb->prepare(
            "SELECT setting_value FROM $table WHERE setting_name = %s",
            $setting_name
        ));
        
        return $result !== null ? $result : $default;
    }
    
    /**
     * Update plugin setting
     */
    public function update_setting($setting_name, $setting_value) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_settings';
        
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE setting_name = %s",
            $setting_name
        ));
        
        if ($existing) {
            return $wpdb->update(
                $table,
                array('setting_value' => $setting_value),
                array('setting_name' => $setting_name),
                array('%s'),
                array('%s')
            );
        } else {
            return $wpdb->insert(
                $table,
                array(
                    'setting_name' => $setting_name,
                    'setting_value' => $setting_value
                ),
                array('%s', '%s')
            );
        }
    }
    
    /**
     * Store audit results
     */
    public function store_audit_results($post_id, $audit_type, $score, $issues, $recommendations) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_audit_results';
        
        return $wpdb->insert(
            $table,
            array(
                'post_id' => $post_id,
                'audit_type' => $audit_type,
                'score' => $score,
                'issues' => maybe_serialize($issues),
                'recommendations' => maybe_serialize($recommendations)
            ),
            array('%d', '%s', '%d', '%s', '%s')
        );
    }
    
    /**
     * Get audit results
     */
    public function get_audit_results($post_id, $audit_type = '') {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_audit_results';
        
        if ($audit_type) {
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table WHERE post_id = %d AND audit_type = %s ORDER BY created_at DESC",
                $post_id, $audit_type
            ));
        } else {
            $results = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM $table WHERE post_id = %d ORDER BY created_at DESC",
                $post_id
            ));
        }
        
        // Unserialize data
        foreach ($results as $result) {
            $result->issues = maybe_unserialize($result->issues);
            $result->recommendations = maybe_unserialize($result->recommendations);
        }
        
        return $results;
    }
    
    /**
     * Store analytics data
     */
    public function store_analytics_data($post_id, $metric_type, $metric_value, $date = null) {
        global $wpdb;
        
        if (!$date) {
            $date = current_time('Y-m-d');
        }
        
        $table = $wpdb->prefix . 'aaiseo_analytics';
        
        return $wpdb->insert(
            $table,
            array(
                'post_id' => $post_id,
                'metric_type' => $metric_type,
                'metric_value' => maybe_serialize($metric_value),
                'date_recorded' => $date
            ),
            array('%d', '%s', '%s', '%s')
        );
    }
    
    /**
     * Get analytics data
     */
    public function get_analytics_data($post_id = 0, $metric_type = '', $days = 30) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_analytics';
        $date_limit = date('Y-m-d', strtotime("-$days days"));
        
        $where_conditions = array("date_recorded >= %s");
        $where_values = array($date_limit);
        
        if ($post_id > 0) {
            $where_conditions[] = "post_id = %d";
            $where_values[] = $post_id;
        }
        
        if ($metric_type) {
            $where_conditions[] = "metric_type = %s";
            $where_values[] = $metric_type;
        }
        
        $where_clause = implode(' AND ', $where_conditions);
        
        $results = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table WHERE $where_clause ORDER BY date_recorded DESC",
            $where_values
        ));
        
        // Unserialize data
        foreach ($results as $result) {
            $result->metric_value = maybe_unserialize($result->metric_value);
        }
        
        return $results;
    }
    
    /**
     * Clean up old data
     */
    public function cleanup_old_data($days = 90) {
        global $wpdb;
        
        $date_limit = date('Y-m-d', strtotime("-$days days"));
        
        // Clean audit results
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}aaiseo_audit_results WHERE created_at < %s",
            $date_limit
        ));
        
        // Clean analytics data
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}aaiseo_analytics WHERE date_recorded < %s",
            $date_limit
        ));
        
        // Clean competitive data
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$wpdb->prefix}aaiseo_competitive WHERE last_checked < %s",
            $date_limit
        ));
    }
}

