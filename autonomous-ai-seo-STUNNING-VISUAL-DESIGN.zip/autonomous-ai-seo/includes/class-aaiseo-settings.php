<?php
/**
 * Settings Management Class
 * Handles all plugin settings and configuration
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Settings {
    
    /**
     * Settings groups
     */
    private $settings_groups = array(
        'general',
        'seo',
        'content',
        'technical',
        'api',
        'advanced'
    );
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_init', array($this, 'register_settings'));
        add_action('wp_ajax_aaiseo_save_settings', array($this, 'ajax_save_settings'));
    }
    
    /**
     * Register WordPress settings
     */
    public function register_settings() {
        foreach ($this->settings_groups as $group) {
            register_setting(
                "aaiseo_settings_{$group}",
                "aaiseo_settings_{$group}",
                array($this, 'sanitize_settings')
            );
        }
    }
    
    /**
     * Get setting value
     */
    public function get($group, $key = null, $default = null) {
        $settings = get_option("aaiseo_settings_{$group}", array());
        
        if ($key === null) {
            return $settings;
        }
        
        return isset($settings[$key]) ? $settings[$key] : $default;
    }
    
    /**
     * Save setting value
     */
    public function set($group, $key, $value) {
        $settings = get_option("aaiseo_settings_{$group}", array());
        $settings[$key] = $value;
        
        return update_option("aaiseo_settings_{$group}", $settings);
    }
    
    /**
     * Get all settings
     */
    public function get_all() {
        $all_settings = array();
        
        foreach ($this->settings_groups as $group) {
            $all_settings[$group] = $this->get($group);
        }
        
        return $all_settings;
    }
    
    /**
     * Sanitize settings
     */
    public function sanitize_settings($input) {
        if (!is_array($input)) {
            return array();
        }
        
        $sanitized = array();
        
        foreach ($input as $key => $value) {
            if (is_array($value)) {
                $sanitized[$key] = $this->sanitize_settings($value);
            } elseif (is_bool($value)) {
                $sanitized[$key] = (bool) $value;
            } elseif (is_numeric($value)) {
                $sanitized[$key] = is_float($value) ? (float) $value : (int) $value;
            } else {
                $sanitized[$key] = sanitize_text_field($value);
            }
        }
        
        return $sanitized;
    }
    
    /**
     * AJAX save settings
     */
    public function ajax_save_settings() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $group = sanitize_text_field($_POST['group']);
        $settings = $_POST['settings'];
        
        if (!in_array($group, $this->settings_groups)) {
            wp_send_json_error(__('Invalid settings group', 'autonomous-ai-seo'));
        }
        
        $sanitized_settings = $this->sanitize_settings($settings);
        update_option("aaiseo_settings_{$group}", $sanitized_settings);
        
        wp_send_json_success(__('Settings saved successfully', 'autonomous-ai-seo'));
    }
    
    /**
     * Reset settings to defaults
     */
    public function reset_to_defaults() {
        $default_settings = $this->get_default_settings();
        
        foreach ($default_settings as $group => $settings) {
            update_option("aaiseo_settings_{$group}", $settings);
        }
        
        return true;
    }
    
    /**
     * Get default settings
     */
    public function get_default_settings() {
        return array(
            'general' => array(
                'enable_seo_analysis' => true,
                'enable_content_optimization' => true,
                'enable_technical_seo' => true,
                'enable_competitor_monitoring' => true,
                'enable_keyword_tracking' => true,
                'enable_analytics' => true
            ),
            'seo' => array(
                'default_meta_title_format' => '%%title%% | %%sitename%%',
                'default_meta_description_format' => '%%excerpt%%',
                'enable_schema_markup' => true,
                'enable_breadcrumbs' => true,
                'enable_xml_sitemaps' => true,
                'enable_robots_txt_optimization' => true
            ),
            'content' => array(
                'min_content_length' => 300,
                'max_keyword_density' => 2.5,
                'enable_readability_analysis' => true,
                'enable_ai_suggestions' => true,
                'enable_internal_linking' => true
            ),
            'technical' => array(
                'enable_page_speed_monitoring' => true,
                'enable_core_web_vitals' => true,
                'enable_mobile_optimization' => true,
                'enable_security_checks' => true,
                'enable_broken_link_detection' => true
            ),
            'api' => array(
                'google_search_console_connected' => false,
                'google_analytics_connected' => false,
                'openai_api_key' => '',
                'enable_ai_content_generation' => false
            ),
            'advanced' => array(
                'enable_debug_mode' => false,
                'cache_duration' => 3600,
                'max_concurrent_requests' => 5,
                'enable_logging' => true
            )
        );
    }
}

