<?php
/**
 * AAISEO Cache Management Class
 *
 * Handles caching for improved performance
 *
 * @package Autonomous_AI_SEO
 * @since 2.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Cache management class
 */
class AAISEO_Cache {
    
    /**
     * Cache group prefix
     */
    const CACHE_GROUP = 'aaiseo';
    
    /**
     * Default cache expiration (1 hour)
     */
    const DEFAULT_EXPIRATION = 3600;
    
    /**
     * Constructor
     */
    public function __construct() {
        // Initialize cache hooks
        add_action('init', array($this, 'init_cache'));
        add_action('wp_loaded', array($this, 'setup_cache_hooks'));
    }
    
    /**
     * Initialize cache system
     */
    public function init_cache() {
        // Set up cache groups
        wp_cache_add_global_groups(array(self::CACHE_GROUP));
    }
    
    /**
     * Setup cache invalidation hooks
     */
    public function setup_cache_hooks() {
        // Clear cache when posts are updated
        add_action('save_post', array($this, 'clear_post_cache'));
        add_action('delete_post', array($this, 'clear_post_cache'));
        
        // Clear cache when options are updated
        add_action('updated_option', array($this, 'clear_options_cache'));
        
        // Clear cache when plugins are activated/deactivated
        add_action('activated_plugin', array($this, 'clear_all_cache'));
        add_action('deactivated_plugin', array($this, 'clear_all_cache'));
    }
    
    /**
     * Get cached data
     *
     * @param string $key Cache key
     * @param string $group Cache group
     * @return mixed|false Cached data or false if not found
     */
    public static function get($key, $group = '') {
        if (empty($group)) {
            $group = self::CACHE_GROUP;
        }
        
        return wp_cache_get($key, $group);
    }
    
    /**
     * Set cached data
     *
     * @param string $key Cache key
     * @param mixed $data Data to cache
     * @param int $expiration Cache expiration in seconds
     * @param string $group Cache group
     * @return bool True on success, false on failure
     */
    public static function set($key, $data, $expiration = null, $group = '') {
        if (empty($group)) {
            $group = self::CACHE_GROUP;
        }
        
        if (is_null($expiration)) {
            $expiration = self::DEFAULT_EXPIRATION;
        }
        
        return wp_cache_set($key, $data, $group, $expiration);
    }
    
    /**
     * Delete cached data
     *
     * @param string $key Cache key
     * @param string $group Cache group
     * @return bool True on success, false on failure
     */
    public static function delete($key, $group = '') {
        if (empty($group)) {
            $group = self::CACHE_GROUP;
        }
        
        return wp_cache_delete($key, $group);
    }
    
    /**
     * Flush all cache for the plugin
     *
     * @return bool True on success, false on failure
     */
    public static function flush() {
        return wp_cache_flush_group(self::CACHE_GROUP);
    }
    
    /**
     * Get or set cached data with callback
     *
     * @param string $key Cache key
     * @param callable $callback Callback to generate data if not cached
     * @param int $expiration Cache expiration in seconds
     * @param string $group Cache group
     * @return mixed Cached or generated data
     */
    public static function remember($key, $callback, $expiration = null, $group = '') {
        $data = self::get($key, $group);
        
        if ($data === false) {
            $data = call_user_func($callback);
            self::set($key, $data, $expiration, $group);
        }
        
        return $data;
    }
    
    /**
     * Clear post-specific cache
     *
     * @param int $post_id Post ID
     */
    public function clear_post_cache($post_id) {
        // Clear SEO analysis cache for this post
        self::delete("seo_analysis_{$post_id}");
        self::delete("content_score_{$post_id}");
        self::delete("keywords_{$post_id}");
        
        // Clear related caches
        self::delete('sitemap_cache');
        self::delete('recent_posts');
    }
    
    /**
     * Clear options cache
     *
     * @param string $option Option name
     */
    public function clear_options_cache($option) {
        if (strpos($option, 'aaiseo_') === 0) {
            self::delete('plugin_settings');
            self::delete('seo_settings');
        }
    }
    
    /**
     * Clear all plugin cache
     */
    public function clear_all_cache() {
        self::flush();
    }
    
    /**
     * Get cache statistics
     *
     * @return array Cache statistics
     */
    public static function get_stats() {
        global $wp_object_cache;
        
        $stats = array(
            'hits' => 0,
            'misses' => 0,
            'cache_size' => 0,
            'group_size' => 0
        );
        
        if (isset($wp_object_cache->cache_hits)) {
            $stats['hits'] = $wp_object_cache->cache_hits;
        }
        
        if (isset($wp_object_cache->cache_misses)) {
            $stats['misses'] = $wp_object_cache->cache_misses;
        }
        
        if (isset($wp_object_cache->cache[self::CACHE_GROUP])) {
            $stats['group_size'] = count($wp_object_cache->cache[self::CACHE_GROUP]);
        }
        
        return $stats;
    }
    
    /**
     * Generate cache key with prefix
     *
     * @param string $key Base key
     * @param array $params Additional parameters
     * @return string Generated cache key
     */
    public static function generate_key($key, $params = array()) {
        $key_parts = array($key);
        
        if (!empty($params)) {
            $key_parts[] = md5(serialize($params));
        }
        
        return implode('_', $key_parts);
    }
    
    /**
     * Cache SEO analysis results
     *
     * @param int $post_id Post ID
     * @param array $analysis Analysis results
     * @param int $expiration Cache expiration
     */
    public static function cache_seo_analysis($post_id, $analysis, $expiration = null) {
        $key = self::generate_key('seo_analysis', array('post_id' => $post_id));
        self::set($key, $analysis, $expiration);
    }
    
    /**
     * Get cached SEO analysis
     *
     * @param int $post_id Post ID
     * @return array|false Analysis results or false if not cached
     */
    public static function get_seo_analysis($post_id) {
        $key = self::generate_key('seo_analysis', array('post_id' => $post_id));
        return self::get($key);
    }
    
    /**
     * Cache keyword research results
     *
     * @param string $keyword Keyword
     * @param array $results Research results
     * @param int $expiration Cache expiration
     */
    public static function cache_keyword_research($keyword, $results, $expiration = null) {
        $key = self::generate_key('keyword_research', array('keyword' => $keyword));
        self::set($key, $results, $expiration);
    }
    
    /**
     * Get cached keyword research
     *
     * @param string $keyword Keyword
     * @return array|false Research results or false if not cached
     */
    public static function get_keyword_research($keyword) {
        $key = self::generate_key('keyword_research', array('keyword' => $keyword));
        return self::get($key);
    }
    
    /**
     * Cache competitor analysis
     *
     * @param string $domain Domain
     * @param array $analysis Analysis results
     * @param int $expiration Cache expiration
     */
    public static function cache_competitor_analysis($domain, $analysis, $expiration = null) {
        $key = self::generate_key('competitor_analysis', array('domain' => $domain));
        self::set($key, $analysis, $expiration);
    }
    
    /**
     * Get cached competitor analysis
     *
     * @param string $domain Domain
     * @return array|false Analysis results or false if not cached
     */
    public static function get_competitor_analysis($domain) {
        $key = self::generate_key('competitor_analysis', array('domain' => $domain));
        return self::get($key);
    }
}

