<?php
/**
 * AAISEO Logger Class
 *
 * Handles logging for debugging and monitoring
 *
 * @package Autonomous_AI_SEO
 * @since 2.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Logger class for debugging and monitoring
 */
class AAISEO_Logger {
    
    /**
     * Log levels
     */
    const EMERGENCY = 'emergency';
    const ALERT = 'alert';
    const CRITICAL = 'critical';
    const ERROR = 'error';
    const WARNING = 'warning';
    const NOTICE = 'notice';
    const INFO = 'info';
    const DEBUG = 'debug';
    
    /**
     * Log file path
     */
    private static $log_file = null;
    
    /**
     * Maximum log file size (5MB)
     */
    const MAX_LOG_SIZE = 5242880;
    
    /**
     * Maximum number of log files to keep
     */
    const MAX_LOG_FILES = 5;
    
    /**
     * Initialize logger
     */
    public static function init() {
        if (is_null(self::$log_file)) {
            $upload_dir = wp_upload_dir();
            $log_dir = $upload_dir['basedir'] . '/aaiseo-logs';
            
            // Create log directory if it doesn't exist
            if (!file_exists($log_dir)) {
                wp_mkdir_p($log_dir);
                
                // Add .htaccess to protect log files
                $htaccess_content = "Order deny,allow\nDeny from all\n";
                file_put_contents($log_dir . '/.htaccess', $htaccess_content);
            }
            
            self::$log_file = $log_dir . '/aaiseo.log';
        }
    }
    
    /**
     * Log a message
     *
     * @param string $level Log level
     * @param string $message Log message
     * @param array $context Additional context data
     */
    public static function log($level, $message, $context = array()) {
        // Only log if debugging is enabled or it's an error/warning
        if (!self::should_log($level)) {
            return;
        }
        
        self::init();
        
        // Rotate log file if it's too large
        self::rotate_log_if_needed();
        
        // Format the log entry
        $timestamp = current_time('Y-m-d H:i:s');
        $level = strtoupper($level);
        $context_string = !empty($context) ? ' ' . wp_json_encode($context) : '';
        
        $log_entry = "[{$timestamp}] {$level}: {$message}{$context_string}" . PHP_EOL;
        
        // Write to log file
        error_log($log_entry, 3, self::$log_file);
        
        // Also log to WordPress debug log if WP_DEBUG is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log("AAISEO {$level}: {$message}");
        }
    }
    
    /**
     * Log emergency message
     *
     * @param string $message Log message
     * @param array $context Additional context data
     */
    public static function emergency($message, $context = array()) {
        self::log(self::EMERGENCY, $message, $context);
    }
    
    /**
     * Log alert message
     *
     * @param string $message Log message
     * @param array $context Additional context data
     */
    public static function alert($message, $context = array()) {
        self::log(self::ALERT, $message, $context);
    }
    
    /**
     * Log critical message
     *
     * @param string $message Log message
     * @param array $context Additional context data
     */
    public static function critical($message, $context = array()) {
        self::log(self::CRITICAL, $message, $context);
    }
    
    /**
     * Log error message
     *
     * @param string $message Log message
     * @param array $context Additional context data
     */
    public static function error($message, $context = array()) {
        self::log(self::ERROR, $message, $context);
    }
    
    /**
     * Log warning message
     *
     * @param string $message Log message
     * @param array $context Additional context data
     */
    public static function warning($message, $context = array()) {
        self::log(self::WARNING, $message, $context);
    }
    
    /**
     * Log notice message
     *
     * @param string $message Log message
     * @param array $context Additional context data
     */
    public static function notice($message, $context = array()) {
        self::log(self::NOTICE, $message, $context);
    }
    
    /**
     * Log info message
     *
     * @param string $message Log message
     * @param array $context Additional context data
     */
    public static function info($message, $context = array()) {
        self::log(self::INFO, $message, $context);
    }
    
    /**
     * Log debug message
     *
     * @param string $message Log message
     * @param array $context Additional context data
     */
    public static function debug($message, $context = array()) {
        self::log(self::DEBUG, $message, $context);
    }
    
    /**
     * Check if we should log based on level and settings
     *
     * @param string $level Log level
     * @return bool Whether to log
     */
    private static function should_log($level) {
        // Always log errors and warnings
        if (in_array($level, array(self::EMERGENCY, self::ALERT, self::CRITICAL, self::ERROR, self::WARNING))) {
            return true;
        }
        
        // Check if debug logging is enabled
        $debug_enabled = get_option('aaiseo_debug_logging', false);
        if ($debug_enabled) {
            return true;
        }
        
        // Check if WP_DEBUG is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            return true;
        }
        
        return false;
    }
    
    /**
     * Rotate log file if it's too large
     */
    private static function rotate_log_if_needed() {
        if (!file_exists(self::$log_file)) {
            return;
        }
        
        if (filesize(self::$log_file) > self::MAX_LOG_SIZE) {
            self::rotate_log();
        }
    }
    
    /**
     * Rotate log files
     */
    private static function rotate_log() {
        $log_dir = dirname(self::$log_file);
        $log_basename = basename(self::$log_file, '.log');
        
        // Remove oldest log file
        $oldest_log = $log_dir . '/' . $log_basename . '.' . self::MAX_LOG_FILES . '.log';
        if (file_exists($oldest_log)) {
            unlink($oldest_log);
        }
        
        // Rotate existing log files
        for ($i = self::MAX_LOG_FILES - 1; $i >= 1; $i--) {
            $old_file = $log_dir . '/' . $log_basename . '.' . $i . '.log';
            $new_file = $log_dir . '/' . $log_basename . '.' . ($i + 1) . '.log';
            
            if (file_exists($old_file)) {
                rename($old_file, $new_file);
            }
        }
        
        // Move current log to .1
        $first_rotated = $log_dir . '/' . $log_basename . '.1.log';
        rename(self::$log_file, $first_rotated);
    }
    
    /**
     * Get log file contents
     *
     * @param int $lines Number of lines to retrieve (default: 100)
     * @return string Log file contents
     */
    public static function get_log_contents($lines = 100) {
        self::init();
        
        if (!file_exists(self::$log_file)) {
            return '';
        }
        
        // Read last N lines from log file
        $file = new SplFileObject(self::$log_file, 'r');
        $file->seek(PHP_INT_MAX);
        $total_lines = $file->key();
        
        $start_line = max(0, $total_lines - $lines);
        $file->seek($start_line);
        
        $log_contents = '';
        while (!$file->eof()) {
            $log_contents .= $file->fgets();
        }
        
        return $log_contents;
    }
    
    /**
     * Clear log file
     *
     * @return bool Success status
     */
    public static function clear_log() {
        self::init();
        
        if (file_exists(self::$log_file)) {
            return unlink(self::$log_file);
        }
        
        return true;
    }
    
    /**
     * Get log file size
     *
     * @return int File size in bytes
     */
    public static function get_log_size() {
        self::init();
        
        if (file_exists(self::$log_file)) {
            return filesize(self::$log_file);
        }
        
        return 0;
    }
    
    /**
     * Log API request
     *
     * @param string $service API service name
     * @param string $endpoint API endpoint
     * @param array $request_data Request data
     * @param array $response_data Response data
     * @param float $duration Request duration in seconds
     */
    public static function log_api_request($service, $endpoint, $request_data = array(), $response_data = array(), $duration = 0) {
        $context = array(
            'service' => $service,
            'endpoint' => $endpoint,
            'request_size' => strlen(wp_json_encode($request_data)),
            'response_size' => strlen(wp_json_encode($response_data)),
            'duration' => $duration,
            'memory_usage' => memory_get_usage(true)
        );
        
        self::info("API Request: {$service} - {$endpoint}", $context);
    }
    
    /**
     * Log SEO analysis
     *
     * @param int $post_id Post ID
     * @param array $analysis_results Analysis results
     * @param float $duration Analysis duration
     */
    public static function log_seo_analysis($post_id, $analysis_results, $duration = 0) {
        $context = array(
            'post_id' => $post_id,
            'score' => isset($analysis_results['score']) ? $analysis_results['score'] : 0,
            'issues_found' => isset($analysis_results['issues']) ? count($analysis_results['issues']) : 0,
            'duration' => $duration,
            'memory_usage' => memory_get_usage(true)
        );
        
        self::info("SEO Analysis completed for post {$post_id}", $context);
    }
    
    /**
     * Log performance metrics
     *
     * @param string $operation Operation name
     * @param float $duration Duration in seconds
     * @param array $additional_data Additional metrics
     */
    public static function log_performance($operation, $duration, $additional_data = array()) {
        $context = array_merge(array(
            'operation' => $operation,
            'duration' => $duration,
            'memory_usage' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true)
        ), $additional_data);
        
        self::debug("Performance: {$operation}", $context);
    }
    
    /**
     * Log database query
     *
     * @param string $query SQL query
     * @param float $duration Query duration
     * @param int $rows_affected Number of rows affected
     */
    public static function log_database_query($query, $duration = 0, $rows_affected = 0) {
        $context = array(
            'query' => $query,
            'duration' => $duration,
            'rows_affected' => $rows_affected,
            'memory_usage' => memory_get_usage(true)
        );
        
        self::debug("Database Query", $context);
    }
}

