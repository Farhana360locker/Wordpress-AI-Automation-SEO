<?php
/**
 * Utility Class
 * 
 * @package Autonomous_AI_SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Utility functions class
 */
class AAISEO_Utils {
    
    /**
     * Sanitize and validate URL
     */
    public static function sanitize_url($url) {
        $url = esc_url_raw($url);
        return filter_var($url, FILTER_VALIDATE_URL) ? $url : '';
    }
    
    /**
     * Calculate reading time
     */
    public static function calculate_reading_time($content) {
        $word_count = str_word_count(strip_tags($content));
        $reading_speed = 200; // Average words per minute
        return ceil($word_count / $reading_speed);
    }
    
    /**
     * Calculate Flesch Reading Ease score
     */
    public static function calculate_flesch_score($content) {
        $text = strip_tags($content);
        $sentences = preg_split('/[.!?]+/', $text, -1, PREG_SPLIT_NO_EMPTY);
        $words = str_word_count($text);
        $syllables = self::count_syllables($text);
        
        if ($sentences === false || $words === 0 || count($sentences) === 0) {
            return 0;
        }
        
        $avg_sentence_length = $words / count($sentences);
        $avg_syllables_per_word = $syllables / $words;
        
        $score = 206.835 - (1.015 * $avg_sentence_length) - (84.6 * $avg_syllables_per_word);
        
        return max(0, min(100, round($score, 1)));
    }
    
    /**
     * Count syllables in text
     */
    private static function count_syllables($text) {
        $text = strtolower($text);
        $text = preg_replace('/[^a-z]/', ' ', $text);
        $words = array_filter(explode(' ', $text));
        
        $syllable_count = 0;
        foreach ($words as $word) {
            $syllable_count += self::count_word_syllables($word);
        }
        
        return $syllable_count;
    }
    
    /**
     * Count syllables in a single word
     */
    private static function count_word_syllables($word) {
        $word = strtolower($word);
        $vowels = 'aeiouy';
        $syllables = 0;
        $prev_was_vowel = false;
        
        for ($i = 0; $i < strlen($word); $i++) {
            $is_vowel = strpos($vowels, $word[$i]) !== false;
            if ($is_vowel && !$prev_was_vowel) {
                $syllables++;
            }
            $prev_was_vowel = $is_vowel;
        }
        
        // Handle silent 'e'
        if (substr($word, -1) === 'e' && $syllables > 1) {
            $syllables--;
        }
        
        return max(1, $syllables);
    }
    
    /**
     * Extract keywords from content
     */
    public static function extract_keywords($content, $limit = 10) {
        $text = strtolower(strip_tags($content));
        $text = preg_replace('/[^a-z0-9\s]/', ' ', $text);
        
        // Remove common stop words
        $stop_words = array(
            'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
            'from', 'up', 'about', 'into', 'through', 'during', 'before', 'after', 'above',
            'below', 'between', 'among', 'is', 'are', 'was', 'were', 'be', 'been', 'being',
            'have', 'has', 'had', 'do', 'does', 'did', 'will', 'would', 'could', 'should',
            'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those', 'i', 'you',
            'he', 'she', 'it', 'we', 'they', 'me', 'him', 'her', 'us', 'them', 'my',
            'your', 'his', 'her', 'its', 'our', 'their', 'a', 'an'
        );
        
        $words = array_filter(explode(' ', $text));
        $word_freq = array();
        
        foreach ($words as $word) {
            $word = trim($word);
            if (strlen($word) > 2 && !in_array($word, $stop_words)) {
                $word_freq[$word] = isset($word_freq[$word]) ? $word_freq[$word] + 1 : 1;
            }
        }
        
        arsort($word_freq);
        return array_slice(array_keys($word_freq), 0, $limit);
    }
    
    /**
     * Generate excerpt
     */
    public static function generate_excerpt($content, $length = 155) {
        $text = strip_tags($content);
        $text = preg_replace('/\s+/', ' ', $text);
        
        if (strlen($text) <= $length) {
            return $text;
        }
        
        $excerpt = substr($text, 0, $length);
        $last_space = strrpos($excerpt, ' ');
        
        if ($last_space !== false) {
            $excerpt = substr($excerpt, 0, $last_space);
        }
        
        return $excerpt . '...';
    }
    
    /**
     * Format file size
     */
    public static function format_file_size($bytes) {
        $units = array('B', 'KB', 'MB', 'GB', 'TB');
        
        for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
            $bytes /= 1024;
        }
        
        return round($bytes, 2) . ' ' . $units[$i];
    }
    
    /**
     * Get domain from URL
     */
    public static function get_domain($url) {
        $parsed = parse_url($url);
        return isset($parsed['host']) ? $parsed['host'] : '';
    }
    
    /**
     * Check if URL is internal
     */
    public static function is_internal_url($url) {
        $site_domain = self::get_domain(home_url());
        $url_domain = self::get_domain($url);
        
        return $site_domain === $url_domain;
    }
    
    /**
     * Generate random string
     */
    public static function generate_random_string($length = 10) {
        $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $string = '';
        
        for ($i = 0; $i < $length; $i++) {
            $string .= $characters[rand(0, strlen($characters) - 1)];
        }
        
        return $string;
    }
    
    /**
     * Validate email
     */
    public static function validate_email($email) {
        return filter_var($email, FILTER_VALIDATE_EMAIL) !== false;
    }
    
    /**
     * Get user IP address
     */
    public static function get_user_ip() {
        $ip_keys = array('HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR');
        
        foreach ($ip_keys as $key) {
            if (array_key_exists($key, $_SERVER) === true) {
                foreach (explode(',', $_SERVER[$key]) as $ip) {
                    $ip = trim($ip);
                    if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE) !== false) {
                        return $ip;
                    }
                }
            }
        }
        
        return isset($_SERVER['REMOTE_ADDR']) ? $_SERVER['REMOTE_ADDR'] : '0.0.0.0';
    }
    
    /**
     * Convert array to CSV
     */
    public static function array_to_csv($array, $filename = 'export.csv') {
        if (empty($array)) {
            return false;
        }
        
        $output = fopen('php://temp', 'w');
        
        // Add headers
        fputcsv($output, array_keys($array[0]));
        
        // Add data
        foreach ($array as $row) {
            fputcsv($output, $row);
        }
        
        rewind($output);
        $csv = stream_get_contents($output);
        fclose($output);
        
        return $csv;
    }
    
    /**
     * Log debug information
     */
    public static function debug_log($message, $data = null) {
        if (!WP_DEBUG || !WP_DEBUG_LOG) {
            return;
        }
        
        $log_message = '[AAISEO] ' . $message;
        
        if ($data !== null) {
            $log_message .= ' | Data: ' . print_r($data, true);
        }
        
        error_log($log_message);
    }
    
    /**
     * Check if plugin is in development mode
     */
    public static function is_development_mode() {
        return defined('AAISEO_DEV_MODE') && AAISEO_DEV_MODE;
    }
    
    /**
     * Get plugin version
     */
    public static function get_plugin_version() {
        return defined('AAISEO_VERSION') ? AAISEO_VERSION : '1.0.0';
    }
    
    /**
     * Check WordPress version compatibility
     */
    public static function check_wp_version($min_version = '5.0') {
        global $wp_version;
        return version_compare($wp_version, $min_version, '>=');
    }
    
    /**
     * Check PHP version compatibility
     */
    public static function check_php_version($min_version = '7.4') {
        return version_compare(PHP_VERSION, $min_version, '>=');
    }
}

