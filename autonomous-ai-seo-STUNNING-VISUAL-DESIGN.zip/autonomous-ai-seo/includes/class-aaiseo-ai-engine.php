<?php
/**
 * AI Engine for Autonomous AI SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_AI_Engine {
    
    /**
     * OpenAI API endpoint
     */
    private $openai_endpoint = 'https://api.openai.com/v1/chat/completions';
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize AI Engine
     */
    public function init() {
        // Hook into content analysis
        add_action('save_post', array($this, 'analyze_content_on_save'), 10, 2);
    }
    
    /**
     * Analyze content using AI
     */
    public function analyze_content($content, $title = '', $meta_description = '') {
        $api_key = get_option('aaiseo_openai_api_key');
        
        if (empty($api_key)) {
            return array(
                'error' => __('OpenAI API key not configured', 'autonomous-ai-seo')
            );
        }
        
        $prompt = $this->build_analysis_prompt($content, $title, $meta_description);
        
        $response = $this->call_openai_api($prompt, $api_key);
        
        if (is_wp_error($response)) {
            return array(
                'error' => $response->get_error_message()
            );
        }
        
        return $this->parse_ai_response($response);
    }
    
    /**
     * Generate meta description using AI
     */
    public function generate_meta_description($content, $title = '') {
        $api_key = get_option('aaiseo_openai_api_key');
        
        if (empty($api_key)) {
            return '';
        }
        
        $prompt = "Based on the following content and title, generate an SEO-optimized meta description (150-160 characters):\n\n";
        $prompt .= "Title: " . $title . "\n\n";
        $prompt .= "Content: " . wp_strip_all_tags(substr($content, 0, 1000)) . "\n\n";
        $prompt .= "Generate only the meta description, no additional text.";
        
        $response = $this->call_openai_api($prompt, $api_key);
        
        if (is_wp_error($response)) {
            return '';
        }
        
        $result = $this->parse_simple_response($response);
        return substr($result, 0, 160);
    }
    
    /**
     * Generate SEO title using AI
     */
    public function generate_seo_title($content, $current_title = '') {
        $api_key = get_option('aaiseo_openai_api_key');
        
        if (empty($api_key)) {
            return $current_title;
        }
        
        $prompt = "Based on the following content, generate an SEO-optimized title (50-60 characters):\n\n";
        $prompt .= "Current title: " . $current_title . "\n\n";
        $prompt .= "Content: " . wp_strip_all_tags(substr($content, 0, 1000)) . "\n\n";
        $prompt .= "Generate only the optimized title, no additional text.";
        
        $response = $this->call_openai_api($prompt, $api_key);
        
        if (is_wp_error($response)) {
            return $current_title;
        }
        
        $result = $this->parse_simple_response($response);
        return substr($result, 0, 60);
    }
    
    /**
     * Analyze keyword density
     */
    public function analyze_keyword_density($content, $target_keyword = '') {
        $content = wp_strip_all_tags(strtolower($content));
        $words = str_word_count($content, 1);
        $total_words = count($words);
        
        if ($total_words === 0) {
            return array(
                'total_words' => 0,
                'keyword_count' => 0,
                'density' => 0,
                'recommendation' => __('No content to analyze', 'autonomous-ai-seo')
            );
        }
        
        $keyword_count = 0;
        if (!empty($target_keyword)) {
            $keyword_count = substr_count($content, strtolower($target_keyword));
        }
        
        $density = $total_words > 0 ? ($keyword_count / $total_words) * 100 : 0;
        
        $recommendation = '';
        if ($density < 0.5) {
            $recommendation = __('Keyword density is too low. Consider adding the target keyword more naturally.', 'autonomous-ai-seo');
        } elseif ($density > 3) {
            $recommendation = __('Keyword density is too high. Reduce keyword usage to avoid over-optimization.', 'autonomous-ai-seo');
        } else {
            $recommendation = __('Keyword density is optimal.', 'autonomous-ai-seo');
        }
        
        return array(
            'total_words' => $total_words,
            'keyword_count' => $keyword_count,
            'density' => round($density, 2),
            'recommendation' => $recommendation
        );
    }
    
    /**
     * Calculate readability score
     */
    public function calculate_readability_score($content) {
        $content = wp_strip_all_tags($content);
        
        // Count sentences
        $sentences = preg_split('/[.!?]+/', $content, -1, PREG_SPLIT_NO_EMPTY);
        $sentence_count = count($sentences);
        
        // Count words
        $words = str_word_count($content, 1);
        $word_count = count($words);
        
        // Count syllables (simplified)
        $syllable_count = 0;
        foreach ($words as $word) {
            $syllable_count += $this->count_syllables($word);
        }
        
        if ($sentence_count === 0 || $word_count === 0) {
            return array(
                'score' => 0,
                'level' => __('No content', 'autonomous-ai-seo'),
                'recommendation' => __('Add content to analyze readability', 'autonomous-ai-seo')
            );
        }
        
        // Flesch Reading Ease Score
        $avg_sentence_length = $word_count / $sentence_count;
        $avg_syllables_per_word = $syllable_count / $word_count;
        
        $score = 206.835 - (1.015 * $avg_sentence_length) - (84.6 * $avg_syllables_per_word);
        $score = max(0, min(100, $score));
        
        $level = '';
        $recommendation = '';
        
        if ($score >= 90) {
            $level = __('Very Easy', 'autonomous-ai-seo');
            $recommendation = __('Excellent readability for all audiences.', 'autonomous-ai-seo');
        } elseif ($score >= 80) {
            $level = __('Easy', 'autonomous-ai-seo');
            $recommendation = __('Good readability for most audiences.', 'autonomous-ai-seo');
        } elseif ($score >= 70) {
            $level = __('Fairly Easy', 'autonomous-ai-seo');
            $recommendation = __('Readable for average audiences.', 'autonomous-ai-seo');
        } elseif ($score >= 60) {
            $level = __('Standard', 'autonomous-ai-seo');
            $recommendation = __('Readable for educated audiences.', 'autonomous-ai-seo');
        } elseif ($score >= 50) {
            $level = __('Fairly Difficult', 'autonomous-ai-seo');
            $recommendation = __('Consider simplifying sentences and vocabulary.', 'autonomous-ai-seo');
        } elseif ($score >= 30) {
            $level = __('Difficult', 'autonomous-ai-seo');
            $recommendation = __('Simplify content for better readability.', 'autonomous-ai-seo');
        } else {
            $level = __('Very Difficult', 'autonomous-ai-seo');
            $recommendation = __('Content is too complex. Significantly simplify language and structure.', 'autonomous-ai-seo');
        }
        
        return array(
            'score' => round($score, 1),
            'level' => $level,
            'recommendation' => $recommendation,
            'word_count' => $word_count,
            'sentence_count' => $sentence_count,
            'avg_sentence_length' => round($avg_sentence_length, 1),
            'avg_syllables_per_word' => round($avg_syllables_per_word, 1)
        );
    }
    
    /**
     * Generate content suggestions
     */
    public function generate_content_suggestions($content, $target_keyword = '') {
        $api_key = get_option('aaiseo_openai_api_key');
        
        if (empty($api_key)) {
            return array();
        }
        
        $prompt = "Analyze the following content and provide SEO improvement suggestions:\n\n";
        $prompt .= "Target keyword: " . $target_keyword . "\n\n";
        $prompt .= "Content: " . wp_strip_all_tags(substr($content, 0, 2000)) . "\n\n";
        $prompt .= "Provide 5 specific, actionable SEO improvement suggestions in JSON format with 'suggestion' and 'priority' (high/medium/low) fields.";
        
        $response = $this->call_openai_api($prompt, $api_key);
        
        if (is_wp_error($response)) {
            return array();
        }
        
        return $this->parse_suggestions_response($response);
    }
    
    /**
     * Analyze content when post is saved
     */
    public function analyze_content_on_save($post_id, $post) {
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }
        
        if (!get_option('aaiseo_auto_optimize')) {
            return;
        }
        
        $content = $post->post_content;
        $title = $post->post_title;
        
        // Run analysis
        $analysis = $this->analyze_content($content, $title);
        
        // Store results
        if (!isset($analysis['error'])) {
            $core = new AAISEO_Core();
            $core->store_audit_results(
                $post_id,
                'ai_content_analysis',
                isset($analysis['score']) ? $analysis['score'] : 0,
                isset($analysis['issues']) ? $analysis['issues'] : array(),
                isset($analysis['recommendations']) ? $analysis['recommendations'] : array()
            );
        }
    }
    
    /**
     * Build analysis prompt
     */
    private function build_analysis_prompt($content, $title, $meta_description) {
        $prompt = "Analyze the following content for SEO optimization and provide a detailed report:\n\n";
        $prompt .= "Title: " . $title . "\n\n";
        $prompt .= "Meta Description: " . $meta_description . "\n\n";
        $prompt .= "Content: " . wp_strip_all_tags(substr($content, 0, 3000)) . "\n\n";
        $prompt .= "Provide analysis in JSON format with the following structure:\n";
        $prompt .= "{\n";
        $prompt .= "  \"score\": (0-100),\n";
        $prompt .= "  \"issues\": [\"issue1\", \"issue2\"],\n";
        $prompt .= "  \"recommendations\": [\"rec1\", \"rec2\"],\n";
        $prompt .= "  \"keyword_suggestions\": [\"keyword1\", \"keyword2\"],\n";
        $prompt .= "  \"content_gaps\": [\"gap1\", \"gap2\"]\n";
        $prompt .= "}";
        
        return $prompt;
    }
    
    /**
     * Call OpenAI API
     */
    private function call_openai_api($prompt, $api_key) {
        $headers = array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type' => 'application/json'
        );
        
        $body = array(
            'model' => 'gpt-3.5-turbo',
            'messages' => array(
                array(
                    'role' => 'user',
                    'content' => $prompt
                )
            ),
            'max_tokens' => 1000,
            'temperature' => 0.7
        );
        
        $response = wp_remote_post($this->openai_endpoint, array(
            'headers' => $headers,
            'body' => json_encode($body),
            'timeout' => 30
        ));
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            return new WP_Error('api_error', 'OpenAI API returned error: ' . $response_code);
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!isset($data['choices'][0]['message']['content'])) {
            return new WP_Error('api_error', 'Invalid API response format');
        }
        
        return $data['choices'][0]['message']['content'];
    }
    
    /**
     * Parse AI response
     */
    private function parse_ai_response($response) {
        $data = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE) {
            return array(
                'score' => 50,
                'issues' => array(__('Unable to parse AI response', 'autonomous-ai-seo')),
                'recommendations' => array(__('Please try again later', 'autonomous-ai-seo')),
                'keyword_suggestions' => array(),
                'content_gaps' => array()
            );
        }
        
        return array(
            'score' => isset($data['score']) ? intval($data['score']) : 50,
            'issues' => isset($data['issues']) ? $data['issues'] : array(),
            'recommendations' => isset($data['recommendations']) ? $data['recommendations'] : array(),
            'keyword_suggestions' => isset($data['keyword_suggestions']) ? $data['keyword_suggestions'] : array(),
            'content_gaps' => isset($data['content_gaps']) ? $data['content_gaps'] : array()
        );
    }
    
    /**
     * Parse simple response
     */
    private function parse_simple_response($response) {
        return trim($response);
    }
    
    /**
     * Parse suggestions response
     */
    private function parse_suggestions_response($response) {
        $data = json_decode($response, true);
        
        if (json_last_error() !== JSON_ERROR_NONE || !is_array($data)) {
            return array();
        }
        
        return $data;
    }
    
    /**
     * Count syllables in a word (simplified)
     */
    private function count_syllables($word) {
        $word = strtolower($word);
        $syllables = 0;
        $vowels = array('a', 'e', 'i', 'o', 'u', 'y');
        $previous_was_vowel = false;
        
        for ($i = 0; $i < strlen($word); $i++) {
            $is_vowel = in_array($word[$i], $vowels);
            if ($is_vowel && !$previous_was_vowel) {
                $syllables++;
            }
            $previous_was_vowel = $is_vowel;
        }
        
        // Handle silent e
        if (substr($word, -1) === 'e' && $syllables > 1) {
            $syllables--;
        }
        
        return max(1, $syllables);
    }
}

