<?php
/**
 * Advanced Link Builder for Autonomous AI SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Link_Builder {
    
    /**
     * Link building strategies
     */
    private $strategies = array();
    
    /**
     * Internal linking rules
     */
    private $internal_linking_rules = array();
    
    /**
     * Anchor text variations
     */
    private $anchor_variations = array();
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize link builder
     */
    public function init() {
        // Initialize strategies
        $this->init_link_strategies();
        
        // Initialize internal linking rules
        $this->init_internal_linking_rules();
        
        // Hook into content processing
        add_filter('the_content', array($this, 'process_internal_links'), 20);
        add_action('save_post', array($this, 'analyze_link_opportunities'), 10, 2);
        
        // Admin hooks
        add_action('wp_ajax_aaiseo_find_link_opportunities', array($this, 'ajax_find_link_opportunities'));
        add_action('wp_ajax_aaiseo_build_internal_links', array($this, 'ajax_build_internal_links'));
        add_action('wp_ajax_aaiseo_analyze_backlinks', array($this, 'ajax_analyze_backlinks'));
        add_action('wp_ajax_aaiseo_suggest_outreach', array($this, 'ajax_suggest_outreach'));
        
        // Cron hooks
        add_action('aaiseo_daily_link_analysis', array($this, 'run_daily_link_analysis'));
        add_action('aaiseo_weekly_backlink_check', array($this, 'run_weekly_backlink_check'));
    }
    
    /**
     * Initialize link building strategies
     */
    private function init_link_strategies() {
        $this->strategies = array(
            'internal_linking' => array(
                'name' => __('Internal Linking', 'autonomous-ai-seo'),
                'description' => __('Automatically create internal links between related content', 'autonomous-ai-seo'),
                'priority' => 'high',
                'automated' => true
            ),
            'broken_link_building' => array(
                'name' => __('Broken Link Building', 'autonomous-ai-seo'),
                'description' => __('Find broken links on other sites and suggest your content as replacement', 'autonomous-ai-seo'),
                'priority' => 'high',
                'automated' => false
            ),
            'resource_page_outreach' => array(
                'name' => __('Resource Page Outreach', 'autonomous-ai-seo'),
                'description' => __('Find resource pages in your niche and request inclusion', 'autonomous-ai-seo'),
                'priority' => 'medium',
                'automated' => false
            ),
            'guest_posting' => array(
                'name' => __('Guest Posting', 'autonomous-ai-seo'),
                'description' => __('Identify guest posting opportunities on relevant sites', 'autonomous-ai-seo'),
                'priority' => 'medium',
                'automated' => false
            ),
            'competitor_backlinks' => array(
                'name' => __('Competitor Backlink Analysis', 'autonomous-ai-seo'),
                'description' => __('Analyze competitor backlinks and find similar opportunities', 'autonomous-ai-seo'),
                'priority' => 'high',
                'automated' => false
            ),
            'unlinked_mentions' => array(
                'name' => __('Unlinked Mentions', 'autonomous-ai-seo'),
                'description' => __('Find mentions of your brand without links and request linking', 'autonomous-ai-seo'),
                'priority' => 'medium',
                'automated' => false
            ),
            'skyscraper_technique' => array(
                'name' => __('Skyscraper Technique', 'autonomous-ai-seo'),
                'description' => __('Create better content than competitors and reach out to their linkers', 'autonomous-ai-seo'),
                'priority' => 'high',
                'automated' => false
            )
        );
    }
    
    /**
     * Initialize internal linking rules
     */
    private function init_internal_linking_rules() {
        $this->internal_linking_rules = array(
            'max_links_per_post' => 10,
            'min_content_length' => 300,
            'max_anchor_length' => 60,
            'avoid_over_optimization' => true,
            'link_to_related_content' => true,
            'link_to_cornerstone_content' => true,
            'avoid_linking_to_same_page' => true,
            'prefer_exact_keyword_match' => false,
            'use_varied_anchor_text' => true,
            'link_density_threshold' => 0.02 // 2% of content
        );
        
        // Allow filtering of rules
        $this->internal_linking_rules = apply_filters('aaiseo_internal_linking_rules', $this->internal_linking_rules);
    }
    
    /**
     * Process internal links in content
     */
    public function process_internal_links($content) {
        if (!is_singular() || is_admin()) {
            return $content;
        }
        
        global $post;
        
        // Skip if internal linking is disabled
        if (!get_option('aaiseo_auto_internal_linking', 1)) {
            return $content;
        }
        
        // Skip if post is excluded
        if (get_post_meta($post->ID, '_aaiseo_exclude_internal_linking', true)) {
            return $content;
        }
        
        // Find and add internal links
        $enhanced_content = $this->add_internal_links($content, $post->ID);
        
        return $enhanced_content;
    }
    
    /**
     * Add internal links to content
     */
    public function add_internal_links($content, $post_id) {
        // Get link opportunities
        $opportunities = $this->find_internal_link_opportunities($content, $post_id);
        
        if (empty($opportunities)) {
            return $content;
        }
        
        // Sort by relevance score
        usort($opportunities, function($a, $b) {
            return $b['relevance_score'] <=> $a['relevance_score'];
        });
        
        // Apply linking rules
        $opportunities = $this->apply_linking_rules($opportunities, $content);
        
        // Add links to content
        $enhanced_content = $content;
        $links_added = 0;
        $max_links = $this->internal_linking_rules['max_links_per_post'];
        
        foreach ($opportunities as $opportunity) {
            if ($links_added >= $max_links) {
                break;
            }
            
            $enhanced_content = $this->insert_link($enhanced_content, $opportunity);
            $links_added++;
        }
        
        // Log internal linking activity
        $this->log_internal_linking_activity($post_id, $links_added, $opportunities);
        
        return $enhanced_content;
    }
    
    /**
     * Find internal link opportunities
     */
    private function find_internal_link_opportunities($content, $current_post_id) {
        $opportunities = array();
        
        // Extract keywords and phrases from content
        $keywords = $this->extract_linkable_keywords($content);
        
        foreach ($keywords as $keyword) {
            // Find related posts
            $related_posts = $this->find_related_posts($keyword, $current_post_id);
            
            foreach ($related_posts as $related_post) {
                $opportunities[] = array(
                    'keyword' => $keyword,
                    'target_post_id' => $related_post['ID'],
                    'target_url' => get_permalink($related_post['ID']),
                    'target_title' => $related_post['post_title'],
                    'relevance_score' => $related_post['relevance_score'],
                    'anchor_text' => $this->generate_anchor_text($keyword, $related_post),
                    'context' => $this->get_keyword_context($content, $keyword)
                );
            }
        }
        
        return $opportunities;
    }
    
    /**
     * Extract linkable keywords from content
     */
    private function extract_linkable_keywords($content) {
        $keywords = array();
        
        // Remove HTML tags
        $text = wp_strip_all_tags($content);
        
        // Extract noun phrases (simplified)
        $sentences = preg_split('/[.!?]+/', $text);
        
        foreach ($sentences as $sentence) {
            $words = preg_split('/\s+/', trim($sentence));
            
            // Extract 1-4 word phrases
            for ($i = 0; $i < count($words); $i++) {
                for ($length = 1; $length <= 4 && ($i + $length) <= count($words); $length++) {
                    $phrase = implode(' ', array_slice($words, $i, $length));
                    $phrase = trim(preg_replace('/[^\w\s]/', '', $phrase));
                    
                    if (strlen($phrase) >= 3 && strlen($phrase) <= 60) {
                        $keywords[] = $phrase;
                    }
                }
            }
        }
        
        // Remove duplicates and common words
        $keywords = array_unique($keywords);
        $keywords = $this->filter_common_words($keywords);
        
        // Limit to most relevant keywords
        return array_slice($keywords, 0, 50);
    }
    
    /**
     * Find related posts for keyword
     */
    private function find_related_posts($keyword, $current_post_id) {
        global $wpdb;
        
        // Search in post titles and content
        $search_query = $wpdb->prepare("
            SELECT ID, post_title, post_content,
                   MATCH(post_title, post_content) AGAINST(%s IN NATURAL LANGUAGE MODE) as relevance_score
            FROM {$wpdb->posts}
            WHERE post_status = 'publish'
            AND post_type IN ('post', 'page')
            AND ID != %d
            AND MATCH(post_title, post_content) AGAINST(%s IN NATURAL LANGUAGE MODE) > 0
            ORDER BY relevance_score DESC
            LIMIT 10
        ", $keyword, $current_post_id, $keyword);
        
        $results = $wpdb->get_results($search_query, ARRAY_A);
        
        // Filter by minimum relevance score
        $filtered_results = array();
        foreach ($results as $result) {
            if ($result['relevance_score'] > 0.5) {
                $filtered_results[] = $result;
            }
        }
        
        return $filtered_results;
    }
    
    /**
     * Generate anchor text for link
     */
    private function generate_anchor_text($keyword, $target_post) {
        $variations = array(
            $keyword,
            $target_post['post_title'],
            $this->get_post_focus_keyword($target_post['ID']),
            $this->create_natural_anchor($keyword, $target_post['post_title'])
        );
        
        // Filter out empty values
        $variations = array_filter($variations);
        
        // Remove duplicates
        $variations = array_unique($variations);
        
        // Choose variation based on rules
        if ($this->internal_linking_rules['use_varied_anchor_text']) {
            return $this->select_varied_anchor($variations, $target_post['ID']);
        }
        
        return $variations[0];
    }
    
    /**
     * Create natural anchor text
     */
    private function create_natural_anchor($keyword, $title) {
        $natural_phrases = array(
            'learn more about ' . $keyword,
            'read our guide on ' . $keyword,
            'check out our ' . $keyword . ' article',
            'discover ' . $keyword,
            'explore ' . $keyword
        );
        
        return $natural_phrases[array_rand($natural_phrases)];
    }
    
    /**
     * Apply linking rules to opportunities
     */
    private function apply_linking_rules($opportunities, $content) {
        $filtered_opportunities = array();
        $word_count = str_word_count(wp_strip_all_tags($content));
        
        foreach ($opportunities as $opportunity) {
            // Check content length requirement
            if ($word_count < $this->internal_linking_rules['min_content_length']) {
                continue;
            }
            
            // Check anchor text length
            if (strlen($opportunity['anchor_text']) > $this->internal_linking_rules['max_anchor_length']) {
                continue;
            }
            
            // Check if keyword already has a link
            if ($this->keyword_already_linked($content, $opportunity['keyword'])) {
                continue;
            }
            
            // Check link density
            $current_links = substr_count($content, '<a ');
            $max_links_by_density = floor($word_count * $this->internal_linking_rules['link_density_threshold']);
            
            if ($current_links >= $max_links_by_density) {
                continue;
            }
            
            $filtered_opportunities[] = $opportunity;
        }
        
        return $filtered_opportunities;
    }
    
    /**
     * Insert link into content
     */
    private function insert_link($content, $opportunity) {
        $keyword = $opportunity['keyword'];
        $url = $opportunity['target_url'];
        $anchor_text = $opportunity['anchor_text'];
        $title = $opportunity['target_title'];
        
        // Create link HTML
        $link_html = sprintf(
            '<a href="%s" title="%s" class="aaiseo-internal-link">%s</a>',
            esc_url($url),
            esc_attr($title),
            esc_html($anchor_text)
        );
        
        // Find first occurrence of keyword and replace with link
        $pattern = '/\b' . preg_quote($keyword, '/') . '\b/i';
        $content = preg_replace($pattern, $link_html, $content, 1);
        
        return $content;
    }
    
    /**
     * Check if keyword already has a link
     */
    private function keyword_already_linked($content, $keyword) {
        // Check if keyword appears within existing link tags
        $pattern = '/<a[^>]*>.*?' . preg_quote($keyword, '/') . '.*?<\/a>/i';
        return preg_match($pattern, $content);
    }
    
    /**
     * Analyze link opportunities for post
     */
    public function analyze_link_opportunities($post_id, $post) {
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }
        
        if ($post->post_status !== 'publish') {
            return;
        }
        
        // Analyze internal linking opportunities
        $internal_opportunities = $this->find_internal_link_opportunities($post->post_content, $post_id);
        
        // Analyze external linking opportunities
        $external_opportunities = $this->find_external_link_opportunities($post);
        
        // Store opportunities
        update_post_meta($post_id, '_aaiseo_internal_link_opportunities', $internal_opportunities);
        update_post_meta($post_id, '_aaiseo_external_link_opportunities', $external_opportunities);
        
        // Analyze current backlinks
        $this->analyze_post_backlinks($post_id);
    }
    
    /**
     * Find external link opportunities
     */
    private function find_external_link_opportunities($post) {
        $opportunities = array();
        
        // Extract topics and keywords
        $topics = $this->extract_topics_from_content($post->post_content);
        
        foreach ($topics as $topic) {
            // Find authoritative sources for topic
            $sources = $this->find_authoritative_sources($topic);
            
            foreach ($sources as $source) {
                $opportunities[] = array(
                    'topic' => $topic,
                    'source_url' => $source['url'],
                    'source_title' => $source['title'],
                    'authority_score' => $source['authority_score'],
                    'relevance_score' => $source['relevance_score'],
                    'link_type' => 'reference'
                );
            }
        }
        
        return $opportunities;
    }
    
    /**
     * Find authoritative sources for topic
     */
    private function find_authoritative_sources($topic) {
        // This would typically use external APIs like Ahrefs, SEMrush, or Moz
        // For now, return mock data
        
        $mock_sources = array(
            array(
                'url' => 'https://example.com/authority-source',
                'title' => 'Authoritative Guide to ' . $topic,
                'authority_score' => 85,
                'relevance_score' => 92
            ),
            array(
                'url' => 'https://research.example.com/study',
                'title' => 'Research Study on ' . $topic,
                'authority_score' => 78,
                'relevance_score' => 88
            )
        );
        
        return $mock_sources;
    }
    
    /**
     * Analyze post backlinks
     */
    private function analyze_post_backlinks($post_id) {
        $post_url = get_permalink($post_id);
        
        // This would typically use backlink APIs
        $backlinks = $this->get_backlinks_for_url($post_url);
        
        $analysis = array(
            'total_backlinks' => count($backlinks),
            'referring_domains' => $this->count_referring_domains($backlinks),
            'authority_score' => $this->calculate_authority_score($backlinks),
            'anchor_text_distribution' => $this->analyze_anchor_text_distribution($backlinks),
            'link_quality_score' => $this->calculate_link_quality_score($backlinks)
        );
        
        update_post_meta($post_id, '_aaiseo_backlink_analysis', $analysis);
        
        return $analysis;
    }
    
    /**
     * Get backlinks for URL (mock implementation)
     */
    private function get_backlinks_for_url($url) {
        // This would use external APIs in real implementation
        return array(
            array(
                'source_url' => 'https://example.com/page1',
                'source_domain' => 'example.com',
                'anchor_text' => 'great resource',
                'authority_score' => 65,
                'follow' => true,
                'first_seen' => '2024-01-15'
            ),
            array(
                'source_url' => 'https://blog.example.org/post',
                'source_domain' => 'blog.example.org',
                'anchor_text' => 'click here',
                'authority_score' => 45,
                'follow' => true,
                'first_seen' => '2024-02-01'
            )
        );
    }
    
    /**
     * Run daily link analysis
     */
    public function run_daily_link_analysis() {
        // Analyze internal linking structure
        $this->analyze_internal_linking_structure();
        
        // Find new link opportunities
        $this->find_new_link_opportunities();
        
        // Check for broken internal links
        $this->check_broken_internal_links();
        
        // Update link metrics
        $this->update_link_metrics();
    }
    
    /**
     * Analyze internal linking structure
     */
    private function analyze_internal_linking_structure() {
        global $wpdb;
        
        // Get all published posts
        $posts = $wpdb->get_results("
            SELECT ID, post_title, post_content 
            FROM {$wpdb->posts} 
            WHERE post_status = 'publish' 
            AND post_type IN ('post', 'page')
        ");
        
        $link_graph = array();
        $orphaned_pages = array();
        $hub_pages = array();
        
        foreach ($posts as $post) {
            $internal_links = $this->extract_internal_links($post->post_content);
            $link_graph[$post->ID] = $internal_links;
            
            // Identify orphaned pages (no internal links pointing to them)
            $incoming_links = $this->count_incoming_internal_links($post->ID, $posts);
            if ($incoming_links === 0) {
                $orphaned_pages[] = $post->ID;
            }
            
            // Identify hub pages (many outgoing links)
            if (count($internal_links) > 10) {
                $hub_pages[] = array(
                    'post_id' => $post->ID,
                    'outgoing_links' => count($internal_links)
                );
            }
        }
        
        // Store analysis results
        update_option('aaiseo_internal_link_graph', $link_graph);
        update_option('aaiseo_orphaned_pages', $orphaned_pages);
        update_option('aaiseo_hub_pages', $hub_pages);
    }
    
    /**
     * Extract internal links from content
     */
    private function extract_internal_links($content) {
        $internal_links = array();
        $site_url = home_url();
        
        preg_match_all('/<a[^>]+href=["\']([^"\']+)["\'][^>]*>/i', $content, $matches);
        
        foreach ($matches[1] as $url) {
            if (strpos($url, $site_url) === 0) {
                $post_id = url_to_postid($url);
                if ($post_id) {
                    $internal_links[] = $post_id;
                }
            }
        }
        
        return array_unique($internal_links);
    }
    
    /**
     * Count incoming internal links for post
     */
    private function count_incoming_internal_links($post_id, $all_posts) {
        $count = 0;
        $target_url = get_permalink($post_id);
        
        foreach ($all_posts as $post) {
            if ($post->ID === $post_id) {
                continue;
            }
            
            if (strpos($post->post_content, $target_url) !== false) {
                $count++;
            }
        }
        
        return $count;
    }
    
    /**
     * AJAX: Find link opportunities
     */
    public function ajax_find_link_opportunities() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        $post_id = intval($_POST['post_id']);
        $post = get_post($post_id);
        
        if (!$post) {
            wp_send_json_error('Post not found');
        }
        
        $opportunities = $this->find_internal_link_opportunities($post->post_content, $post_id);
        
        wp_send_json_success(array(
            'internal_opportunities' => array_slice($opportunities, 0, 10),
            'total_opportunities' => count($opportunities)
        ));
    }
    
    /**
     * AJAX: Build internal links
     */
    public function ajax_build_internal_links() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        $post_id = intval($_POST['post_id']);
        $post = get_post($post_id);
        
        if (!$post) {
            wp_send_json_error('Post not found');
        }
        
        $enhanced_content = $this->add_internal_links($post->post_content, $post_id);
        
        // Update post content
        wp_update_post(array(
            'ID' => $post_id,
            'post_content' => $enhanced_content
        ));
        
        wp_send_json_success(array(
            'message' => __('Internal links added successfully', 'autonomous-ai-seo'),
            'enhanced_content' => $enhanced_content
        ));
    }
    
    /**
     * Filter common words from keywords
     */
    private function filter_common_words($keywords) {
        $common_words = array(
            'the', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
            'this', 'that', 'these', 'those', 'a', 'an', 'is', 'are', 'was', 'were',
            'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did', 'will',
            'would', 'could', 'should', 'may', 'might', 'must', 'can', 'shall'
        );
        
        return array_filter($keywords, function($keyword) use ($common_words) {
            $words = explode(' ', strtolower($keyword));
            return !in_array($words[0], $common_words) && count($words) <= 4;
        });
    }
    
    /**
     * Get post focus keyword
     */
    private function get_post_focus_keyword($post_id) {
        // Try various SEO plugin meta keys
        $focus_keyword = get_post_meta($post_id, '_yoast_wpseo_focuskw', true);
        if ($focus_keyword) {
            return $focus_keyword;
        }
        
        $focus_keyword = get_post_meta($post_id, 'rank_math_focus_keyword', true);
        if ($focus_keyword) {
            return $focus_keyword;
        }
        
        $focus_keyword = get_post_meta($post_id, '_aaiseo_focus_keyword', true);
        if ($focus_keyword) {
            return $focus_keyword;
        }
        
        return '';
    }
    
    /**
     * Select varied anchor text
     */
    private function select_varied_anchor($variations, $target_post_id) {
        // Get previously used anchors for this post
        $used_anchors = get_post_meta($target_post_id, '_aaiseo_used_anchors', true);
        if (!is_array($used_anchors)) {
            $used_anchors = array();
        }
        
        // Find unused variation
        foreach ($variations as $variation) {
            if (!in_array($variation, $used_anchors)) {
                $used_anchors[] = $variation;
                update_post_meta($target_post_id, '_aaiseo_used_anchors', $used_anchors);
                return $variation;
            }
        }
        
        // If all variations used, return random one
        return $variations[array_rand($variations)];
    }
    
    /**
     * Get keyword context
     */
    private function get_keyword_context($content, $keyword) {
        $position = stripos($content, $keyword);
        if ($position === false) {
            return '';
        }
        
        $start = max(0, $position - 100);
        $length = 200;
        
        return substr($content, $start, $length);
    }
    
    /**
     * Extract topics from content
     */
    private function extract_topics_from_content($content) {
        // Simple topic extraction - in real implementation would use NLP
        $text = wp_strip_all_tags($content);
        $words = str_word_count($text, 1);
        
        // Get most frequent meaningful words
        $word_freq = array_count_values(array_map('strtolower', $words));
        arsort($word_freq);
        
        $topics = array();
        $count = 0;
        foreach ($word_freq as $word => $freq) {
            if (strlen($word) > 4 && $freq > 2 && $count < 10) {
                $topics[] = $word;
                $count++;
            }
        }
        
        return $topics;
    }
    
    /**
     * Log internal linking activity
     */
    private function log_internal_linking_activity($post_id, $links_added, $opportunities) {
        $activity = array(
            'post_id' => $post_id,
            'links_added' => $links_added,
            'opportunities_found' => count($opportunities),
            'timestamp' => current_time('mysql')
        );
        
        $existing_log = get_option('aaiseo_internal_linking_log', array());
        $existing_log[] = $activity;
        
        // Keep only last 100 entries
        if (count($existing_log) > 100) {
            $existing_log = array_slice($existing_log, -100);
        }
        
        update_option('aaiseo_internal_linking_log', $existing_log);
    }
}

