<?php
/**
 * Dashboard Admin Class
 * 
 * @package Autonomous_AI_SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Dashboard management class
 */
class AAISEO_Dashboard {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('wp_ajax_aaiseo_get_dashboard_data', array($this, 'get_dashboard_data'));
        add_action('wp_ajax_aaiseo_refresh_stats', array($this, 'refresh_stats'));
    }
    
    /**
     * Get dashboard data via AJAX
     */
    public function get_dashboard_data() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'aaiseo_dashboard_nonce')) {
            wp_die('Security check failed');
        }
        
        $data = array(
            'seo_score' => $this->get_overall_seo_score(),
            'total_posts' => $this->get_total_posts_analyzed(),
            'issues_found' => $this->get_issues_count(),
            'improvements' => $this->get_improvements_count(),
            'recent_activity' => $this->get_recent_activity(),
            'top_keywords' => $this->get_top_keywords(),
            'performance_data' => $this->get_performance_data()
        );
        
        wp_send_json_success($data);
    }
    
    /**
     * Get overall SEO score
     */
    private function get_overall_seo_score() {
        global $wpdb;
        
        $table = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        $avg_score = $wpdb->get_var("SELECT AVG(seo_score) FROM $table WHERE seo_score > 0");
        
        return $avg_score ? round($avg_score) : 0;
    }
    
    /**
     * Get total posts analyzed
     */
    private function get_total_posts_analyzed() {
        global $wpdb;
        
        $table = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        return $wpdb->get_var("SELECT COUNT(*) FROM $table");
    }
    
    /**
     * Get issues count
     */
    private function get_issues_count() {
        global $wpdb;
        
        $table = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        return $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE seo_score < 70");
    }
    
    /**
     * Get improvements count
     */
    private function get_improvements_count() {
        global $wpdb;
        
        $table = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        return $wpdb->get_var("SELECT COUNT(*) FROM $table WHERE seo_score >= 80");
    }
    
    /**
     * Get recent activity
     */
    private function get_recent_activity() {
        global $wpdb;
        
        $table = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        $results = $wpdb->get_results("
            SELECT p.post_title, sa.seo_score, sa.last_analyzed 
            FROM $table sa 
            JOIN {$wpdb->posts} p ON sa.post_id = p.ID 
            ORDER BY sa.last_analyzed DESC 
            LIMIT 10
        ");
        
        $activity = array();
        foreach ($results as $result) {
            $activity[] = array(
                'title' => $result->post_title,
                'score' => $result->seo_score,
                'date' => $result->last_analyzed,
                'action' => 'SEO Analysis Completed'
            );
        }
        
        return $activity;
    }
    
    /**
     * Get top keywords
     */
    private function get_top_keywords() {
        global $wpdb;
        
        $table = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'keyword_rankings';
        $results = $wpdb->get_results("
            SELECT keyword, AVG(position) as avg_position, COUNT(*) as frequency
            FROM $table 
            WHERE position > 0 
            GROUP BY keyword 
            ORDER BY frequency DESC, avg_position ASC 
            LIMIT 10
        ");
        
        $keywords = array();
        foreach ($results as $result) {
            $keywords[] = array(
                'keyword' => $result->keyword,
                'position' => round($result->avg_position),
                'frequency' => $result->frequency
            );
        }
        
        return $keywords;
    }
    
    /**
     * Get performance data for charts
     */
    private function get_performance_data() {
        global $wpdb;
        
        $table = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'performance_metrics';
        $results = $wpdb->get_results("
            SELECT DATE(recorded_at) as date, 
                   AVG(organic_traffic) as traffic,
                   AVG(avg_position) as position,
                   AVG(click_through_rate) as ctr
            FROM $table 
            WHERE recorded_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY DATE(recorded_at)
            ORDER BY date ASC
        ");
        
        $performance = array(
            'dates' => array(),
            'traffic' => array(),
            'positions' => array(),
            'ctr' => array()
        );
        
        foreach ($results as $result) {
            $performance['dates'][] = $result->date;
            $performance['traffic'][] = (int)$result->traffic;
            $performance['positions'][] = round($result->position, 1);
            $performance['ctr'][] = round($result->ctr, 2);
        }
        
        return $performance;
    }
    
    /**
     * Refresh stats via AJAX
     */
    public function refresh_stats() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'aaiseo_dashboard_nonce')) {
            wp_die('Security check failed');
        }
        
        // Trigger stats refresh
        do_action('aaiseo_refresh_dashboard_stats');
        
        wp_send_json_success(array('message' => 'Stats refreshed successfully'));
    }
    
    /**
     * Render dashboard widget
     */
    public function render_dashboard_widget($widget_type) {
        switch ($widget_type) {
            case 'seo_overview':
                return $this->render_seo_overview_widget();
            case 'recent_activity':
                return $this->render_recent_activity_widget();
            case 'performance_chart':
                return $this->render_performance_chart_widget();
            case 'top_keywords':
                return $this->render_top_keywords_widget();
            default:
                return '<p>Widget not found</p>';
        }
    }
    
    /**
     * Render SEO overview widget
     */
    private function render_seo_overview_widget() {
        $seo_score = $this->get_overall_seo_score();
        $total_posts = $this->get_total_posts_analyzed();
        $issues = $this->get_issues_count();
        $improvements = $this->get_improvements_count();
        
        ob_start();
        ?>
        <div class="aaiseo-widget seo-overview">
            <h3>SEO Overview</h3>
            <div class="seo-stats">
                <div class="stat-item">
                    <div class="stat-number"><?php echo $seo_score; ?></div>
                    <div class="stat-label">Average SEO Score</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo $total_posts; ?></div>
                    <div class="stat-label">Posts Analyzed</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo $issues; ?></div>
                    <div class="stat-label">Issues Found</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo $improvements; ?></div>
                    <div class="stat-label">Optimized Posts</div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render recent activity widget
     */
    private function render_recent_activity_widget() {
        $activities = $this->get_recent_activity();
        
        ob_start();
        ?>
        <div class="aaiseo-widget recent-activity">
            <h3>Recent Activity</h3>
            <div class="activity-list">
                <?php if (!empty($activities)): ?>
                    <?php foreach ($activities as $activity): ?>
                        <div class="activity-item">
                            <div class="activity-title"><?php echo esc_html($activity['title']); ?></div>
                            <div class="activity-meta">
                                <span class="score">Score: <?php echo $activity['score']; ?></span>
                                <span class="date"><?php echo date('M j, Y', strtotime($activity['date'])); ?></span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No recent activity found.</p>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render performance chart widget
     */
    private function render_performance_chart_widget() {
        $performance = $this->get_performance_data();
        
        ob_start();
        ?>
        <div class="aaiseo-widget performance-chart">
            <h3>Performance Trends</h3>
            <canvas id="aaiseo-performance-chart" width="400" height="200"></canvas>
            <script type="text/javascript">
                var performanceData = <?php echo json_encode($performance); ?>;
            </script>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render top keywords widget
     */
    private function render_top_keywords_widget() {
        $keywords = $this->get_top_keywords();
        
        ob_start();
        ?>
        <div class="aaiseo-widget top-keywords">
            <h3>Top Keywords</h3>
            <div class="keywords-list">
                <?php if (!empty($keywords)): ?>
                    <?php foreach ($keywords as $keyword): ?>
                        <div class="keyword-item">
                            <div class="keyword-text"><?php echo esc_html($keyword['keyword']); ?></div>
                            <div class="keyword-meta">
                                <span class="position">Pos: <?php echo $keyword['position']; ?></span>
                                <span class="frequency">Used: <?php echo $keyword['frequency']; ?>x</span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <p>No keyword data available.</p>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}

