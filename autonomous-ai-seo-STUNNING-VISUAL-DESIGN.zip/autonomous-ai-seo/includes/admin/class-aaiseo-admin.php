<?php
/**
 * Enhanced Professional Admin Interface for Autonomous AI SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Admin {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
        add_action('admin_init', array($this, 'admin_init'));
        
        // AJAX handlers
        add_action('wp_ajax_aaiseo_get_dashboard_data', array($this, 'ajax_get_dashboard_data'));
        add_action('wp_ajax_aaiseo_run_seo_analysis', array($this, 'ajax_run_seo_analysis'));
        add_action('wp_ajax_aaiseo_optimize_content', array($this, 'ajax_optimize_content'));
        add_action('wp_ajax_aaiseo_get_keyword_suggestions', array($this, 'ajax_get_keyword_suggestions'));
        add_action('wp_ajax_aaiseo_track_keyword', array($this, 'ajax_track_keyword'));
        add_action('wp_ajax_aaiseo_get_analytics_data', array($this, 'ajax_get_analytics_data'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        // Main menu
        add_menu_page(
            __('Autonomous AI SEO', 'autonomous-ai-seo'),
            __('AI SEO Pro', 'autonomous-ai-seo'),
            'manage_options',
            'aaiseo-dashboard',
            array($this, 'dashboard_page'),
            'data:image/svg+xml;base64,' . base64_encode('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#00d4aa"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>'),
            30
        );
        
        // Submenu pages
        add_submenu_page('aaiseo-dashboard', __('Dashboard', 'autonomous-ai-seo'), __('Dashboard', 'autonomous-ai-seo'), 'manage_options', 'aaiseo-dashboard', array($this, 'dashboard_page'));
        add_submenu_page('aaiseo-dashboard', __('Content Optimizer', 'autonomous-ai-seo'), __('Content Optimizer', 'autonomous-ai-seo'), 'manage_options', 'aaiseo-content', array($this, 'content_page'));
        add_submenu_page('aaiseo-dashboard', __('Keyword Research', 'autonomous-ai-seo'), __('Keyword Research', 'autonomous-ai-seo'), 'manage_options', 'aaiseo-keywords', array($this, 'keywords_page'));
        add_submenu_page('aaiseo-dashboard', __('Rank Tracker', 'autonomous-ai-seo'), __('Rank Tracker', 'autonomous-ai-seo'), 'manage_options', 'aaiseo-rankings', array($this, 'rankings_page'));
        add_submenu_page('aaiseo-dashboard', __('Analytics', 'autonomous-ai-seo'), __('Analytics', 'autonomous-ai-seo'), 'manage_options', 'aaiseo-analytics', array($this, 'analytics_page'));
        add_submenu_page('aaiseo-dashboard', __('Technical SEO', 'autonomous-ai-seo'), __('Technical SEO', 'autonomous-ai-seo'), 'manage_options', 'aaiseo-technical', array($this, 'technical_page'));
        add_submenu_page('aaiseo-dashboard', __('Competitors', 'autonomous-ai-seo'), __('Competitors', 'autonomous-ai-seo'), 'manage_options', 'aaiseo-competitors', array($this, 'competitors_page'));
        add_submenu_page('aaiseo-dashboard', __('Settings', 'autonomous-ai-seo'), __('Settings', 'autonomous-ai-seo'), 'manage_options', 'aaiseo-settings', array($this, 'settings_page'));
    }
    
    /**
     * Enqueue admin assets
     */
    public function enqueue_admin_assets($hook) {
        if (strpos($hook, 'aaiseo') === false) {
            return;
        }
        
        // Enqueue Chart.js for analytics
        wp_enqueue_script('chartjs', 'https://cdn.jsdelivr.net/npm/chart.js', array(), '3.9.1', true);
        
        // Enqueue admin CSS
        wp_enqueue_style('aaiseo-admin', AAISEO_PLUGIN_URL . 'assets/admin.css', array(), AAISEO_VERSION);
        
        // Enqueue admin JS
        wp_enqueue_script('aaiseo-admin', AAISEO_PLUGIN_URL . 'assets/admin.js', array('jquery', 'chartjs'), AAISEO_VERSION, true);
        
        // Localize script
        wp_localize_script('aaiseo-admin', 'aaiseo_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('aaiseo_nonce'),
            'strings' => array(
                'loading' => __('Loading...', 'autonomous-ai-seo'),
                'error' => __('An error occurred', 'autonomous-ai-seo'),
                'success' => __('Success!', 'autonomous-ai-seo'),
                'analyzing' => __('Analyzing...', 'autonomous-ai-seo'),
                'optimizing' => __('Optimizing...', 'autonomous-ai-seo')
            )
        ));
    }
    
    /**
     * Admin init
     */
    public function admin_init() {
        // Register settings
        register_setting('aaiseo_settings', 'aaiseo_openai_api_key');
        register_setting('aaiseo_settings', 'aaiseo_auto_optimize');
        register_setting('aaiseo_settings', 'aaiseo_technical_audit');
        register_setting('aaiseo_settings', 'aaiseo_competitive_monitoring');
    }
    
    /**
     * Enhanced Dashboard page
     */
    public function dashboard_page() {
        ?>
        <div class="aaiseo-admin-wrap">
            <div class="aaiseo-header">
                <div class="aaiseo-header-content">
                    <h1 class="aaiseo-title">
                        <span class="aaiseo-icon">🚀</span>
                        <?php _e('AI SEO Dashboard', 'autonomous-ai-seo'); ?>
                    </h1>
                    <p class="aaiseo-subtitle"><?php _e('Complete AI-Powered SEO Optimization & Analytics', 'autonomous-ai-seo'); ?></p>
                </div>
                <div class="aaiseo-header-actions">
                    <button class="aaiseo-btn aaiseo-btn-primary" id="run-full-analysis">
                        <span class="dashicons dashicons-search"></span>
                        <?php _e('Run Full Analysis', 'autonomous-ai-seo'); ?>
                    </button>
                    <button class="aaiseo-btn aaiseo-btn-secondary" id="export-report">
                        <span class="dashicons dashicons-download"></span>
                        <?php _e('Export Report', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
            
            <div class="aaiseo-dashboard-grid">
                <!-- SEO Score Card -->
                <div class="aaiseo-card aaiseo-score-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Overall SEO Score', 'autonomous-ai-seo'); ?></h3>
                        <span class="aaiseo-tooltip" data-tip="<?php _e('Your overall SEO performance score based on technical, content, and performance factors', 'autonomous-ai-seo'); ?>">?</span>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-score-circle" data-score="0">
                            <div class="aaiseo-score-number">0</div>
                            <div class="aaiseo-score-label"><?php _e('Score', 'autonomous-ai-seo'); ?></div>
                        </div>
                        <div class="aaiseo-score-details">
                            <div class="aaiseo-score-item">
                                <span class="aaiseo-score-dot aaiseo-score-good"></span>
                                <span><?php _e('Technical SEO', 'autonomous-ai-seo'); ?></span>
                                <span class="aaiseo-score-value" id="technical-score">--</span>
                            </div>
                            <div class="aaiseo-score-item">
                                <span class="aaiseo-score-dot aaiseo-score-warning"></span>
                                <span><?php _e('Content Quality', 'autonomous-ai-seo'); ?></span>
                                <span class="aaiseo-score-value" id="content-score">--</span>
                            </div>
                            <div class="aaiseo-score-item">
                                <span class="aaiseo-score-dot aaiseo-score-error"></span>
                                <span><?php _e('Performance', 'autonomous-ai-seo'); ?></span>
                                <span class="aaiseo-score-value" id="performance-score">--</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Stats -->
                <div class="aaiseo-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Quick Stats', 'autonomous-ai-seo'); ?></h3>
                        <button class="aaiseo-btn aaiseo-btn-sm" id="refresh-stats">
                            <span class="dashicons dashicons-update"></span>
                        </button>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-stats-grid">
                            <div class="aaiseo-stat">
                                <div class="aaiseo-stat-number" id="total-pages">--</div>
                                <div class="aaiseo-stat-label"><?php _e('Pages Analyzed', 'autonomous-ai-seo'); ?></div>
                            </div>
                            <div class="aaiseo-stat">
                                <div class="aaiseo-stat-number" id="keywords-tracked">--</div>
                                <div class="aaiseo-stat-label"><?php _e('Keywords Tracked', 'autonomous-ai-seo'); ?></div>
                            </div>
                            <div class="aaiseo-stat">
                                <div class="aaiseo-stat-number" id="issues-found">--</div>
                                <div class="aaiseo-stat-label"><?php _e('Issues Found', 'autonomous-ai-seo'); ?></div>
                            </div>
                            <div class="aaiseo-stat">
                                <div class="aaiseo-stat-number" id="improvements">--</div>
                                <div class="aaiseo-stat-label"><?php _e('Improvements', 'autonomous-ai-seo'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Activity -->
                <div class="aaiseo-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Recent Activity', 'autonomous-ai-seo'); ?></h3>
                        <a href="#" class="aaiseo-link"><?php _e('View All', 'autonomous-ai-seo'); ?></a>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-activity-list">
                            <div class="aaiseo-activity-item">
                                <div class="aaiseo-activity-icon aaiseo-activity-success">✓</div>
                                <div class="aaiseo-activity-content">
                                    <div class="aaiseo-activity-title"><?php _e('Content optimized', 'autonomous-ai-seo'); ?></div>
                                    <div class="aaiseo-activity-meta"><?php _e('Homepage - 2 minutes ago', 'autonomous-ai-seo'); ?></div>
                                </div>
                            </div>
                            <div class="aaiseo-activity-item">
                                <div class="aaiseo-activity-icon aaiseo-activity-info">📊</div>
                                <div class="aaiseo-activity-content">
                                    <div class="aaiseo-activity-title"><?php _e('Keyword ranking updated', 'autonomous-ai-seo'); ?></div>
                                    <div class="aaiseo-activity-meta"><?php _e('"SEO optimization" moved to position 3', 'autonomous-ai-seo'); ?></div>
                                </div>
                            </div>
                            <div class="aaiseo-activity-item">
                                <div class="aaiseo-activity-icon aaiseo-activity-warning">⚠</div>
                                <div class="aaiseo-activity-content">
                                    <div class="aaiseo-activity-title"><?php _e('Technical issue detected', 'autonomous-ai-seo'); ?></div>
                                    <div class="aaiseo-activity-meta"><?php _e('Missing meta description on 3 pages', 'autonomous-ai-seo'); ?></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Performance Chart -->
                <div class="aaiseo-card aaiseo-chart-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('SEO Performance Trend', 'autonomous-ai-seo'); ?></h3>
                        <div class="aaiseo-chart-controls">
                            <select id="chart-period">
                                <option value="7"><?php _e('Last 7 days', 'autonomous-ai-seo'); ?></option>
                                <option value="30" selected><?php _e('Last 30 days', 'autonomous-ai-seo'); ?></option>
                                <option value="90"><?php _e('Last 90 days', 'autonomous-ai-seo'); ?></option>
                            </select>
                        </div>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-chart-container">
                            <canvas id="seo-performance-chart"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                <div class="aaiseo-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Quick Actions', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-quick-actions">
                            <a href="<?php echo admin_url('admin.php?page=aaiseo-content'); ?>" class="aaiseo-quick-action">
                                <div class="aaiseo-quick-action-icon">✍️</div>
                                <div class="aaiseo-quick-action-title"><?php _e('Optimize Content', 'autonomous-ai-seo'); ?></div>
                                <div class="aaiseo-quick-action-desc"><?php _e('Analyze and improve your content', 'autonomous-ai-seo'); ?></div>
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=aaiseo-keywords'); ?>" class="aaiseo-quick-action">
                                <div class="aaiseo-quick-action-icon">🔍</div>
                                <div class="aaiseo-quick-action-title"><?php _e('Research Keywords', 'autonomous-ai-seo'); ?></div>
                                <div class="aaiseo-quick-action-desc"><?php _e('Find profitable keywords', 'autonomous-ai-seo'); ?></div>
                            </a>
                            <a href="<?php echo admin_url('admin.php?page=aaiseo-technical'); ?>" class="aaiseo-quick-action">
                                <div class="aaiseo-quick-action-icon">⚙️</div>
                                <div class="aaiseo-quick-action-title"><?php _e('Technical Audit', 'autonomous-ai-seo'); ?></div>
                                <div class="aaiseo-quick-action-desc"><?php _e('Fix technical SEO issues', 'autonomous-ai-seo'); ?></div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Enhanced Content Optimizer page
     */
    public function content_page() {
        ?>
        <div class="aaiseo-admin-wrap">
            <div class="aaiseo-header">
                <div class="aaiseo-header-content">
                    <h1 class="aaiseo-title">
                        <span class="aaiseo-icon">✍️</span>
                        <?php _e('Content Optimizer', 'autonomous-ai-seo'); ?>
                    </h1>
                    <p class="aaiseo-subtitle"><?php _e('AI-Powered Content Analysis & Optimization', 'autonomous-ai-seo'); ?></p>
                </div>
                <div class="aaiseo-header-actions">
                    <button class="aaiseo-btn aaiseo-btn-primary" id="bulk-optimize">
                        <span class="dashicons dashicons-admin-tools"></span>
                        <?php _e('Bulk Optimize', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
            
            <div class="aaiseo-content-layout">
                <div class="aaiseo-content-sidebar">
                    <!-- Content Selection -->
                    <div class="aaiseo-card">
                        <div class="aaiseo-card-header">
                            <h3><?php _e('Content Selection', 'autonomous-ai-seo'); ?></h3>
                        </div>
                        <div class="aaiseo-card-body">
                            <div class="aaiseo-form-group">
                                <label><?php _e('Select Content Type', 'autonomous-ai-seo'); ?></label>
                                <select id="content-type" class="aaiseo-input">
                                    <option value="post"><?php _e('Blog Posts', 'autonomous-ai-seo'); ?></option>
                                    <option value="page"><?php _e('Pages', 'autonomous-ai-seo'); ?></option>
                                    <option value="product"><?php _e('Products', 'autonomous-ai-seo'); ?></option>
                                </select>
                            </div>
                            
                            <div class="aaiseo-form-group">
                                <label><?php _e('Select Specific Content', 'autonomous-ai-seo'); ?></label>
                                <select id="content-selector" class="aaiseo-input">
                                    <option value=""><?php _e('Choose content...', 'autonomous-ai-seo'); ?></option>
                                    <?php
                                    $posts = get_posts(array('numberposts' => 50, 'post_status' => 'publish'));
                                    foreach ($posts as $post) {
                                        echo '<option value="' . $post->ID . '">' . esc_html($post->post_title) . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                            
                            <div class="aaiseo-form-group">
                                <label><?php _e('Target Keyword', 'autonomous-ai-seo'); ?></label>
                                <input type="text" id="target-keyword" class="aaiseo-input" placeholder="<?php _e('Enter target keyword...', 'autonomous-ai-seo'); ?>">
                                <small class="aaiseo-help-text"><?php _e('Primary keyword you want to rank for', 'autonomous-ai-seo'); ?></small>
                            </div>
                            
                            <button class="aaiseo-btn aaiseo-btn-primary aaiseo-btn-full" id="analyze-content">
                                <span class="dashicons dashicons-search"></span>
                                <?php _e('Analyze Content', 'autonomous-ai-seo'); ?>
                            </button>
                        </div>
                    </div>
                    
                    <!-- Content Score -->
                    <div class="aaiseo-card">
                        <div class="aaiseo-card-header">
                            <h3><?php _e('Content Score', 'autonomous-ai-seo'); ?></h3>
                        </div>
                        <div class="aaiseo-card-body">
                            <div class="aaiseo-score-circle" data-score="0">
                                <div class="aaiseo-score-number">0</div>
                                <div class="aaiseo-score-label"><?php _e('Score', 'autonomous-ai-seo'); ?></div>
                            </div>
                            
                            <div class="aaiseo-score-breakdown">
                                <div class="aaiseo-score-item">
                                    <span><?php _e('Keyword Density', 'autonomous-ai-seo'); ?></span>
                                    <div class="aaiseo-progress">
                                        <div class="aaiseo-progress-bar" data-width="0"></div>
                                    </div>
                                    <span class="aaiseo-score-value" id="keyword-density">--</span>
                                </div>
                                <div class="aaiseo-score-item">
                                    <span><?php _e('Readability', 'autonomous-ai-seo'); ?></span>
                                    <div class="aaiseo-progress">
                                        <div class="aaiseo-progress-bar" data-width="0"></div>
                                    </div>
                                    <span class="aaiseo-score-value" id="readability-score">--</span>
                                </div>
                                <div class="aaiseo-score-item">
                                    <span><?php _e('Word Count', 'autonomous-ai-seo'); ?></span>
                                    <div class="aaiseo-progress">
                                        <div class="aaiseo-progress-bar" data-width="0"></div>
                                    </div>
                                    <span class="aaiseo-score-value" id="word-count">--</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="aaiseo-content-main">
                    <!-- Analysis Results -->
                    <div class="aaiseo-card" id="analysis-results" style="display: none;">
                        <div class="aaiseo-card-header">
                            <h3><?php _e('Analysis Results', 'autonomous-ai-seo'); ?></h3>
                            <div class="aaiseo-card-actions">
                                <button class="aaiseo-btn aaiseo-btn-sm aaiseo-btn-secondary" id="export-analysis">
                                    <span class="dashicons dashicons-download"></span>
                                    <?php _e('Export', 'autonomous-ai-seo'); ?>
                                </button>
                            </div>
                        </div>
                        <div class="aaiseo-card-body">
                            <div class="aaiseo-tabs">
                                <button class="aaiseo-tab active" data-target="overview"><?php _e('Overview', 'autonomous-ai-seo'); ?></button>
                                <button class="aaiseo-tab" data-target="recommendations"><?php _e('Recommendations', 'autonomous-ai-seo'); ?></button>
                                <button class="aaiseo-tab" data-target="keywords"><?php _e('Keywords', 'autonomous-ai-seo'); ?></button>
                                <button class="aaiseo-tab" data-target="technical"><?php _e('Technical', 'autonomous-ai-seo'); ?></button>
                            </div>
                            
                            <div class="aaiseo-tab-content">
                                <div id="overview" class="aaiseo-tab-pane active">
                                    <div id="analysis-content"></div>
                                </div>
                                <div id="recommendations" class="aaiseo-tab-pane">
                                    <div id="recommendations-content"></div>
                                </div>
                                <div id="keywords" class="aaiseo-tab-pane">
                                    <div id="keywords-content"></div>
                                </div>
                                <div id="technical" class="aaiseo-tab-pane">
                                    <div id="technical-content"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Content Preview -->
                    <div class="aaiseo-card" id="content-preview">
                        <div class="aaiseo-card-header">
                            <h3><?php _e('Content Preview', 'autonomous-ai-seo'); ?></h3>
                        </div>
                        <div class="aaiseo-card-body">
                            <div class="aaiseo-content-preview-placeholder">
                                <div class="aaiseo-placeholder-icon">📄</div>
                                <h4><?php _e('Select content to analyze', 'autonomous-ai-seo'); ?></h4>
                                <p><?php _e('Choose a post or page from the sidebar to see its content and analysis results.', 'autonomous-ai-seo'); ?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    // Continue with other page methods...
    // I'll add the remaining methods in the next part due to length
    
    /**
     * AJAX Handlers
     */
    public function ajax_get_dashboard_data() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        // Return sample data for now
        wp_send_json_success(array(
            'total_pages' => 42,
            'keywords_tracked' => 15,
            'issues_found' => 3,
            'improvements' => 8,
            'technical_score' => 85,
            'content_score' => 78,
            'performance_score' => 92
        ));
    }
    
    public function ajax_run_seo_analysis() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        wp_send_json_success(array('message' => 'Analysis completed'));
    }
    
    public function ajax_optimize_content() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        wp_send_json_success(array('message' => 'Content optimized'));
    }
    
    public function ajax_get_keyword_suggestions() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        wp_send_json_success(array('keywords' => array()));
    }
    
    public function ajax_track_keyword() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        wp_send_json_success(array('message' => 'Keyword tracked'));
    }
    
    public function ajax_get_analytics_data() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        wp_send_json_success(array('data' => array()));
    }
}


    
    /**
     * Enhanced Keyword Research page
     */
    public function keywords_page() {
        ?>
        <div class="aaiseo-admin-wrap">
            <div class="aaiseo-header">
                <div class="aaiseo-header-content">
                    <h1 class="aaiseo-title">
                        <span class="aaiseo-icon">🔍</span>
                        <?php _e('Keyword Research', 'autonomous-ai-seo'); ?>
                    </h1>
                    <p class="aaiseo-subtitle"><?php _e('Discover High-Value Keywords with AI-Powered Research', 'autonomous-ai-seo'); ?></p>
                </div>
                <div class="aaiseo-header-actions">
                    <button class="aaiseo-btn aaiseo-btn-primary" id="export-keywords">
                        <span class="dashicons dashicons-download"></span>
                        <?php _e('Export Keywords', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
            
            <div class="aaiseo-content-layout">
                <div class="aaiseo-content-sidebar">
                    <!-- Keyword Research Form -->
                    <div class="aaiseo-card">
                        <div class="aaiseo-card-header">
                            <h3><?php _e('Research Parameters', 'autonomous-ai-seo'); ?></h3>
                        </div>
                        <div class="aaiseo-card-body">
                            <div class="aaiseo-form-group">
                                <label><?php _e('Seed Keyword', 'autonomous-ai-seo'); ?></label>
                                <input type="text" id="seed-keyword" class="aaiseo-input" placeholder="<?php _e('Enter main keyword...', 'autonomous-ai-seo'); ?>">
                                <small class="aaiseo-help-text"><?php _e('Main topic or keyword to research', 'autonomous-ai-seo'); ?></small>
                            </div>
                            
                            <div class="aaiseo-form-group">
                                <label><?php _e('Target Location', 'autonomous-ai-seo'); ?></label>
                                <select id="target-location" class="aaiseo-input">
                                    <option value="US"><?php _e('United States', 'autonomous-ai-seo'); ?></option>
                                    <option value="UK"><?php _e('United Kingdom', 'autonomous-ai-seo'); ?></option>
                                    <option value="CA"><?php _e('Canada', 'autonomous-ai-seo'); ?></option>
                                    <option value="AU"><?php _e('Australia', 'autonomous-ai-seo'); ?></option>
                                </select>
                            </div>
                            
                            <div class="aaiseo-form-group">
                                <label><?php _e('Language', 'autonomous-ai-seo'); ?></label>
                                <select id="target-language" class="aaiseo-input">
                                    <option value="en"><?php _e('English', 'autonomous-ai-seo'); ?></option>
                                    <option value="es"><?php _e('Spanish', 'autonomous-ai-seo'); ?></option>
                                    <option value="fr"><?php _e('French', 'autonomous-ai-seo'); ?></option>
                                    <option value="de"><?php _e('German', 'autonomous-ai-seo'); ?></option>
                                </select>
                            </div>
                            
                            <div class="aaiseo-form-group">
                                <label><?php _e('Search Volume Range', 'autonomous-ai-seo'); ?></label>
                                <div class="aaiseo-range-inputs">
                                    <input type="number" id="min-volume" class="aaiseo-input" placeholder="Min" value="100">
                                    <span>-</span>
                                    <input type="number" id="max-volume" class="aaiseo-input" placeholder="Max" value="10000">
                                </div>
                            </div>
                            
                            <button class="aaiseo-btn aaiseo-btn-primary aaiseo-btn-full" id="research-keywords">
                                <span class="dashicons dashicons-search"></span>
                                <?php _e('Research Keywords', 'autonomous-ai-seo'); ?>
                            </button>
                        </div>
                    </div>
                    
                    <!-- Keyword Filters -->
                    <div class="aaiseo-card">
                        <div class="aaiseo-card-header">
                            <h3><?php _e('Filters', 'autonomous-ai-seo'); ?></h3>
                        </div>
                        <div class="aaiseo-card-body">
                            <div class="aaiseo-filter-group">
                                <label><?php _e('Difficulty', 'autonomous-ai-seo'); ?></label>
                                <div class="aaiseo-checkbox-group">
                                    <label><input type="checkbox" value="easy" checked> <?php _e('Easy', 'autonomous-ai-seo'); ?></label>
                                    <label><input type="checkbox" value="medium" checked> <?php _e('Medium', 'autonomous-ai-seo'); ?></label>
                                    <label><input type="checkbox" value="hard"> <?php _e('Hard', 'autonomous-ai-seo'); ?></label>
                                </div>
                            </div>
                            
                            <div class="aaiseo-filter-group">
                                <label><?php _e('Keyword Type', 'autonomous-ai-seo'); ?></label>
                                <div class="aaiseo-checkbox-group">
                                    <label><input type="checkbox" value="short" checked> <?php _e('Short-tail', 'autonomous-ai-seo'); ?></label>
                                    <label><input type="checkbox" value="long" checked> <?php _e('Long-tail', 'autonomous-ai-seo'); ?></label>
                                    <label><input type="checkbox" value="question"> <?php _e('Questions', 'autonomous-ai-seo'); ?></label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="aaiseo-content-main">
                    <!-- Keyword Results -->
                    <div class="aaiseo-card" id="keyword-results">
                        <div class="aaiseo-card-header">
                            <h3><?php _e('Keyword Opportunities', 'autonomous-ai-seo'); ?></h3>
                            <div class="aaiseo-card-actions">
                                <select id="sort-keywords" class="aaiseo-input aaiseo-input-sm">
                                    <option value="volume"><?php _e('Sort by Volume', 'autonomous-ai-seo'); ?></option>
                                    <option value="difficulty"><?php _e('Sort by Difficulty', 'autonomous-ai-seo'); ?></option>
                                    <option value="cpc"><?php _e('Sort by CPC', 'autonomous-ai-seo'); ?></option>
                                </select>
                            </div>
                        </div>
                        <div class="aaiseo-card-body">
                            <div class="aaiseo-keyword-table-container">
                                <table class="aaiseo-table" id="keywords-table">
                                    <thead>
                                        <tr>
                                            <th><?php _e('Keyword', 'autonomous-ai-seo'); ?></th>
                                            <th><?php _e('Volume', 'autonomous-ai-seo'); ?></th>
                                            <th><?php _e('Difficulty', 'autonomous-ai-seo'); ?></th>
                                            <th><?php _e('CPC', 'autonomous-ai-seo'); ?></th>
                                            <th><?php _e('Trend', 'autonomous-ai-seo'); ?></th>
                                            <th><?php _e('Actions', 'autonomous-ai-seo'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody id="keywords-tbody">
                                        <tr class="aaiseo-placeholder-row">
                                            <td colspan="6">
                                                <div class="aaiseo-placeholder">
                                                    <div class="aaiseo-placeholder-icon">🔍</div>
                                                    <h4><?php _e('Start Your Keyword Research', 'autonomous-ai-seo'); ?></h4>
                                                    <p><?php _e('Enter a seed keyword and click "Research Keywords" to discover opportunities.', 'autonomous-ai-seo'); ?></p>
                                                </div>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Enhanced Rank Tracker page
     */
    public function rankings_page() {
        ?>
        <div class="aaiseo-admin-wrap">
            <div class="aaiseo-header">
                <div class="aaiseo-header-content">
                    <h1 class="aaiseo-title">
                        <span class="aaiseo-icon">📈</span>
                        <?php _e('Rank Tracker', 'autonomous-ai-seo'); ?>
                    </h1>
                    <p class="aaiseo-subtitle"><?php _e('Monitor Your Keyword Rankings & Track Progress', 'autonomous-ai-seo'); ?></p>
                </div>
                <div class="aaiseo-header-actions">
                    <button class="aaiseo-btn aaiseo-btn-primary" id="add-keyword">
                        <span class="dashicons dashicons-plus"></span>
                        <?php _e('Add Keyword', 'autonomous-ai-seo'); ?>
                    </button>
                    <button class="aaiseo-btn aaiseo-btn-secondary" id="refresh-rankings">
                        <span class="dashicons dashicons-update"></span>
                        <?php _e('Refresh All', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
            
            <div class="aaiseo-dashboard-grid">
                <!-- Ranking Overview -->
                <div class="aaiseo-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Ranking Overview', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-ranking-stats">
                            <div class="aaiseo-ranking-stat">
                                <div class="aaiseo-ranking-number">12</div>
                                <div class="aaiseo-ranking-label"><?php _e('Top 10', 'autonomous-ai-seo'); ?></div>
                                <div class="aaiseo-ranking-change up">+3</div>
                            </div>
                            <div class="aaiseo-ranking-stat">
                                <div class="aaiseo-ranking-number">28</div>
                                <div class="aaiseo-ranking-label"><?php _e('Top 50', 'autonomous-ai-seo'); ?></div>
                                <div class="aaiseo-ranking-change up">+5</div>
                            </div>
                            <div class="aaiseo-ranking-stat">
                                <div class="aaiseo-ranking-number">45</div>
                                <div class="aaiseo-ranking-label"><?php _e('Total Tracked', 'autonomous-ai-seo'); ?></div>
                                <div class="aaiseo-ranking-change neutral">0</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Ranking Distribution -->
                <div class="aaiseo-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Position Distribution', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-position-chart">
                            <canvas id="position-distribution-chart"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- Recent Changes -->
                <div class="aaiseo-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Recent Changes', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-ranking-changes">
                            <div class="aaiseo-ranking-change-item">
                                <div class="aaiseo-change-keyword">SEO optimization</div>
                                <div class="aaiseo-change-movement up">↗ +5</div>
                                <div class="aaiseo-change-position">Position 8</div>
                            </div>
                            <div class="aaiseo-ranking-change-item">
                                <div class="aaiseo-change-keyword">content marketing</div>
                                <div class="aaiseo-change-movement down">↘ -2</div>
                                <div class="aaiseo-change-position">Position 15</div>
                            </div>
                            <div class="aaiseo-ranking-change-item">
                                <div class="aaiseo-change-keyword">digital marketing</div>
                                <div class="aaiseo-change-movement up">↗ +12</div>
                                <div class="aaiseo-change-position">Position 23</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Tracked Keywords Table -->
                <div class="aaiseo-card aaiseo-full-width">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Tracked Keywords', 'autonomous-ai-seo'); ?></h3>
                        <div class="aaiseo-card-actions">
                            <input type="text" id="search-keywords" class="aaiseo-input aaiseo-input-sm" placeholder="<?php _e('Search keywords...', 'autonomous-ai-seo'); ?>">
                        </div>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-table-container">
                            <table class="aaiseo-table" id="rankings-table">
                                <thead>
                                    <tr>
                                        <th><?php _e('Keyword', 'autonomous-ai-seo'); ?></th>
                                        <th><?php _e('Current Position', 'autonomous-ai-seo'); ?></th>
                                        <th><?php _e('Previous Position', 'autonomous-ai-seo'); ?></th>
                                        <th><?php _e('Change', 'autonomous-ai-seo'); ?></th>
                                        <th><?php _e('URL', 'autonomous-ai-seo'); ?></th>
                                        <th><?php _e('Volume', 'autonomous-ai-seo'); ?></th>
                                        <th><?php _e('Last Updated', 'autonomous-ai-seo'); ?></th>
                                        <th><?php _e('Actions', 'autonomous-ai-seo'); ?></th>
                                    </tr>
                                </thead>
                                <tbody id="rankings-tbody">
                                    <!-- Sample data will be loaded here -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Enhanced Analytics page
     */
    public function analytics_page() {
        ?>
        <div class="aaiseo-admin-wrap">
            <div class="aaiseo-header">
                <div class="aaiseo-header-content">
                    <h1 class="aaiseo-title">
                        <span class="aaiseo-icon">📊</span>
                        <?php _e('SEO Analytics', 'autonomous-ai-seo'); ?>
                    </h1>
                    <p class="aaiseo-subtitle"><?php _e('Comprehensive SEO Performance Analytics & Insights', 'autonomous-ai-seo'); ?></p>
                </div>
                <div class="aaiseo-header-actions">
                    <select id="date-range" class="aaiseo-input">
                        <option value="7"><?php _e('Last 7 days', 'autonomous-ai-seo'); ?></option>
                        <option value="30" selected><?php _e('Last 30 days', 'autonomous-ai-seo'); ?></option>
                        <option value="90"><?php _e('Last 90 days', 'autonomous-ai-seo'); ?></option>
                        <option value="365"><?php _e('Last year', 'autonomous-ai-seo'); ?></option>
                    </select>
                    <button class="aaiseo-btn aaiseo-btn-primary" id="export-analytics">
                        <span class="dashicons dashicons-download"></span>
                        <?php _e('Export Report', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
            
            <div class="aaiseo-dashboard-grid">
                <!-- Key Metrics -->
                <div class="aaiseo-card aaiseo-metrics-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Key Metrics', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-metrics-grid">
                            <div class="aaiseo-metric">
                                <div class="aaiseo-metric-icon">👁️</div>
                                <div class="aaiseo-metric-value">24,567</div>
                                <div class="aaiseo-metric-label"><?php _e('Impressions', 'autonomous-ai-seo'); ?></div>
                                <div class="aaiseo-metric-change up">+12.5%</div>
                            </div>
                            <div class="aaiseo-metric">
                                <div class="aaiseo-metric-icon">🖱️</div>
                                <div class="aaiseo-metric-value">1,234</div>
                                <div class="aaiseo-metric-label"><?php _e('Clicks', 'autonomous-ai-seo'); ?></div>
                                <div class="aaiseo-metric-change up">+8.3%</div>
                            </div>
                            <div class="aaiseo-metric">
                                <div class="aaiseo-metric-icon">📈</div>
                                <div class="aaiseo-metric-value">5.02%</div>
                                <div class="aaiseo-metric-label"><?php _e('CTR', 'autonomous-ai-seo'); ?></div>
                                <div class="aaiseo-metric-change down">-2.1%</div>
                            </div>
                            <div class="aaiseo-metric">
                                <div class="aaiseo-metric-icon">🎯</div>
                                <div class="aaiseo-metric-value">15.8</div>
                                <div class="aaiseo-metric-label"><?php _e('Avg. Position', 'autonomous-ai-seo'); ?></div>
                                <div class="aaiseo-metric-change up">+3.2</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Performance Chart -->
                <div class="aaiseo-card aaiseo-chart-card aaiseo-full-width">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Performance Trends', 'autonomous-ai-seo'); ?></h3>
                        <div class="aaiseo-chart-controls">
                            <div class="aaiseo-chart-legend">
                                <span class="aaiseo-legend-item">
                                    <span class="aaiseo-legend-color" style="background: #2563eb;"></span>
                                    <?php _e('Clicks', 'autonomous-ai-seo'); ?>
                                </span>
                                <span class="aaiseo-legend-item">
                                    <span class="aaiseo-legend-color" style="background: #10b981;"></span>
                                    <?php _e('Impressions', 'autonomous-ai-seo'); ?>
                                </span>
                                <span class="aaiseo-legend-item">
                                    <span class="aaiseo-legend-color" style="background: #f59e0b;"></span>
                                    <?php _e('CTR', 'autonomous-ai-seo'); ?>
                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-chart-container">
                            <canvas id="performance-trends-chart"></canvas>
                        </div>
                    </div>
                </div>
                
                <!-- Top Pages -->
                <div class="aaiseo-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Top Performing Pages', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-top-pages">
                            <div class="aaiseo-page-item">
                                <div class="aaiseo-page-title">Homepage</div>
                                <div class="aaiseo-page-stats">
                                    <span class="aaiseo-page-clicks">456 clicks</span>
                                    <span class="aaiseo-page-ctr">6.2% CTR</span>
                                </div>
                            </div>
                            <div class="aaiseo-page-item">
                                <div class="aaiseo-page-title">SEO Guide</div>
                                <div class="aaiseo-page-stats">
                                    <span class="aaiseo-page-clicks">234 clicks</span>
                                    <span class="aaiseo-page-ctr">4.8% CTR</span>
                                </div>
                            </div>
                            <div class="aaiseo-page-item">
                                <div class="aaiseo-page-title">Content Marketing</div>
                                <div class="aaiseo-page-stats">
                                    <span class="aaiseo-page-clicks">189 clicks</span>
                                    <span class="aaiseo-page-ctr">3.9% CTR</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Top Keywords -->
                <div class="aaiseo-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Top Keywords', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-top-keywords">
                            <div class="aaiseo-keyword-item">
                                <div class="aaiseo-keyword-name">seo optimization</div>
                                <div class="aaiseo-keyword-stats">
                                    <span class="aaiseo-keyword-position">Pos. 3</span>
                                    <span class="aaiseo-keyword-clicks">89 clicks</span>
                                </div>
                            </div>
                            <div class="aaiseo-keyword-item">
                                <div class="aaiseo-keyword-name">content marketing</div>
                                <div class="aaiseo-keyword-stats">
                                    <span class="aaiseo-keyword-position">Pos. 7</span>
                                    <span class="aaiseo-keyword-clicks">67 clicks</span>
                                </div>
                            </div>
                            <div class="aaiseo-keyword-item">
                                <div class="aaiseo-keyword-name">digital marketing</div>
                                <div class="aaiseo-keyword-stats">
                                    <span class="aaiseo-keyword-position">Pos. 12</span>
                                    <span class="aaiseo-keyword-clicks">45 clicks</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Enhanced Technical SEO page
     */
    public function technical_page() {
        ?>
        <div class="aaiseo-admin-wrap">
            <div class="aaiseo-header">
                <div class="aaiseo-header-content">
                    <h1 class="aaiseo-title">
                        <span class="aaiseo-icon">⚙️</span>
                        <?php _e('Technical SEO', 'autonomous-ai-seo'); ?>
                    </h1>
                    <p class="aaiseo-subtitle"><?php _e('Comprehensive Technical SEO Audit & Optimization', 'autonomous-ai-seo'); ?></p>
                </div>
                <div class="aaiseo-header-actions">
                    <button class="aaiseo-btn aaiseo-btn-primary" id="run-audit">
                        <span class="dashicons dashicons-admin-tools"></span>
                        <?php _e('Run Full Audit', 'autonomous-ai-seo'); ?>
                    </button>
                    <button class="aaiseo-btn aaiseo-btn-secondary" id="fix-all-issues">
                        <span class="dashicons dashicons-yes"></span>
                        <?php _e('Auto-Fix Issues', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
            
            <div class="aaiseo-dashboard-grid">
                <!-- Technical Score -->
                <div class="aaiseo-card aaiseo-score-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Technical SEO Score', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-score-circle" data-score="85">
                            <div class="aaiseo-score-number">85</div>
                            <div class="aaiseo-score-label"><?php _e('Score', 'autonomous-ai-seo'); ?></div>
                        </div>
                        <div class="aaiseo-score-breakdown">
                            <div class="aaiseo-score-item">
                                <span class="aaiseo-score-dot aaiseo-score-good"></span>
                                <span><?php _e('Core Web Vitals', 'autonomous-ai-seo'); ?></span>
                                <span class="aaiseo-score-value">92</span>
                            </div>
                            <div class="aaiseo-score-item">
                                <span class="aaiseo-score-dot aaiseo-score-warning"></span>
                                <span><?php _e('Mobile Usability', 'autonomous-ai-seo'); ?></span>
                                <span class="aaiseo-score-value">78</span>
                            </div>
                            <div class="aaiseo-score-item">
                                <span class="aaiseo-score-dot aaiseo-score-good"></span>
                                <span><?php _e('Security', 'autonomous-ai-seo'); ?></span>
                                <span class="aaiseo-score-value">95</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Issues Summary -->
                <div class="aaiseo-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Issues Summary', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-issues-summary">
                            <div class="aaiseo-issue-type">
                                <div class="aaiseo-issue-icon error">🔴</div>
                                <div class="aaiseo-issue-count">3</div>
                                <div class="aaiseo-issue-label"><?php _e('Critical', 'autonomous-ai-seo'); ?></div>
                            </div>
                            <div class="aaiseo-issue-type">
                                <div class="aaiseo-issue-icon warning">🟡</div>
                                <div class="aaiseo-issue-count">7</div>
                                <div class="aaiseo-issue-label"><?php _e('Warning', 'autonomous-ai-seo'); ?></div>
                            </div>
                            <div class="aaiseo-issue-type">
                                <div class="aaiseo-issue-icon info">🔵</div>
                                <div class="aaiseo-issue-count">12</div>
                                <div class="aaiseo-issue-label"><?php _e('Info', 'autonomous-ai-seo'); ?></div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Audit Categories -->
                <div class="aaiseo-card aaiseo-full-width">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Technical Audit Results', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-tabs">
                            <button class="aaiseo-tab active" data-target="performance"><?php _e('Performance', 'autonomous-ai-seo'); ?></button>
                            <button class="aaiseo-tab" data-target="accessibility"><?php _e('Accessibility', 'autonomous-ai-seo'); ?></button>
                            <button class="aaiseo-tab" data-target="seo-issues"><?php _e('SEO Issues', 'autonomous-ai-seo'); ?></button>
                            <button class="aaiseo-tab" data-target="security"><?php _e('Security', 'autonomous-ai-seo'); ?></button>
                        </div>
                        
                        <div class="aaiseo-tab-content">
                            <div id="performance" class="aaiseo-tab-pane active">
                                <div class="aaiseo-audit-section">
                                    <h4><?php _e('Core Web Vitals', 'autonomous-ai-seo'); ?></h4>
                                    <div class="aaiseo-vitals-grid">
                                        <div class="aaiseo-vital">
                                            <div class="aaiseo-vital-score good">2.1s</div>
                                            <div class="aaiseo-vital-label"><?php _e('LCP', 'autonomous-ai-seo'); ?></div>
                                        </div>
                                        <div class="aaiseo-vital">
                                            <div class="aaiseo-vital-score good">0.08</div>
                                            <div class="aaiseo-vital-label"><?php _e('FID', 'autonomous-ai-seo'); ?></div>
                                        </div>
                                        <div class="aaiseo-vital">
                                            <div class="aaiseo-vital-score warning">0.15</div>
                                            <div class="aaiseo-vital-label"><?php _e('CLS', 'autonomous-ai-seo'); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="accessibility" class="aaiseo-tab-pane">
                                <div class="aaiseo-audit-section">
                                    <h4><?php _e('Accessibility Issues', 'autonomous-ai-seo'); ?></h4>
                                    <div class="aaiseo-issues-list">
                                        <div class="aaiseo-issue-item">
                                            <div class="aaiseo-issue-severity warning">⚠</div>
                                            <div class="aaiseo-issue-content">
                                                <div class="aaiseo-issue-title"><?php _e('Missing alt text on images', 'autonomous-ai-seo'); ?></div>
                                                <div class="aaiseo-issue-description"><?php _e('5 images are missing alt text', 'autonomous-ai-seo'); ?></div>
                                            </div>
                                            <button class="aaiseo-btn aaiseo-btn-sm"><?php _e('Fix', 'autonomous-ai-seo'); ?></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="seo-issues" class="aaiseo-tab-pane">
                                <div class="aaiseo-audit-section">
                                    <h4><?php _e('SEO Issues', 'autonomous-ai-seo'); ?></h4>
                                    <div class="aaiseo-issues-list">
                                        <div class="aaiseo-issue-item">
                                            <div class="aaiseo-issue-severity error">🔴</div>
                                            <div class="aaiseo-issue-content">
                                                <div class="aaiseo-issue-title"><?php _e('Duplicate meta descriptions', 'autonomous-ai-seo'); ?></div>
                                                <div class="aaiseo-issue-description"><?php _e('3 pages have duplicate meta descriptions', 'autonomous-ai-seo'); ?></div>
                                            </div>
                                            <button class="aaiseo-btn aaiseo-btn-sm"><?php _e('Fix', 'autonomous-ai-seo'); ?></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div id="security" class="aaiseo-tab-pane">
                                <div class="aaiseo-audit-section">
                                    <h4><?php _e('Security Status', 'autonomous-ai-seo'); ?></h4>
                                    <div class="aaiseo-security-checks">
                                        <div class="aaiseo-security-check">
                                            <div class="aaiseo-check-status good">✓</div>
                                            <div class="aaiseo-check-label"><?php _e('HTTPS Enabled', 'autonomous-ai-seo'); ?></div>
                                        </div>
                                        <div class="aaiseo-security-check">
                                            <div class="aaiseo-check-status good">✓</div>
                                            <div class="aaiseo-check-label"><?php _e('Security Headers', 'autonomous-ai-seo'); ?></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Enhanced Competitors page
     */
    public function competitors_page() {
        ?>
        <div class="aaiseo-admin-wrap">
            <div class="aaiseo-header">
                <div class="aaiseo-header-content">
                    <h1 class="aaiseo-title">
                        <span class="aaiseo-icon">🎯</span>
                        <?php _e('Competitor Analysis', 'autonomous-ai-seo'); ?>
                    </h1>
                    <p class="aaiseo-subtitle"><?php _e('Monitor Competitors & Discover Opportunities', 'autonomous-ai-seo'); ?></p>
                </div>
                <div class="aaiseo-header-actions">
                    <button class="aaiseo-btn aaiseo-btn-primary" id="add-competitor">
                        <span class="dashicons dashicons-plus"></span>
                        <?php _e('Add Competitor', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
            
            <div class="aaiseo-dashboard-grid">
                <!-- Competitor Overview -->
                <div class="aaiseo-card aaiseo-full-width">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Competitor Overview', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-competitors-grid">
                            <div class="aaiseo-competitor-card">
                                <div class="aaiseo-competitor-header">
                                    <div class="aaiseo-competitor-favicon">🌐</div>
                                    <div class="aaiseo-competitor-name">competitor1.com</div>
                                    <div class="aaiseo-competitor-status active">Active</div>
                                </div>
                                <div class="aaiseo-competitor-stats">
                                    <div class="aaiseo-competitor-stat">
                                        <div class="aaiseo-stat-value">45,678</div>
                                        <div class="aaiseo-stat-label"><?php _e('Keywords', 'autonomous-ai-seo'); ?></div>
                                    </div>
                                    <div class="aaiseo-competitor-stat">
                                        <div class="aaiseo-stat-value">2.3M</div>
                                        <div class="aaiseo-stat-label"><?php _e('Traffic', 'autonomous-ai-seo'); ?></div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="aaiseo-competitor-card">
                                <div class="aaiseo-competitor-header">
                                    <div class="aaiseo-competitor-favicon">🌐</div>
                                    <div class="aaiseo-competitor-name">competitor2.com</div>
                                    <div class="aaiseo-competitor-status active">Active</div>
                                </div>
                                <div class="aaiseo-competitor-stats">
                                    <div class="aaiseo-competitor-stat">
                                        <div class="aaiseo-stat-value">32,145</div>
                                        <div class="aaiseo-stat-label"><?php _e('Keywords', 'autonomous-ai-seo'); ?></div>
                                    </div>
                                    <div class="aaiseo-competitor-stat">
                                        <div class="aaiseo-stat-value">1.8M</div>
                                        <div class="aaiseo-stat-label"><?php _e('Traffic', 'autonomous-ai-seo'); ?></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Keyword Gaps -->
                <div class="aaiseo-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Keyword Gaps', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-keyword-gaps">
                            <div class="aaiseo-gap-item">
                                <div class="aaiseo-gap-keyword">content strategy</div>
                                <div class="aaiseo-gap-volume">8,100/mo</div>
                                <div class="aaiseo-gap-difficulty">Medium</div>
                            </div>
                            <div class="aaiseo-gap-item">
                                <div class="aaiseo-gap-keyword">seo tools</div>
                                <div class="aaiseo-gap-volume">12,500/mo</div>
                                <div class="aaiseo-gap-difficulty">High</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Content Gaps -->
                <div class="aaiseo-card">
                    <div class="aaiseo-card-header">
                        <h3><?php _e('Content Opportunities', 'autonomous-ai-seo'); ?></h3>
                    </div>
                    <div class="aaiseo-card-body">
                        <div class="aaiseo-content-gaps">
                            <div class="aaiseo-content-gap">
                                <div class="aaiseo-gap-title">Ultimate SEO Guide</div>
                                <div class="aaiseo-gap-competitor">competitor1.com</div>
                                <div class="aaiseo-gap-traffic">15K visits/mo</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Enhanced Settings page
     */
    public function settings_page() {
        ?>
        <div class="aaiseo-admin-wrap">
            <div class="aaiseo-header">
                <div class="aaiseo-header-content">
                    <h1 class="aaiseo-title">
                        <span class="aaiseo-icon">⚙️</span>
                        <?php _e('Settings', 'autonomous-ai-seo'); ?>
                    </h1>
                    <p class="aaiseo-subtitle"><?php _e('Configure Your AI SEO Settings', 'autonomous-ai-seo'); ?></p>
                </div>
                <div class="aaiseo-header-actions">
                    <button class="aaiseo-btn aaiseo-btn-primary" id="save-settings">
                        <span class="dashicons dashicons-yes"></span>
                        <?php _e('Save Settings', 'autonomous-ai-seo'); ?>
                    </button>
                </div>
            </div>
            
            <div class="aaiseo-settings-layout">
                <div class="aaiseo-settings-sidebar">
                    <div class="aaiseo-settings-nav">
                        <a href="#general" class="aaiseo-nav-item active"><?php _e('General', 'autonomous-ai-seo'); ?></a>
                        <a href="#api" class="aaiseo-nav-item"><?php _e('API Keys', 'autonomous-ai-seo'); ?></a>
                        <a href="#automation" class="aaiseo-nav-item"><?php _e('Automation', 'autonomous-ai-seo'); ?></a>
                        <a href="#notifications" class="aaiseo-nav-item"><?php _e('Notifications', 'autonomous-ai-seo'); ?></a>
                        <a href="#advanced" class="aaiseo-nav-item"><?php _e('Advanced', 'autonomous-ai-seo'); ?></a>
                    </div>
                </div>
                
                <div class="aaiseo-settings-content">
                    <form id="aaiseo-settings-form">
                        <!-- General Settings -->
                        <div id="general" class="aaiseo-settings-section active">
                            <div class="aaiseo-card">
                                <div class="aaiseo-card-header">
                                    <h3><?php _e('General Settings', 'autonomous-ai-seo'); ?></h3>
                                </div>
                                <div class="aaiseo-card-body">
                                    <div class="aaiseo-form-group">
                                        <label><?php _e('Site Name', 'autonomous-ai-seo'); ?></label>
                                        <input type="text" name="site_name" class="aaiseo-input" value="<?php echo get_bloginfo('name'); ?>">
                                        <small class="aaiseo-help-text"><?php _e('Your website name for SEO purposes', 'autonomous-ai-seo'); ?></small>
                                    </div>
                                    
                                    <div class="aaiseo-form-group">
                                        <label><?php _e('Default Meta Description', 'autonomous-ai-seo'); ?></label>
                                        <textarea name="default_meta_description" class="aaiseo-textarea"><?php echo get_bloginfo('description'); ?></textarea>
                                        <small class="aaiseo-help-text"><?php _e('Default meta description for pages without one', 'autonomous-ai-seo'); ?></small>
                                    </div>
                                    
                                    <div class="aaiseo-form-group">
                                        <label class="aaiseo-checkbox-label">
                                            <input type="checkbox" name="enable_seo_analysis" checked>
                                            <?php _e('Enable automatic SEO analysis', 'autonomous-ai-seo'); ?>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- API Settings -->
                        <div id="api" class="aaiseo-settings-section">
                            <div class="aaiseo-card">
                                <div class="aaiseo-card-header">
                                    <h3><?php _e('API Configuration', 'autonomous-ai-seo'); ?></h3>
                                </div>
                                <div class="aaiseo-card-body">
                                    <div class="aaiseo-form-group">
                                        <label><?php _e('OpenAI API Key', 'autonomous-ai-seo'); ?></label>
                                        <input type="password" name="openai_api_key" class="aaiseo-input" value="<?php echo get_option('aaiseo_openai_api_key', ''); ?>">
                                        <small class="aaiseo-help-text"><?php _e('Required for AI-powered content analysis', 'autonomous-ai-seo'); ?></small>
                                    </div>
                                    
                                    <div class="aaiseo-form-group">
                                        <label><?php _e('Google Search Console', 'autonomous-ai-seo'); ?></label>
                                        <button type="button" class="aaiseo-btn aaiseo-btn-secondary" id="connect-gsc">
                                            <span class="dashicons dashicons-admin-links"></span>
                                            <?php _e('Connect Account', 'autonomous-ai-seo'); ?>
                                        </button>
                                        <small class="aaiseo-help-text"><?php _e('Connect to get search performance data', 'autonomous-ai-seo'); ?></small>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Automation Settings -->
                        <div id="automation" class="aaiseo-settings-section">
                            <div class="aaiseo-card">
                                <div class="aaiseo-card-header">
                                    <h3><?php _e('Automation Settings', 'autonomous-ai-seo'); ?></h3>
                                </div>
                                <div class="aaiseo-card-body">
                                    <div class="aaiseo-form-group">
                                        <label class="aaiseo-checkbox-label">
                                            <input type="checkbox" name="auto_optimize_content">
                                            <?php _e('Automatically optimize new content', 'autonomous-ai-seo'); ?>
                                        </label>
                                    </div>
                                    
                                    <div class="aaiseo-form-group">
                                        <label class="aaiseo-checkbox-label">
                                            <input type="checkbox" name="auto_generate_meta">
                                            <?php _e('Auto-generate meta descriptions', 'autonomous-ai-seo'); ?>
                                        </label>
                                    </div>
                                    
                                    <div class="aaiseo-form-group">
                                        <label class="aaiseo-checkbox-label">
                                            <input type="checkbox" name="auto_internal_linking">
                                            <?php _e('Suggest internal links automatically', 'autonomous-ai-seo'); ?>
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }
}

