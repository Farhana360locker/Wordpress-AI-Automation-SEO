<?php
/**
 * Analytics functionality for Autonomous AI SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Analytics {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize analytics
     */
    public function init() {
        // Schedule analytics collection
        add_action('aaiseo_daily_audit', array($this, 'collect_daily_analytics'));
        
        // Track page views
        add_action('wp', array($this, 'track_page_view'));
    }
    
    /**
     * Get performance metrics
     */
    public function getPerformanceMetrics($days = 30) {
        $core = new AAISEO_Core();
        $analytics_data = $core->get_analytics_data(0, '', $days);
        
        $metrics = array(
            'total_pages' => $this->get_total_pages(),
            'optimized_pages' => $this->get_optimized_pages(),
            'avg_seo_score' => $this->calculate_average_seo_score(),
            'traffic_trend' => $this->get_traffic_trend($days),
            'top_performing_pages' => $this->get_top_performing_pages(10),
            'issues_found' => $this->get_total_issues(),
            'improvements_made' => $this->get_total_improvements(),
            'keyword_rankings' => $this->get_keyword_rankings(),
            'core_web_vitals' => $this->get_core_web_vitals_summary()
        );
        
        return $metrics;
    }
    
    /**
     * Get predictive insights
     */
    public function getPredictiveInsights() {
        $insights = array();
        
        // Traffic prediction
        $traffic_trend = $this->get_traffic_trend(30);
        $traffic_prediction = $this->predict_traffic_growth($traffic_trend);
        
        $insights[] = array(
            'type' => 'traffic_prediction',
            'title' => __('Traffic Growth Prediction', 'autonomous-ai-seo'),
            'description' => sprintf(
                __('Based on current trends, your traffic is expected to %s by %s%% in the next 30 days.', 'autonomous-ai-seo'),
                $traffic_prediction['direction'],
                abs($traffic_prediction['percentage'])
            ),
            'confidence' => $traffic_prediction['confidence'],
            'priority' => $traffic_prediction['percentage'] > 10 ? 'high' : 'medium'
        );
        
        // SEO score prediction
        $seo_trend = $this->get_seo_score_trend(30);
        $seo_prediction = $this->predict_seo_improvement($seo_trend);
        
        $insights[] = array(
            'type' => 'seo_prediction',
            'title' => __('SEO Score Prediction', 'autonomous-ai-seo'),
            'description' => sprintf(
                __('Your SEO score is trending %s. Expected improvement: %s points in 30 days.', 'autonomous-ai-seo'),
                $seo_prediction['direction'],
                $seo_prediction['points']
            ),
            'confidence' => $seo_prediction['confidence'],
            'priority' => $seo_prediction['points'] > 5 ? 'high' : 'medium'
        );
        
        // Content opportunities
        $content_gaps = $this->identify_content_gaps();
        if (!empty($content_gaps)) {
            $insights[] = array(
                'type' => 'content_opportunity',
                'title' => __('Content Opportunities', 'autonomous-ai-seo'),
                'description' => sprintf(
                    __('We identified %d content gaps that could improve your rankings.', 'autonomous-ai-seo'),
                    count($content_gaps)
                ),
                'confidence' => 85,
                'priority' => 'high',
                'data' => $content_gaps
            );
        }
        
        return $insights;
    }
    
    /**
     * Track page view
     */
    public function track_page_view() {
        if (is_admin() || wp_doing_ajax() || wp_doing_cron()) {
            return;
        }
        
        global $post;
        
        if (!$post || !is_singular()) {
            return;
        }
        
        $core = new AAISEO_Core();
        
        // Get current view count
        $current_views = get_post_meta($post->ID, '_aaiseo_page_views', true);
        $current_views = $current_views ? intval($current_views) : 0;
        
        // Increment view count
        update_post_meta($post->ID, '_aaiseo_page_views', $current_views + 1);
        
        // Store daily analytics
        $today = current_time('Y-m-d');
        $core->store_analytics_data($post->ID, 'page_views', 1, $today);
    }
    
    /**
     * Collect daily analytics
     */
    public function collect_daily_analytics() {
        $core = new AAISEO_Core();
        $today = current_time('Y-m-d');
        
        // Collect site-wide metrics
        $metrics = array(
            'total_posts' => wp_count_posts('post')->publish,
            'total_pages' => wp_count_posts('page')->publish,
            'avg_seo_score' => $this->calculate_average_seo_score(),
            'total_issues' => $this->get_total_issues(),
            'optimized_content' => $this->get_optimized_pages()
        );
        
        foreach ($metrics as $metric_type => $value) {
            $core->store_analytics_data(0, $metric_type, $value, $today);
        }
        
        // Collect individual post metrics
        $posts = get_posts(array(
            'post_type' => array('post', 'page'),
            'post_status' => 'publish',
            'numberposts' => 100,
            'meta_query' => array(
                array(
                    'key' => '_aaiseo_last_analyzed',
                    'value' => date('Y-m-d', strtotime('-7 days')),
                    'compare' => '<='
                )
            )
        ));
        
        foreach ($posts as $post) {
            $this->collect_post_analytics($post->ID);
        }
    }
    
    /**
     * Collect analytics for specific post
     */
    private function collect_post_analytics($post_id) {
        $core = new AAISEO_Core();
        $today = current_time('Y-m-d');
        
        // Get SEO score
        $audit_results = $core->get_audit_results($post_id, 'ai_content_analysis');
        $seo_score = !empty($audit_results) ? $audit_results[0]->score : 0;
        
        // Get page views
        $page_views = get_post_meta($post_id, '_aaiseo_page_views', true);
        $page_views = $page_views ? intval($page_views) : 0;
        
        // Store metrics
        $core->store_analytics_data($post_id, 'seo_score', $seo_score, $today);
        $core->store_analytics_data($post_id, 'total_views', $page_views, $today);
        
        // Update last analyzed timestamp
        update_post_meta($post_id, '_aaiseo_last_analyzed', $today);
    }
    
    /**
     * Get total pages
     */
    private function get_total_pages() {
        $posts = wp_count_posts('post');
        $pages = wp_count_posts('page');
        return $posts->publish + $pages->publish;
    }
    
    /**
     * Get optimized pages count
     */
    private function get_optimized_pages() {
        global $wpdb;
        
        $count = $wpdb->get_var("
            SELECT COUNT(DISTINCT post_id) 
            FROM {$wpdb->prefix}aaiseo_audit_results 
            WHERE score >= 70
        ");
        
        return intval($count);
    }
    
    /**
     * Get traffic trend
     */
    private function get_traffic_trend($days = 30) {
        $core = new AAISEO_Core();
        $analytics_data = $core->get_analytics_data(0, 'page_views', $days);
        
        $daily_views = array();
        foreach ($analytics_data as $data) {
            $date = $data->date_recorded;
            if (!isset($daily_views[$date])) {
                $daily_views[$date] = 0;
            }
            $daily_views[$date] += intval($data->metric_value);
        }
        
        ksort($daily_views);
        return array_values($daily_views);
    }
    
    /**
     * Get top performing pages
     */
    private function get_top_performing_pages($limit = 10) {
        global $wpdb;
        
        $results = $wpdb->get_results($wpdb->prepare("
            SELECT p.ID, p.post_title, pm.meta_value as views, ar.score
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_aaiseo_page_views'
            LEFT JOIN {$wpdb->prefix}aaiseo_audit_results ar ON p.ID = ar.post_id AND ar.audit_type = 'ai_content_analysis'
            WHERE p.post_status = 'publish'
            AND p.post_type IN ('post', 'page')
            ORDER BY CAST(pm.meta_value AS UNSIGNED) DESC
            LIMIT %d
        ", $limit));
        
        $pages = array();
        foreach ($results as $result) {
            $pages[] = array(
                'id' => $result->ID,
                'title' => $result->post_title,
                'views' => intval($result->views),
                'seo_score' => intval($result->score),
                'url' => get_permalink($result->ID)
            );
        }
        
        return $pages;
    }
    
    /**
     * Get total issues
     */
    private function get_total_issues() {
        global $wpdb;
        
        $count = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM {$wpdb->prefix}aaiseo_audit_results 
            WHERE score < 70
            AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ");
        
        return intval($count);
    }
    
    /**
     * Get total improvements
     */
    private function get_total_improvements() {
        global $wpdb;
        
        $count = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM {$wpdb->prefix}aaiseo_content_optimization 
            WHERE status = 'completed'
            AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
        ");
        
        return intval($count);
    }
    
    /**
     * Get keyword rankings (mock data for now)
     */
    private function get_keyword_rankings() {
        return array(
            array('keyword' => 'SEO optimization', 'position' => 5, 'change' => '+2'),
            array('keyword' => 'WordPress SEO', 'position' => 12, 'change' => '+5'),
            array('keyword' => 'AI content', 'position' => 8, 'change' => '-1'),
            array('keyword' => 'Technical SEO', 'position' => 15, 'change' => '+3'),
            array('keyword' => 'Content marketing', 'position' => 22, 'change' => '+7')
        );
    }
    
    /**
     * Get Core Web Vitals summary
     */
    private function get_core_web_vitals_summary() {
        return array(
            'lcp' => array('value' => 2.1, 'status' => 'good'),
            'fid' => array('value' => 85, 'status' => 'good'),
            'cls' => array('value' => 0.08, 'status' => 'needs_improvement')
        );
    }
    
    /**
     * Predict traffic growth
     */
    private function predict_traffic_growth($traffic_data) {
        if (count($traffic_data) < 7) {
            return array(
                'direction' => 'stable',
                'percentage' => 0,
                'confidence' => 50
            );
        }
        
        $recent_avg = array_sum(array_slice($traffic_data, -7)) / 7;
        $previous_avg = array_sum(array_slice($traffic_data, -14, 7)) / 7;
        
        if ($previous_avg == 0) {
            return array(
                'direction' => 'stable',
                'percentage' => 0,
                'confidence' => 50
            );
        }
        
        $growth_rate = (($recent_avg - $previous_avg) / $previous_avg) * 100;
        $direction = $growth_rate > 0 ? 'increase' : ($growth_rate < 0 ? 'decrease' : 'stable');
        
        return array(
            'direction' => $direction,
            'percentage' => round(abs($growth_rate), 1),
            'confidence' => min(90, 60 + (count($traffic_data) * 2))
        );
    }
    
    /**
     * Predict SEO improvement
     */
    private function predict_seo_improvement($seo_data) {
        if (count($seo_data) < 5) {
            return array(
                'direction' => 'stable',
                'points' => 0,
                'confidence' => 50
            );
        }
        
        $recent_avg = array_sum(array_slice($seo_data, -5)) / 5;
        $previous_avg = array_sum(array_slice($seo_data, -10, 5)) / 5;
        
        $improvement = $recent_avg - $previous_avg;
        $direction = $improvement > 0 ? 'upward' : ($improvement < 0 ? 'downward' : 'stable');
        
        return array(
            'direction' => $direction,
            'points' => round(abs($improvement), 1),
            'confidence' => min(85, 55 + (count($seo_data) * 3))
        );
    }
    
    /**
     * Get SEO score trend
     */
    private function get_seo_score_trend($days = 30) {
        $core = new AAISEO_Core();
        $analytics_data = $core->get_analytics_data(0, 'seo_score', $days);
        
        $daily_scores = array();
        foreach ($analytics_data as $data) {
            $date = $data->date_recorded;
            if (!isset($daily_scores[$date])) {
                $daily_scores[$date] = array();
            }
            $daily_scores[$date][] = floatval($data->metric_value);
        }
        
        $trend = array();
        foreach ($daily_scores as $date => $scores) {
            $trend[] = array_sum($scores) / count($scores);
        }
        
        return $trend;
    }
    
    /**
     * Identify content gaps
     */
    private function identify_content_gaps() {
        // This would typically analyze competitor content and search trends
        // For now, return mock data
        return array(
            array(
                'topic' => 'Voice Search Optimization',
                'opportunity_score' => 85,
                'search_volume' => 2400,
                'competition' => 'medium'
            ),
            array(
                'topic' => 'Mobile SEO Best Practices',
                'opportunity_score' => 78,
                'search_volume' => 1800,
                'competition' => 'low'
            ),
            array(
                'topic' => 'Local SEO Strategies',
                'opportunity_score' => 92,
                'search_volume' => 3200,
                'competition' => 'high'
            )
        );
    }
    
    /**
     * Get SEO scores data
     */
    public function get_seo_scores_data($date_range, $page_url = '') {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        $where_clause = $this->build_date_where_clause($date_range, 'last_analyzed');
        
        if (!empty($page_url)) {
            $post_id = url_to_postid($page_url);
            if ($post_id) {
                $where_clause .= $wpdb->prepare(" AND post_id = %d", $post_id);
            }
        }
        
        $results = $wpdb->get_results(
            "SELECT seo_score, content_score, technical_score, last_analyzed, post_id 
             FROM $table_name 
             WHERE $where_clause 
             ORDER BY last_analyzed DESC"
        );
        
        $data = array();
        foreach ($results as $result) {
            $data[] = array(
                'date' => $result->last_analyzed,
                'seo_score' => intval($result->seo_score),
                'content_score' => intval($result->content_score),
                'technical_score' => intval($result->technical_score),
                'post_id' => intval($result->post_id),
                'post_title' => get_the_title($result->post_id)
            );
        }
        
        return $data;
    }
    
    /**
     * Get keyword rankings data
     */
    public function get_keyword_rankings_data($date_range, $page_url = '') {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'keyword_rankings';
        $where_clause = $this->build_date_where_clause($date_range, 'tracked_date');
        
        if (!empty($page_url)) {
            $where_clause .= $wpdb->prepare(" AND url = %s", $page_url);
        }
        
        $results = $wpdb->get_results(
            "SELECT keyword, position, previous_position, search_volume, difficulty, tracked_date, url 
             FROM $table_name 
             WHERE $where_clause 
             ORDER BY tracked_date DESC"
        );
        
        $data = array();
        foreach ($results as $result) {
            $data[] = array(
                'date' => $result->tracked_date,
                'keyword' => $result->keyword,
                'position' => intval($result->position),
                'previous_position' => intval($result->previous_position),
                'change' => intval($result->previous_position) - intval($result->position),
                'search_volume' => intval($result->search_volume),
                'difficulty' => intval($result->difficulty),
                'url' => $result->url
            );
        }
        
        return $data;
    }
    
    /**
     * Get traffic data
     */
    public function get_traffic_data($date_range, $page_url = '') {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'performance_metrics';
        $where_clause = $this->build_date_where_clause($date_range, 'recorded_date');
        $where_clause .= " AND metric_type = 'traffic'";
        
        if (!empty($page_url)) {
            $where_clause .= $wpdb->prepare(" AND page_url = %s", $page_url);
        }
        
        $results = $wpdb->get_results(
            "SELECT metric_name, metric_value, recorded_date, page_url 
             FROM $table_name 
             WHERE $where_clause 
             ORDER BY recorded_date DESC"
        );
        
        $data = array();
        foreach ($results as $result) {
            $data[] = array(
                'date' => $result->recorded_date,
                'metric' => $result->metric_name,
                'value' => floatval($result->metric_value),
                'page_url' => $result->page_url
            );
        }
        
        // If no data exists, generate sample data
        if (empty($data)) {
            $data = $this->generate_sample_traffic_data($date_range);
        }
        
        return $data;
    }
    
    /**
     * Get competitor data
     */
    public function get_competitor_data($date_range) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'competitor_data';
        $where_clause = $this->build_date_where_clause($date_range, 'last_analyzed');
        
        $results = $wpdb->get_results(
            "SELECT domain, company_name, organic_keywords, organic_traffic, backlinks, 
                    domain_authority, last_analyzed 
             FROM $table_name 
             WHERE $where_clause 
             ORDER BY last_analyzed DESC"
        );
        
        $data = array();
        foreach ($results as $result) {
            $data[] = array(
                'date' => $result->last_analyzed,
                'domain' => $result->domain,
                'company_name' => $result->company_name,
                'organic_keywords' => intval($result->organic_keywords),
                'organic_traffic' => intval($result->organic_traffic),
                'backlinks' => intval($result->backlinks),
                'domain_authority' => intval($result->domain_authority)
            );
        }
        
        // If no data exists, generate sample data
        if (empty($data)) {
            $data = $this->generate_sample_competitor_data();
        }
        
        return $data;
    }
    
    /**
     * Get technical issues data
     */
    public function get_technical_issues_data($date_range) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'performance_metrics';
        $where_clause = $this->build_date_where_clause($date_range, 'recorded_date');
        $where_clause .= " AND metric_type = 'technical'";
        
        $results = $wpdb->get_results(
            "SELECT metric_name, metric_value, recorded_date, page_url 
             FROM $table_name 
             WHERE $where_clause 
             ORDER BY recorded_date DESC"
        );
        
        $data = array();
        foreach ($results as $result) {
            $data[] = array(
                'date' => $result->recorded_date,
                'issue_type' => $result->metric_name,
                'severity' => floatval($result->metric_value),
                'page_url' => $result->page_url
            );
        }
        
        // If no data exists, generate sample data
        if (empty($data)) {
            $data = $this->generate_sample_technical_data();
        }
        
        return $data;
    }
    
    /**
     * Get overview data
     */
    public function get_overview_data($date_range) {
        $overview = array(
            'seo_scores' => $this->get_seo_scores_data($date_range),
            'keyword_rankings' => $this->get_keyword_rankings_data($date_range),
            'traffic_data' => $this->get_traffic_data($date_range),
            'technical_issues' => $this->get_technical_issues_data($date_range)
        );
        
        // Calculate summary metrics
        $overview['summary'] = array(
            'avg_seo_score' => $this->calculate_average_seo_score($overview['seo_scores']),
            'total_keywords' => count($overview['keyword_rankings']),
            'avg_position' => $this->calculate_average_position($overview['keyword_rankings']),
            'total_issues' => count($overview['technical_issues'])
        );
        
        return $overview;
    }
    
    /**
     * Format chart data
     */
    public function format_chart_data($data, $metric_type) {
        $chart_data = array(
            'labels' => array(),
            'datasets' => array()
        );
        
        switch ($metric_type) {
            case 'seo_scores':
                $chart_data = $this->format_seo_scores_chart($data);
                break;
                
            case 'keyword_rankings':
                $chart_data = $this->format_keyword_rankings_chart($data);
                break;
                
            case 'traffic_data':
                $chart_data = $this->format_traffic_chart($data);
                break;
                
            case 'competitor_data':
                $chart_data = $this->format_competitor_chart($data);
                break;
                
            case 'technical_issues':
                $chart_data = $this->format_technical_issues_chart($data);
                break;
                
            default:
                $chart_data = $this->format_overview_chart($data);
                break;
        }
        
        return $chart_data;
    }
    
    /**
     * Get data summary
     */
    public function get_data_summary($data, $metric_type) {
        $summary = array();
        
        switch ($metric_type) {
            case 'seo_scores':
                $summary = $this->get_seo_scores_summary($data);
                break;
                
            case 'keyword_rankings':
                $summary = $this->get_keyword_rankings_summary($data);
                break;
                
            case 'traffic_data':
                $summary = $this->get_traffic_summary($data);
                break;
                
            case 'competitor_data':
                $summary = $this->get_competitor_summary($data);
                break;
                
            case 'technical_issues':
                $summary = $this->get_technical_issues_summary($data);
                break;
                
            default:
                $summary = $this->get_overview_summary($data);
                break;
        }
        
        return $summary;
    }
    
    /**
     * Build date where clause
     */
    private function build_date_where_clause($date_range, $date_column) {
        global $wpdb;
        
        $where_clause = "1=1";
        
        switch ($date_range) {
            case 'today':
                $where_clause .= $wpdb->prepare(" AND DATE($date_column) = %s", current_time('Y-m-d'));
                break;
                
            case 'yesterday':
                $where_clause .= $wpdb->prepare(" AND DATE($date_column) = %s", date('Y-m-d', strtotime('-1 day')));
                break;
                
            case 'last_7_days':
                $where_clause .= $wpdb->prepare(" AND $date_column >= %s", date('Y-m-d H:i:s', strtotime('-7 days')));
                break;
                
            case 'last_30_days':
                $where_clause .= $wpdb->prepare(" AND $date_column >= %s", date('Y-m-d H:i:s', strtotime('-30 days')));
                break;
                
            case 'last_90_days':
                $where_clause .= $wpdb->prepare(" AND $date_column >= %s", date('Y-m-d H:i:s', strtotime('-90 days')));
                break;
                
            case 'this_month':
                $where_clause .= $wpdb->prepare(" AND MONTH($date_column) = %d AND YEAR($date_column) = %d", 
                    date('n'), date('Y'));
                break;
                
            case 'last_month':
                $last_month = date('Y-m-d', strtotime('first day of last month'));
                $last_month_end = date('Y-m-d', strtotime('last day of last month'));
                $where_clause .= $wpdb->prepare(" AND DATE($date_column) BETWEEN %s AND %s", 
                    $last_month, $last_month_end);
                break;
        }
        
        return $where_clause;
    }
    
    /**
     * Generate sample traffic data
     */
    private function generate_sample_traffic_data($date_range) {
        $data = array();
        $days = $this->get_days_from_range($date_range);
        
        for ($i = $days; $i >= 0; $i--) {
            $date = date('Y-m-d', strtotime("-$i days"));
            $base_traffic = rand(100, 500);
            
            $data[] = array(
                'date' => $date,
                'metric' => 'organic_sessions',
                'value' => $base_traffic + rand(-50, 100),
                'page_url' => home_url()
            );
            
            $data[] = array(
                'date' => $date,
                'metric' => 'page_views',
                'value' => ($base_traffic * 1.5) + rand(-75, 150),
                'page_url' => home_url()
            );
        }
        
        return $data;
    }
    
    /**
     * Generate sample competitor data
     */
    private function generate_sample_competitor_data() {
        return array(
            array(
                'date' => current_time('Y-m-d'),
                'domain' => 'competitor1.com',
                'company_name' => 'Competitor One',
                'organic_keywords' => rand(1000, 5000),
                'organic_traffic' => rand(10000, 50000),
                'backlinks' => rand(500, 2000),
                'domain_authority' => rand(40, 80)
            ),
            array(
                'date' => current_time('Y-m-d'),
                'domain' => 'competitor2.com',
                'company_name' => 'Competitor Two',
                'organic_keywords' => rand(800, 4000),
                'organic_traffic' => rand(8000, 40000),
                'backlinks' => rand(300, 1500),
                'domain_authority' => rand(35, 75)
            )
        );
    }
    
    /**
     * Generate sample technical data
     */
    private function generate_sample_technical_data() {
        return array(
            array(
                'date' => current_time('Y-m-d'),
                'issue_type' => 'page_speed',
                'severity' => rand(1, 10),
                'page_url' => home_url()
            ),
            array(
                'date' => current_time('Y-m-d'),
                'issue_type' => 'mobile_usability',
                'severity' => rand(1, 5),
                'page_url' => home_url()
            )
        );
    }
    
    /**
     * Get days from date range
     */
    private function get_days_from_range($date_range) {
        switch ($date_range) {
            case 'today':
            case 'yesterday':
                return 1;
            case 'last_7_days':
                return 7;
            case 'last_30_days':
                return 30;
            case 'last_90_days':
                return 90;
            default:
                return 30;
        }
    }
    
    /**
     * Format SEO scores chart
     */
    private function format_seo_scores_chart($data) {
        $labels = array();
        $seo_scores = array();
        $content_scores = array();
        $technical_scores = array();
        
        foreach ($data as $item) {
            $labels[] = date('M j', strtotime($item['date']));
            $seo_scores[] = $item['seo_score'];
            $content_scores[] = $item['content_score'];
            $technical_scores[] = $item['technical_score'];
        }
        
        return array(
            'labels' => $labels,
            'datasets' => array(
                array(
                    'label' => 'SEO Score',
                    'data' => $seo_scores,
                    'borderColor' => '#00d4aa',
                    'backgroundColor' => 'rgba(0, 212, 170, 0.1)'
                ),
                array(
                    'label' => 'Content Score',
                    'data' => $content_scores,
                    'borderColor' => '#ff6b6b',
                    'backgroundColor' => 'rgba(255, 107, 107, 0.1)'
                ),
                array(
                    'label' => 'Technical Score',
                    'data' => $technical_scores,
                    'borderColor' => '#4ecdc4',
                    'backgroundColor' => 'rgba(78, 205, 196, 0.1)'
                )
            )
        );
    }
    
    /**
     * Format keyword rankings chart
     */
    private function format_keyword_rankings_chart($data) {
        $labels = array();
        $positions = array();
        
        foreach ($data as $item) {
            $labels[] = $item['keyword'];
            $positions[] = $item['position'];
        }
        
        return array(
            'labels' => $labels,
            'datasets' => array(
                array(
                    'label' => 'Position',
                    'data' => $positions,
                    'borderColor' => '#45b7d1',
                    'backgroundColor' => 'rgba(69, 183, 209, 0.1)'
                )
            )
        );
    }
    
    /**
     * Format traffic chart
     */
    private function format_traffic_chart($data) {
        $labels = array();
        $sessions = array();
        $pageviews = array();
        
        $grouped_data = array();
        foreach ($data as $item) {
            $date = date('M j', strtotime($item['date']));
            if (!isset($grouped_data[$date])) {
                $grouped_data[$date] = array('sessions' => 0, 'pageviews' => 0);
            }
            
            if ($item['metric'] === 'organic_sessions') {
                $grouped_data[$date]['sessions'] = $item['value'];
            } elseif ($item['metric'] === 'page_views') {
                $grouped_data[$date]['pageviews'] = $item['value'];
            }
        }
        
        foreach ($grouped_data as $date => $values) {
            $labels[] = $date;
            $sessions[] = $values['sessions'];
            $pageviews[] = $values['pageviews'];
        }
        
        return array(
            'labels' => $labels,
            'datasets' => array(
                array(
                    'label' => 'Organic Sessions',
                    'data' => $sessions,
                    'borderColor' => '#96ceb4',
                    'backgroundColor' => 'rgba(150, 206, 180, 0.1)'
                ),
                array(
                    'label' => 'Page Views',
                    'data' => $pageviews,
                    'borderColor' => '#feca57',
                    'backgroundColor' => 'rgba(254, 202, 87, 0.1)'
                )
            )
        );
    }
    
    /**
     * Format competitor chart
     */
    private function format_competitor_chart($data) {
        $labels = array();
        $organic_traffic = array();
        $domain_authority = array();
        
        foreach ($data as $item) {
            $labels[] = $item['company_name'];
            $organic_traffic[] = $item['organic_traffic'];
            $domain_authority[] = $item['domain_authority'];
        }
        
        return array(
            'labels' => $labels,
            'datasets' => array(
                array(
                    'label' => 'Organic Traffic',
                    'data' => $organic_traffic,
                    'borderColor' => '#ff9ff3',
                    'backgroundColor' => 'rgba(255, 159, 243, 0.1)'
                ),
                array(
                    'label' => 'Domain Authority',
                    'data' => $domain_authority,
                    'borderColor' => '#54a0ff',
                    'backgroundColor' => 'rgba(84, 160, 255, 0.1)'
                )
            )
        );
    }
    
    /**
     * Format technical issues chart
     */
    private function format_technical_issues_chart($data) {
        $labels = array();
        $severity = array();
        
        foreach ($data as $item) {
            $labels[] = $item['issue_type'];
            $severity[] = $item['severity'];
        }
        
        return array(
            'labels' => $labels,
            'datasets' => array(
                array(
                    'label' => 'Severity',
                    'data' => $severity,
                    'borderColor' => '#ff6b6b',
                    'backgroundColor' => 'rgba(255, 107, 107, 0.1)'
                )
            )
        );
    }
    
    /**
     * Format overview chart
     */
    private function format_overview_chart($data) {
        // Create a combined overview chart
        return array(
            'labels' => array('SEO', 'Content', 'Technical', 'Rankings'),
            'datasets' => array(
                array(
                    'label' => 'Overall Performance',
                    'data' => array(
                        $data['summary']['avg_seo_score'],
                        rand(60, 90), // Content performance
                        rand(70, 95), // Technical performance
                        100 - $data['summary']['avg_position'] // Rankings (inverted)
                    ),
                    'borderColor' => '#00d4aa',
                    'backgroundColor' => 'rgba(0, 212, 170, 0.1)'
                )
            )
        );
    }
    
    /**
     * Calculate average SEO score
     */
    private function calculate_average_seo_score($seo_data) {
        if (empty($seo_data)) {
            return 0;
        }
        
        $total = 0;
        foreach ($seo_data as $item) {
            $total += $item['seo_score'];
        }
        
        return round($total / count($seo_data));
    }
    
    /**
     * Calculate average position
     */
    private function calculate_average_position($ranking_data) {
        if (empty($ranking_data)) {
            return 0;
        }
        
        $total = 0;
        foreach ($ranking_data as $item) {
            $total += $item['position'];
        }
        
        return round($total / count($ranking_data));
    }
    
    /**
     * Get SEO scores summary
     */
    private function get_seo_scores_summary($data) {
        return array(
            'total_pages' => count($data),
            'avg_seo_score' => $this->calculate_average_seo_score($data),
            'highest_score' => !empty($data) ? max(array_column($data, 'seo_score')) : 0,
            'lowest_score' => !empty($data) ? min(array_column($data, 'seo_score')) : 0
        );
    }
    
    /**
     * Get keyword rankings summary
     */
    private function get_keyword_rankings_summary($data) {
        return array(
            'total_keywords' => count($data),
            'avg_position' => $this->calculate_average_position($data),
            'top_10_keywords' => count(array_filter($data, function($item) { return $item['position'] <= 10; })),
            'improved_keywords' => count(array_filter($data, function($item) { return $item['change'] > 0; }))
        );
    }
    
    /**
     * Get traffic summary
     */
    private function get_traffic_summary($data) {
        $sessions = array_filter($data, function($item) { return $item['metric'] === 'organic_sessions'; });
        $pageviews = array_filter($data, function($item) { return $item['metric'] === 'page_views'; });
        
        return array(
            'total_sessions' => array_sum(array_column($sessions, 'value')),
            'total_pageviews' => array_sum(array_column($pageviews, 'value')),
            'avg_sessions_per_day' => !empty($sessions) ? round(array_sum(array_column($sessions, 'value')) / count($sessions)) : 0,
            'avg_pageviews_per_day' => !empty($pageviews) ? round(array_sum(array_column($pageviews, 'value')) / count($pageviews)) : 0
        );
    }
    
    /**
     * Get competitor summary
     */
    private function get_competitor_summary($data) {
        return array(
            'total_competitors' => count($data),
            'avg_domain_authority' => !empty($data) ? round(array_sum(array_column($data, 'domain_authority')) / count($data)) : 0,
            'total_competitor_traffic' => array_sum(array_column($data, 'organic_traffic')),
            'total_competitor_keywords' => array_sum(array_column($data, 'organic_keywords'))
        );
    }
    
    /**
     * Get technical issues summary
     */
    private function get_technical_issues_summary($data) {
        return array(
            'total_issues' => count($data),
            'high_severity_issues' => count(array_filter($data, function($item) { return $item['severity'] >= 7; })),
            'medium_severity_issues' => count(array_filter($data, function($item) { return $item['severity'] >= 4 && $item['severity'] < 7; })),
            'low_severity_issues' => count(array_filter($data, function($item) { return $item['severity'] < 4; }))
        );
    }
    
    /**
     * Get overview summary
     */
    private function get_overview_summary($data) {
        return array(
            'overall_health' => $data['summary']['avg_seo_score'],
            'total_keywords_tracked' => $data['summary']['total_keywords'],
            'avg_keyword_position' => $data['summary']['avg_position'],
            'total_technical_issues' => $data['summary']['total_issues'],
            'performance_trend' => $this->calculate_performance_trend($data)
        );
    }
    
    /**
     * Calculate performance trend
     */
    private function calculate_performance_trend($data) {
        // Simple trend calculation based on recent vs older data
        if (empty($data['seo_scores'])) {
            return 'stable';
        }
        
        $recent_scores = array_slice($data['seo_scores'], 0, 5);
        $older_scores = array_slice($data['seo_scores'], -5);
        
        $recent_avg = array_sum(array_column($recent_scores, 'seo_score')) / count($recent_scores);
        $older_avg = array_sum(array_column($older_scores, 'seo_score')) / count($older_scores);
        
        $difference = $recent_avg - $older_avg;
        
        if ($difference > 5) {
            return 'improving';
        } elseif ($difference < -5) {
            return 'declining';
        } else {
            return 'stable';
        }
    }
    
    /**
     * Generate daily report
     */
    public function generate_daily_report() {
        global $wpdb;
        
        // Get yesterday's data
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        
        // Collect daily metrics
        $report_data = array(
            'date' => $yesterday,
            'seo_scores' => $this->get_daily_seo_scores($yesterday),
            'keyword_rankings' => $this->get_daily_ranking_changes($yesterday),
            'technical_issues' => $this->get_daily_technical_issues($yesterday),
            'content_analysis' => $this->get_daily_content_analysis($yesterday)
        );
        
        // Store report
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'daily_reports';
        $wpdb->replace(
            $table_name,
            array(
                'report_date' => $yesterday,
                'report_data' => wp_json_encode($report_data),
                'generated_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s')
        );
        
        return $report_data;
    }
    
    /**
     * Generate weekly report
     */
    public function generate_weekly_report() {
        global $wpdb;
        
        // Get last week's date range
        $end_date = date('Y-m-d', strtotime('-1 day'));
        $start_date = date('Y-m-d', strtotime('-7 days'));
        
        // Collect weekly metrics
        $report_data = array(
            'week_ending' => $end_date,
            'date_range' => array('start' => $start_date, 'end' => $end_date),
            'summary' => $this->get_weekly_summary($start_date, $end_date),
            'top_performing_content' => $this->get_top_performing_content($start_date, $end_date),
            'ranking_improvements' => $this->get_ranking_improvements($start_date, $end_date),
            'technical_health' => $this->get_weekly_technical_health($start_date, $end_date),
            'recommendations' => $this->generate_weekly_recommendations($start_date, $end_date)
        );
        
        // Store report
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'weekly_reports';
        $wpdb->replace(
            $table_name,
            array(
                'week_ending' => $end_date,
                'report_data' => wp_json_encode($report_data),
                'generated_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s')
        );
        
        return $report_data;
    }
    
    /**
     * Get daily SEO scores
     */
    private function get_daily_seo_scores($date) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        $scores = $wpdb->get_results($wpdb->prepare(
            "SELECT post_id, seo_score FROM $table_name 
             WHERE DATE(analyzed_at) = %s 
             ORDER BY seo_score DESC",
            $date
        ));
        
        return $scores;
    }
    
    /**
     * Get daily ranking changes
     */
    private function get_daily_ranking_changes($date) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'keyword_rankings';
        $changes = $wpdb->get_results($wpdb->prepare(
            "SELECT keyword, position, previous_position, 
                    (previous_position - position) as change
             FROM $table_name 
             WHERE DATE(tracked_date) = %s 
             AND previous_position IS NOT NULL
             ORDER BY ABS(previous_position - position) DESC",
            $date
        ));
        
        return $changes;
    }
    
    /**
     * Get daily technical issues
     */
    private function get_daily_technical_issues($date) {
        // Get technical issues from options or database
        $issues = get_option('aaiseo_automated_check_results', array());
        
        return array(
            'total_issues' => $this->count_technical_issues($issues),
            'critical_issues' => $this->get_critical_issues($issues),
            'resolved_issues' => $this->get_resolved_issues($date)
        );
    }
    
    /**
     * Get daily content analysis
     */
    private function get_daily_content_analysis($date) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'content_analysis';
        $analysis = $wpdb->get_results($wpdb->prepare(
            "SELECT post_id, readability_score, keyword_density, word_count
             FROM $table_name 
             WHERE DATE(analyzed_at) = %s",
            $date
        ));
        
        return $analysis;
    }
    
    /**
     * Get weekly summary
     */
    private function get_weekly_summary($start_date, $end_date) {
        global $wpdb;
        
        // Calculate weekly averages and totals
        $seo_table = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        $avg_seo_score = $wpdb->get_var($wpdb->prepare(
            "SELECT AVG(seo_score) FROM $seo_table 
             WHERE analyzed_at BETWEEN %s AND %s",
            $start_date, $end_date
        ));
        
        return array(
            'avg_seo_score' => round($avg_seo_score, 1),
            'total_content_analyzed' => $this->get_content_analyzed_count($start_date, $end_date),
            'ranking_changes' => $this->get_ranking_changes_count($start_date, $end_date),
            'technical_score' => $this->get_weekly_technical_score($start_date, $end_date)
        );
    }
    
    /**
     * Helper methods for weekly report
     */
    private function get_content_analyzed_count($start_date, $end_date) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name 
             WHERE analyzed_at BETWEEN %s AND %s",
            $start_date, $end_date
        ));
    }
    
    /**
     * Get ranking changes count
     */
    private function get_ranking_changes_count($start_date, $end_date) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'keyword_rankings';
        return $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name 
             WHERE tracked_date BETWEEN %s AND %s 
             AND previous_position IS NOT NULL 
             AND position != previous_position",
            $start_date, $end_date
        ));
    }
    
    /**
     * Generate weekly recommendations
     */
    private function generate_weekly_recommendations($start_date, $end_date) {
        $recommendations = array();
        
        // Analyze performance and generate recommendations
        $low_scoring_content = $this->get_low_scoring_content($start_date, $end_date);
        if (!empty($low_scoring_content)) {
            $recommendations[] = array(
                'type' => 'content_optimization',
                'priority' => 'high',
                'message' => 'Focus on optimizing content with SEO scores below 70',
                'action_items' => array(
                    'Review keyword targeting',
                    'Improve content structure',
                    'Add internal links'
                )
            );
        }
        
        return $recommendations;
    }
    
    /**
     * Get low scoring content
     */
    private function get_low_scoring_content($start_date, $end_date) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        return $wpdb->get_results($wpdb->prepare(
            "SELECT post_id, seo_score FROM $table_name 
             WHERE analyzed_at BETWEEN %s AND %s 
             AND seo_score < 70 
             ORDER BY seo_score ASC",
            $start_date, $end_date
        ));
    }
}

