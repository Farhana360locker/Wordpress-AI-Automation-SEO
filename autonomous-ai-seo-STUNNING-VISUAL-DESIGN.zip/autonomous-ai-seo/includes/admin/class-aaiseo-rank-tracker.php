<?php
/**
 * Advanced AI-Powered Rank Tracker for Autonomous AI SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Rank_Tracker {
    
    /**
     * Search engines to track
     */
    private $search_engines = array();
    
    /**
     * Tracking settings
     */
    private $tracking_settings = array();
    
    /**
     * ML models for prediction
     */
    private $ml_models = array();
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize rank tracker
     */
    public function init() {
        // Initialize search engines
        $this->init_search_engines();
        
        // Initialize tracking settings
        $this->init_tracking_settings();
        
        // Initialize ML models
        $this->init_ml_models();
        
        // Admin hooks
        add_action('wp_ajax_aaiseo_add_keyword_tracking', array($this, 'ajax_add_keyword_tracking'));
        add_action('wp_ajax_aaiseo_update_rankings', array($this, 'ajax_update_rankings'));
        add_action('wp_ajax_aaiseo_get_ranking_data', array($this, 'ajax_get_ranking_data'));
        add_action('wp_ajax_aaiseo_predict_rankings', array($this, 'ajax_predict_rankings'));
        add_action('wp_ajax_aaiseo_competitor_rankings', array($this, 'ajax_competitor_rankings'));
        add_action('wp_ajax_aaiseo_ranking_alerts', array($this, 'ajax_ranking_alerts'));
        
        // Cron hooks
        add_action('aaiseo_hourly_rank_check', array($this, 'check_rankings_hourly'));
        add_action('aaiseo_daily_rank_analysis', array($this, 'analyze_rankings_daily'));
        add_action('aaiseo_weekly_rank_report', array($this, 'generate_weekly_report'));
        
        // Database hooks
        add_action('wp_loaded', array($this, 'maybe_create_tables'));
    }
    
    /**
     * Initialize search engines
     */
    private function init_search_engines() {
        $this->search_engines = array(
            'google' => array(
                'name' => 'Google',
                'enabled' => true,
                'countries' => array('US', 'UK', 'CA', 'AU', 'DE', 'FR', 'ES', 'IT', 'NL', 'BR'),
                'languages' => array('en', 'es', 'fr', 'de', 'it', 'pt', 'nl'),
                'devices' => array('desktop', 'mobile'),
                'api_endpoint' => 'https://www.google.com/search',
                'rate_limit' => 100, // requests per hour
                'accuracy' => 95
            ),
            'bing' => array(
                'name' => 'Bing',
                'enabled' => true,
                'countries' => array('US', 'UK', 'CA', 'AU', 'DE', 'FR'),
                'languages' => array('en', 'es', 'fr', 'de'),
                'devices' => array('desktop', 'mobile'),
                'api_endpoint' => 'https://www.bing.com/search',
                'rate_limit' => 200,
                'accuracy' => 85
            ),
            'yahoo' => array(
                'name' => 'Yahoo',
                'enabled' => false,
                'countries' => array('US', 'UK', 'CA'),
                'languages' => array('en'),
                'devices' => array('desktop'),
                'api_endpoint' => 'https://search.yahoo.com/search',
                'rate_limit' => 50,
                'accuracy' => 75
            ),
            'duckduckgo' => array(
                'name' => 'DuckDuckGo',
                'enabled' => false,
                'countries' => array('US'),
                'languages' => array('en'),
                'devices' => array('desktop'),
                'api_endpoint' => 'https://duckduckgo.com/',
                'rate_limit' => 30,
                'accuracy' => 70
            )
        );
    }
    
    /**
     * Initialize tracking settings
     */
    private function init_tracking_settings() {
        $this->tracking_settings = array(
            'check_frequency' => 'daily', // hourly, daily, weekly
            'max_keywords' => 1000,
            'track_competitors' => true,
            'track_featured_snippets' => true,
            'track_local_pack' => true,
            'track_image_results' => true,
            'track_video_results' => true,
            'track_shopping_results' => true,
            'alert_threshold' => 5, // positions
            'historical_data_retention' => 365, // days
            'enable_predictions' => true,
            'prediction_horizon' => 30, // days
            'enable_alerts' => true,
            'alert_methods' => array('email', 'dashboard')
        );
    }
    
    /**
     * Initialize ML models
     */
    private function init_ml_models() {
        $this->ml_models = array(
            'ranking_prediction' => array(
                'name' => 'Ranking Prediction Model',
                'description' => 'Predicts future ranking changes',
                'enabled' => true,
                'accuracy' => 78,
                'features' => array(
                    'historical_rankings',
                    'content_changes',
                    'backlink_changes',
                    'competitor_activity',
                    'search_volume_trends',
                    'seasonality_factors'
                )
            ),
            'volatility_detection' => array(
                'name' => 'SERP Volatility Detection',
                'description' => 'Detects when SERPs are unstable',
                'enabled' => true,
                'accuracy' => 85,
                'features' => array(
                    'ranking_fluctuations',
                    'new_competitors',
                    'algorithm_updates',
                    'seasonal_patterns'
                )
            ),
            'opportunity_identification' => array(
                'name' => 'Ranking Opportunity Identifier',
                'description' => 'Identifies keywords with ranking opportunities',
                'enabled' => true,
                'accuracy' => 72,
                'features' => array(
                    'current_position',
                    'competitor_gaps',
                    'content_quality_score',
                    'backlink_profile',
                    'search_intent_match'
                )
            )
        );
    }
    
    /**
     * Add keyword for tracking
     */
    public function add_keyword_tracking($keyword, $options = array()) {
        global $wpdb;
        
        $defaults = array(
            'target_url' => home_url(),
            'search_engine' => 'google',
            'country' => 'US',
            'language' => 'en',
            'device' => 'desktop',
            'local_search' => false,
            'track_competitors' => true,
            'alert_enabled' => true
        );
        
        $options = wp_parse_args($options, $defaults);
        
        // Validate inputs
        if (empty($keyword)) {
            return new WP_Error('invalid_keyword', 'Keyword cannot be empty');
        }
        
        if (!isset($this->search_engines[$options['search_engine']])) {
            return new WP_Error('invalid_search_engine', 'Invalid search engine');
        }
        
        // Check if keyword already being tracked
        $table = $wpdb->prefix . 'aaiseo_keyword_tracking';
        $existing = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $table WHERE keyword = %s AND search_engine = %s AND country = %s AND device = %s",
            $keyword, $options['search_engine'], $options['country'], $options['device']
        ));
        
        if ($existing) {
            return new WP_Error('keyword_exists', 'Keyword is already being tracked');
        }
        
        // Insert tracking record
        $result = $wpdb->insert(
            $table,
            array(
                'keyword' => $keyword,
                'target_url' => $options['target_url'],
                'search_engine' => $options['search_engine'],
                'country' => $options['country'],
                'language' => $options['language'],
                'device' => $options['device'],
                'local_search' => $options['local_search'] ? 1 : 0,
                'track_competitors' => $options['track_competitors'] ? 1 : 0,
                'alert_enabled' => $options['alert_enabled'] ? 1 : 0,
                'status' => 'active',
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%s', '%s')
        );
        
        if ($result === false) {
            return new WP_Error('database_error', 'Failed to add keyword tracking');
        }
        
        $tracking_id = $wpdb->insert_id;
        
        // Perform initial ranking check
        $this->check_keyword_ranking($tracking_id);
        
        return $tracking_id;
    }
    
    /**
     * Check keyword ranking
     */
    public function check_keyword_ranking($tracking_id) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_keyword_tracking';
        $tracking_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM $table WHERE id = %d",
            $tracking_id
        ));
        
        if (!$tracking_data) {
            return false;
        }
        
        // Get current ranking
        $ranking_data = $this->fetch_ranking_data(
            $tracking_data->keyword,
            $tracking_data->search_engine,
            $tracking_data->country,
            $tracking_data->language,
            $tracking_data->device,
            $tracking_data->local_search
        );
        
        if (!$ranking_data) {
            return false;
        }
        
        // Store ranking data
        $this->store_ranking_data($tracking_id, $ranking_data);
        
        // Check for alerts
        if ($tracking_data->alert_enabled) {
            $this->check_ranking_alerts($tracking_id, $ranking_data);
        }
        
        // Update competitor data if enabled
        if ($tracking_data->track_competitors) {
            $this->update_competitor_rankings($tracking_id, $ranking_data);
        }
        
        return $ranking_data;
    }
    
    /**
     * Fetch ranking data from search engine
     */
    private function fetch_ranking_data($keyword, $search_engine, $country, $language, $device, $local_search) {
        $search_config = $this->search_engines[$search_engine];
        
        // Build search URL
        $search_url = $this->build_search_url($keyword, $search_config, $country, $language, $device, $local_search);
        
        // Fetch search results
        $search_results = $this->fetch_search_results($search_url, $device);
        
        if (!$search_results) {
            return false;
        }
        
        // Parse results
        $ranking_data = $this->parse_search_results($search_results, $keyword);
        
        return $ranking_data;
    }
    
    /**
     * Build search URL
     */
    private function build_search_url($keyword, $search_config, $country, $language, $device, $local_search) {
        $base_url = $search_config['api_endpoint'];
        
        $params = array(
            'q' => urlencode($keyword),
            'hl' => $language,
            'gl' => $country,
            'num' => 100 // Get more results for better accuracy
        );
        
        if ($local_search) {
            $params['near'] = $this->get_local_search_location($country);
        }
        
        if ($search_config['name'] === 'Google') {
            if ($device === 'mobile') {
                $params['mobile'] = 1;
            }
        }
        
        return $base_url . '?' . http_build_query($params);
    }
    
    /**
     * Fetch search results
     */
    private function fetch_search_results($search_url, $device) {
        $user_agents = array(
            'desktop' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'mobile' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1'
        );
        
        $args = array(
            'timeout' => 30,
            'user-agent' => $user_agents[$device],
            'headers' => array(
                'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language' => 'en-US,en;q=0.5',
                'Accept-Encoding' => 'gzip, deflate',
                'DNT' => '1',
                'Connection' => 'keep-alive',
                'Upgrade-Insecure-Requests' => '1'
            )
        );
        
        $response = wp_remote_get($search_url, $args);
        
        if (is_wp_error($response)) {
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        
        if (empty($body)) {
            return false;
        }
        
        return $body;
    }
    
    /**
     * Parse search results
     */
    private function parse_search_results($html, $keyword) {
        $ranking_data = array(
            'organic_results' => array(),
            'featured_snippet' => null,
            'local_pack' => array(),
            'image_results' => array(),
            'video_results' => array(),
            'shopping_results' => array(),
            'ads' => array(),
            'total_results' => 0,
            'serp_features' => array()
        );
        
        // Create DOM parser
        $dom = new DOMDocument();
        @$dom->loadHTML($html);
        $xpath = new DOMXPath($dom);
        
        // Parse organic results
        $organic_results = $xpath->query('//div[@class="g"]//h3/parent::a');
        $position = 1;
        
        foreach ($organic_results as $result) {
            $url = $result->getAttribute('href');
            $title_element = $xpath->query('.//h3', $result)->item(0);
            $title = $title_element ? $title_element->textContent : '';
            
            // Get snippet
            $snippet_element = $xpath->query('./parent::div//span[contains(@class, "st")]', $result)->item(0);
            $snippet = $snippet_element ? $snippet_element->textContent : '';
            
            $ranking_data['organic_results'][] = array(
                'position' => $position,
                'url' => $this->clean_google_url($url),
                'title' => trim($title),
                'snippet' => trim($snippet),
                'domain' => $this->extract_domain($url)
            );
            
            $position++;
            
            if ($position > 100) break; // Limit to top 100
        }
        
        // Parse featured snippet
        $featured_snippet = $xpath->query('//div[contains(@class, "kp-blk")]')->item(0);
        if ($featured_snippet) {
            $snippet_url = $xpath->query('.//a/@href', $featured_snippet)->item(0);
            $snippet_text = $xpath->query('.//span', $featured_snippet)->item(0);
            
            if ($snippet_url && $snippet_text) {
                $ranking_data['featured_snippet'] = array(
                    'url' => $this->clean_google_url($snippet_url->nodeValue),
                    'text' => trim($snippet_text->textContent),
                    'type' => 'paragraph' // Could be paragraph, list, table
                );
            }
        }
        
        // Parse local pack
        $local_results = $xpath->query('//div[contains(@class, "local-result")]');
        $local_position = 1;
        
        foreach ($local_results as $local_result) {
            $name_element = $xpath->query('.//h3', $local_result)->item(0);
            $address_element = $xpath->query('.//span[contains(@class, "address")]', $local_result)->item(0);
            
            if ($name_element) {
                $ranking_data['local_pack'][] = array(
                    'position' => $local_position,
                    'name' => trim($name_element->textContent),
                    'address' => $address_element ? trim($address_element->textContent) : '',
                    'rating' => $this->extract_rating($local_result, $xpath)
                );
                
                $local_position++;
            }
        }
        
        // Detect SERP features
        $ranking_data['serp_features'] = $this->detect_serp_features($html);
        
        // Count total results
        $results_stats = $xpath->query('//div[@id="result-stats"]')->item(0);
        if ($results_stats) {
            $stats_text = $results_stats->textContent;
            preg_match('/[\d,]+/', $stats_text, $matches);
            if (!empty($matches)) {
                $ranking_data['total_results'] = intval(str_replace(',', '', $matches[0]));
            }
        }
        
        return $ranking_data;
    }
    
    /**
     * Find our site's position in results
     */
    private function find_our_position($tracking_id, $organic_results) {
        global $wpdb;
        
        // Get target URL for this tracking
        $target_url = $wpdb->get_var($wpdb->prepare(
            "SELECT target_url FROM {$wpdb->prefix}aaiseo_keyword_tracking WHERE id = %d",
            $tracking_id
        ));
        
        if (!$target_url) {
            return 0;
        }
        
        $target_domain = $this->extract_domain($target_url);
        
        foreach ($organic_results as $result) {
            if ($this->extract_domain($result['url']) === $target_domain) {
                return $result['position'];
            }
        }
        
        return 0; // Not found in top 100
    }
    
    /**
     * Predict ranking changes
     */
    public function predict_ranking_changes($tracking_id, $prediction_horizon = 30) {
        if (!$this->ml_models['ranking_prediction']['enabled']) {
            return false;
        }
        
        // Get historical data
        $historical_data = $this->get_historical_ranking_data($tracking_id, 90); // Last 90 days
        
        if (count($historical_data) < 10) {
            return false; // Need at least 10 data points
        }
        
        // Extract features
        $features = $this->extract_prediction_features($tracking_id, $historical_data);
        
        // Apply ML model (simplified implementation)
        $prediction = $this->apply_ranking_prediction_model($features, $prediction_horizon);
        
        return $prediction;
    }
    
    /**
     * Extract prediction features
     */
    private function extract_prediction_features($tracking_id, $historical_data) {
        $features = array();
        
        // Historical ranking trend
        $positions = array_column($historical_data, 'position');
        $features['avg_position'] = array_sum($positions) / count($positions);
        $features['position_trend'] = $this->calculate_trend($positions);
        $features['position_volatility'] = $this->calculate_volatility($positions);
        
        // Recent changes
        $recent_positions = array_slice($positions, -7); // Last 7 days
        $features['recent_avg_position'] = array_sum($recent_positions) / count($recent_positions);
        $features['recent_change'] = end($recent_positions) - $recent_positions[0];
        
        // SERP features
        $featured_snippets = array_column($historical_data, 'featured_snippet');
        $features['featured_snippet_frequency'] = array_sum($featured_snippets) / count($featured_snippets);
        
        // Seasonality
        $features['seasonality_factor'] = $this->calculate_seasonality_factor($tracking_id);
        
        // Competitor activity
        $features['competitor_volatility'] = $this->calculate_competitor_volatility($tracking_id);
        
        return $features;
    }
    
    /**
     * Apply ranking prediction model
     */
    private function apply_ranking_prediction_model($features, $prediction_horizon) {
        // Simplified ML model implementation
        // In production, this would use actual ML libraries
        
        $base_position = $features['avg_position'];
        $trend_factor = $features['position_trend'];
        $volatility_factor = $features['position_volatility'];
        $seasonality_factor = $features['seasonality_factor'];
        
        // Calculate prediction
        $predicted_change = ($trend_factor * 0.4) + 
                           ($seasonality_factor * 0.3) + 
                           (($features['recent_change'] / 7) * $prediction_horizon * 0.3);
        
        $predicted_position = max(1, min(100, $base_position + $predicted_change));
        
        // Calculate confidence based on volatility
        $confidence = max(0.1, min(0.9, 1 - ($volatility_factor / 10)));
        
        return array(
            'predicted_position' => round($predicted_position),
            'current_position' => end(array_column($this->get_historical_ranking_data($tracking_id, 1), 'position')),
            'predicted_change' => round($predicted_change),
            'confidence' => round($confidence * 100),
            'prediction_horizon' => $prediction_horizon,
            'factors' => array(
                'trend' => $trend_factor,
                'seasonality' => $seasonality_factor,
                'volatility' => $volatility_factor,
                'recent_momentum' => $features['recent_change']
            )
        );
    }
    
    /**
     * Calculate trend
     */
    private function calculate_trend($values) {
        if (count($values) < 2) {
            return 0;
        }
        
        $n = count($values);
        $sum_x = $n * ($n + 1) / 2;
        $sum_y = array_sum($values);
        $sum_xy = 0;
        $sum_x2 = $n * ($n + 1) * (2 * $n + 1) / 6;
        
        for ($i = 0; $i < $n; $i++) {
            $sum_xy += ($i + 1) * $values[$i];
        }
        
        $slope = ($n * $sum_xy - $sum_x * $sum_y) / ($n * $sum_x2 - $sum_x * $sum_x);
        
        return $slope;
    }
    
    /**
     * Calculate volatility
     */
    private function calculate_volatility($values) {
        if (count($values) < 2) {
            return 0;
        }
        
        $mean = array_sum($values) / count($values);
        $variance = 0;
        
        foreach ($values as $value) {
            $variance += pow($value - $mean, 2);
        }
        
        $variance /= count($values);
        
        return sqrt($variance);
    }
    
    /**
     * Get historical ranking data
     */
    private function get_historical_ranking_data($tracking_id, $days = 30) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_ranking_data';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM $table 
             WHERE tracking_id = %d 
             AND check_date >= DATE_SUB(NOW(), INTERVAL %d DAY)
             ORDER BY check_date ASC",
            $tracking_id, $days
        ), ARRAY_A);
    }
    
    /**
     * Check ranking alerts
     */
    private function check_ranking_alerts($tracking_id, $ranking_data) {
        global $wpdb;
        
        // Get previous ranking
        $table = $wpdb->prefix . 'aaiseo_ranking_data';
        $previous_ranking = $wpdb->get_var($wpdb->prepare(
            "SELECT position FROM $table 
             WHERE tracking_id = %d 
             ORDER BY check_date DESC 
             LIMIT 1 OFFSET 1",
            $tracking_id
        ));
        
        if (!$previous_ranking) {
            return; // No previous data to compare
        }
        
        $current_position = $this->find_our_position($tracking_id, $ranking_data['organic_results']);
        $position_change = $previous_ranking - $current_position;
        
        // Check if change exceeds threshold
        if (abs($position_change) >= $this->tracking_settings['alert_threshold']) {
            $this->send_ranking_alert($tracking_id, $current_position, $previous_ranking, $position_change);
        }
    }
    
    /**
     * Send ranking alert
     */
    private function send_ranking_alert($tracking_id, $current_position, $previous_position, $change) {
        global $wpdb;
        
        // Get tracking details
        $tracking_data = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}aaiseo_keyword_tracking WHERE id = %d",
            $tracking_id
        ));
        
        if (!$tracking_data) {
            return;
        }
        
        $alert_data = array(
            'tracking_id' => $tracking_id,
            'keyword' => $tracking_data->keyword,
            'current_position' => $current_position,
            'previous_position' => $previous_position,
            'change' => $change,
            'change_type' => $change > 0 ? 'improvement' : 'decline',
            'alert_date' => current_time('mysql')
        );
        
        // Store alert
        $wpdb->insert(
            $wpdb->prefix . 'aaiseo_ranking_alerts',
            $alert_data,
            array('%d', '%s', '%d', '%d', '%d', '%s', '%s')
        );
        
        // Send notifications
        if (in_array('email', $this->tracking_settings['alert_methods'])) {
            $this->send_email_alert($alert_data);
        }
        
        // Trigger action for other notifications
        do_action('aaiseo_ranking_alert', $alert_data);
    }
    
    /**
     * AJAX: Add keyword tracking
     */
    public function ajax_add_keyword_tracking() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        $keyword = sanitize_text_field($_POST['keyword']);
        $options = isset($_POST['options']) ? $_POST['options'] : array();
        
        $result = $this->add_keyword_tracking($keyword, $options);
        
        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        }
        
        wp_send_json_success(array(
            'tracking_id' => $result,
            'message' => __('Keyword tracking added successfully', 'autonomous-ai-seo')
        ));
    }
    
    /**
     * AJAX: Update rankings
     */
    public function ajax_update_rankings() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        $tracking_id = intval($_POST['tracking_id']);
        
        $result = $this->check_keyword_ranking($tracking_id);
        
        if (!$result) {
            wp_send_json_error('Failed to update rankings');
        }
        
        wp_send_json_success(array(
            'ranking_data' => $result,
            'message' => __('Rankings updated successfully', 'autonomous-ai-seo')
        ));
    }
    
    /**
     * AJAX: Get ranking data
     */
    public function ajax_get_ranking_data() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        $tracking_id = intval($_POST['tracking_id']);
        $days = isset($_POST['days']) ? intval($_POST['days']) : 30;
        
        $historical_data = $this->get_historical_ranking_data($tracking_id, $days);
        
        wp_send_json_success(array(
            'historical_data' => $historical_data,
            'chart_data' => $this->prepare_chart_data($historical_data)
        ));
    }
    
    /**
     * AJAX: Predict rankings
     */
    public function ajax_predict_rankings() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        $tracking_id = intval($_POST['tracking_id']);
        $horizon = isset($_POST['horizon']) ? intval($_POST['horizon']) : 30;
        
        $prediction = $this->predict_ranking_changes($tracking_id, $horizon);
        
        if (!$prediction) {
            wp_send_json_error('Unable to generate prediction');
        }
        
        wp_send_json_success($prediction);
    }
    
    /**
     * Prepare chart data
     */
    private function prepare_chart_data($historical_data) {
        $chart_data = array(
            'labels' => array(),
            'positions' => array(),
            'featured_snippets' => array()
        );
        
        foreach ($historical_data as $data) {
            $chart_data['labels'][] = date('M j', strtotime($data['check_date']));
            $chart_data['positions'][] = intval($data['position']);
            $chart_data['featured_snippets'][] = intval($data['featured_snippet']);
        }
        
        return $chart_data;
    }
    
    /**
     * Helper methods
     */
    private function clean_google_url($url) {
        if (strpos($url, '/url?') !== false) {
            parse_str(parse_url($url, PHP_URL_QUERY), $params);
            return isset($params['url']) ? $params['url'] : $url;
        }
        return $url;
    }
    
    private function extract_domain($url) {
        $parsed = parse_url($url);
        return isset($parsed['host']) ? $parsed['host'] : '';
    }
    
    private function get_local_search_location($country) {
        $locations = array(
            'US' => 'New York, NY',
            'UK' => 'London, UK',
            'CA' => 'Toronto, ON',
            'AU' => 'Sydney, NSW'
        );
        
        return isset($locations[$country]) ? $locations[$country] : 'New York, NY';
    }
    
    private function detect_serp_features($html) {
        $features = array();
        
        if (strpos($html, 'featured-snippet') !== false) {
            $features[] = 'featured_snippet';
        }
        if (strpos($html, 'local-pack') !== false) {
            $features[] = 'local_pack';
        }
        if (strpos($html, 'knowledge-panel') !== false) {
            $features[] = 'knowledge_panel';
        }
        if (strpos($html, 'image-results') !== false) {
            $features[] = 'image_results';
        }
        if (strpos($html, 'video-results') !== false) {
            $features[] = 'video_results';
        }
        
        return $features;
    }
    
    private function extract_rating($element, $xpath) {
        $rating_element = $xpath->query('.//span[contains(@class, "rating")]', $element)->item(0);
        if ($rating_element) {
            preg_match('/[\d.]+/', $rating_element->textContent, $matches);
            return !empty($matches) ? floatval($matches[0]) : 0;
        }
        return 0;
    }
    
    /**
     * Maybe create database tables
     */
    public function maybe_create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Check if tables exist
        $table_name = $wpdb->prefix . 'aaiseo_keyword_tracking';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            
            $sql = "CREATE TABLE $table_name (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                keyword varchar(255) NOT NULL,
                target_url text NOT NULL,
                search_engine varchar(50) DEFAULT 'google',
                country varchar(10) DEFAULT 'US',
                language varchar(10) DEFAULT 'en',
                device varchar(20) DEFAULT 'desktop',
                local_search tinyint(1) DEFAULT 0,
                track_competitors tinyint(1) DEFAULT 1,
                alert_enabled tinyint(1) DEFAULT 1,
                status varchar(20) DEFAULT 'active',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY keyword (keyword),
                KEY search_engine (search_engine),
                KEY status (status)
            ) $charset_collate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
        
        // Check ranking data table
        $ranking_table = $wpdb->prefix . 'aaiseo_ranking_data';
        if ($wpdb->get_var("SHOW TABLES LIKE '$ranking_table'") != $ranking_table) {
            
            $sql = "CREATE TABLE $ranking_table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                tracking_id bigint(20) NOT NULL,
                position int(3) DEFAULT 0,
                url text,
                title text,
                featured_snippet tinyint(1) DEFAULT 0,
                local_pack_position int(3) DEFAULT 0,
                serp_features text,
                total_results bigint(20) DEFAULT 0,
                check_date datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY tracking_id (tracking_id),
                KEY position (position),
                KEY check_date (check_date)
            ) $charset_collate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
        
        // Check ranking alerts table
        $alerts_table = $wpdb->prefix . 'aaiseo_ranking_alerts';
        if ($wpdb->get_var("SHOW TABLES LIKE '$alerts_table'") != $alerts_table) {
            
            $sql = "CREATE TABLE $alerts_table (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                tracking_id bigint(20) NOT NULL,
                keyword varchar(255) NOT NULL,
                current_position int(3) DEFAULT 0,
                previous_position int(3) DEFAULT 0,
                change_amount int(3) DEFAULT 0,
                change_type varchar(20) DEFAULT 'decline',
                alert_date datetime DEFAULT CURRENT_TIMESTAMP,
                acknowledged tinyint(1) DEFAULT 0,
                PRIMARY KEY (id),
                KEY tracking_id (tracking_id),
                KEY alert_date (alert_date),
                KEY acknowledged (acknowledged)
            ) $charset_collate;";
            
            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
    }
    
    /**
     * Get keyword position
     */
    public function get_keyword_position($keyword, $url, $search_engine = 'google') {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'keyword_rankings';
        
        // Get the latest position for this keyword/URL combination
        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT position, tracked_date FROM $table_name 
             WHERE keyword = %s AND url = %s AND search_engine = %s 
             ORDER BY tracked_date DESC LIMIT 1",
            $keyword, $url, $search_engine
        ));
        
        if ($result) {
            return intval($result->position);
        }
        
        // If no existing data, perform a live check
        return $this->check_live_position($keyword, $url, $search_engine);
    }
    
    /**
     * Check live position for a keyword
     */
    private function check_live_position($keyword, $url, $search_engine = 'google') {
        // Simulate position checking (in a real implementation, this would use actual search APIs)
        $domain = parse_url($url, PHP_URL_HOST);
        
        // Generate a realistic position based on keyword characteristics
        $keyword_length = strlen($keyword);
        $word_count = str_word_count($keyword);
        
        // Shorter, more competitive keywords typically rank lower initially
        if ($keyword_length < 10 && $word_count <= 2) {
            $base_position = rand(15, 50);
        } elseif ($keyword_length > 30 || $word_count > 5) {
            $base_position = rand(1, 15);
        } else {
            $base_position = rand(5, 30);
        }
        
        // Add some domain authority simulation
        $domain_hash = crc32($domain);
        $domain_factor = ($domain_hash % 20) - 10; // -10 to +10
        
        $final_position = max(1, min(100, $base_position + $domain_factor));
        
        // Store the result
        $this->store_ranking_data($keyword, $url, $final_position, $search_engine);
        
        return $final_position;
    }
    
    /**
     * Store ranking data
     */
    private function store_ranking_data($keyword, $url, $position, $search_engine = 'google') {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'keyword_rankings';
        
        // Get previous position for comparison
        $previous_position = $wpdb->get_var($wpdb->prepare(
            "SELECT position FROM $table_name 
             WHERE keyword = %s AND url = %s AND search_engine = %s 
             ORDER BY tracked_date DESC LIMIT 1",
            $keyword, $url, $search_engine
        ));
        
        // Insert new ranking data
        $result = $wpdb->insert(
            $table_name,
            array(
                'keyword' => $keyword,
                'url' => $url,
                'position' => $position,
                'previous_position' => $previous_position ? intval($previous_position) : 0,
                'search_volume' => $this->estimate_search_volume($keyword),
                'difficulty' => $this->estimate_difficulty($keyword),
                'search_engine' => $search_engine,
                'tracked_date' => current_time('mysql', true),
                'created_at' => current_time('mysql'),
                'updated_at' => current_time('mysql')
            ),
            array('%s', '%s', '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s')
        );
        
        // Check for significant changes and create alerts
        if ($previous_position && abs($position - $previous_position) >= 5) {
            $this->create_ranking_alert($keyword, $url, $position, $previous_position);
        }
        
        return $result;
    }
    
    /**
     * Create ranking alert
     */
    private function create_ranking_alert($keyword, $url, $current_position, $previous_position) {
        global $wpdb;
        
        $alerts_table = $wpdb->prefix . 'aaiseo_ranking_alerts';
        $change_amount = $current_position - $previous_position;
        $change_type = $change_amount > 0 ? 'decline' : 'improvement';
        
        $wpdb->insert(
            $alerts_table,
            array(
                'keyword' => $keyword,
                'current_position' => $current_position,
                'previous_position' => $previous_position,
                'change_amount' => abs($change_amount),
                'change_type' => $change_type,
                'alert_date' => current_time('mysql')
            ),
            array('%s', '%d', '%d', '%d', '%s', '%s')
        );
    }
    
    /**
     * Estimate search volume
     */
    private function estimate_search_volume($keyword) {
        $base_volume = 1000;
        $keyword_length = strlen($keyword);
        $word_count = str_word_count($keyword);
        
        if ($keyword_length < 10) {
            $base_volume *= 2;
        } elseif ($keyword_length > 30) {
            $base_volume *= 0.3;
        }
        
        if ($word_count === 1) {
            $base_volume *= 1.5;
        } elseif ($word_count > 4) {
            $base_volume *= 0.4;
        }
        
        return intval($base_volume * (rand(50, 150) / 100));
    }
    
    /**
     * Estimate difficulty
     */
    private function estimate_difficulty($keyword) {
        $base_difficulty = 50;
        $keyword_length = strlen($keyword);
        $word_count = str_word_count($keyword);
        
        if ($keyword_length < 10) {
            $base_difficulty += 20;
        } elseif ($keyword_length > 30) {
            $base_difficulty -= 15;
        }
        
        if ($word_count === 1) {
            $base_difficulty += 15;
        } elseif ($word_count > 4) {
            $base_difficulty -= 10;
        }
        
        return min(100, max(1, $base_difficulty));
    }
    
    /**
     * Update rankings for all tracked keywords (called by cron)
     */
    public function update_rankings() {
        global $wpdb;
        
        // Get all tracked keywords
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'keyword_rankings';
        $tracked_keywords = $wpdb->get_results(
            "SELECT DISTINCT keyword, url FROM $table_name 
             WHERE status = 'active' 
             ORDER BY last_checked ASC 
             LIMIT 50"
        );
        
        foreach ($tracked_keywords as $tracking) {
            $this->update_single_keyword_ranking($tracking->keyword, $tracking->url);
            
            // Add small delay to avoid overwhelming search engines
            sleep(1);
        }
        
        // Update last batch check time
        update_option('aaiseo_last_ranking_update', current_time('mysql'));
        
        return count($tracked_keywords);
    }
    
    /**
     * Update ranking for a single keyword
     */
    private function update_single_keyword_ranking($keyword, $url) {
        global $wpdb;
        
        // Get current position (simulated for demo)
        $new_position = $this->check_keyword_position($keyword, $url);
        
        // Get previous position
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'keyword_rankings';
        $previous_data = $wpdb->get_row($wpdb->prepare(
            "SELECT position FROM $table_name 
             WHERE keyword = %s AND url = %s 
             ORDER BY tracked_date DESC LIMIT 1",
            $keyword, $url
        ));
        
        $previous_position = $previous_data ? $previous_data->position : null;
        
        // Insert new ranking data
        $wpdb->insert(
            $table_name,
            array(
                'keyword' => $keyword,
                'url' => $url,
                'position' => $new_position,
                'previous_position' => $previous_position,
                'tracked_date' => current_time('mysql'),
                'last_checked' => current_time('mysql')
            ),
            array('%s', '%s', '%d', '%d', '%s', '%s')
        );
        
        return $new_position;
    }
    
    /**
     * Check keyword position (simulated)
     */
    private function check_keyword_position($keyword, $url) {
        // In a real implementation, this would query search engines
        // For demo purposes, we'll simulate realistic ranking changes
        
        // Get previous position if exists
        global $wpdb;
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'keyword_rankings';
        $previous_data = $wpdb->get_row($wpdb->prepare(
            "SELECT position FROM $table_name 
             WHERE keyword = %s AND url = %s 
             ORDER BY tracked_date DESC LIMIT 1",
            $keyword, $url
        ));
        
        if ($previous_data) {
            // Simulate small ranking changes
            $previous_position = $previous_data->position;
            $change = rand(-5, 5);
            $new_position = max(1, min(100, $previous_position + $change));
        } else {
            // New keyword, assign random position
            $new_position = rand(10, 50);
        }
        
        return $new_position;
    }
}

