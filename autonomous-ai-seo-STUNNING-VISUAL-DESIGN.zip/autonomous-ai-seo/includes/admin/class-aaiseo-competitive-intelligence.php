<?php
/**
 * Competitive Intelligence for Autonomous AI SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Competitive_Intelligence {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize competitive intelligence
     */
    public function init() {
        // Schedule competitive analysis
        add_action('aaiseo_competitive_check', array($this, 'run_competitive_analysis'));
    }
    
    /**
     * Get competitor analysis
     */
    public function getCompetitorAnalysis() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_competitive';
        
        $competitors = $wpdb->get_results("
            SELECT competitor_url, 
                   COUNT(*) as tracked_keywords,
                   AVG(ranking_position) as avg_position,
                   MAX(last_checked) as last_updated
            FROM $table 
            GROUP BY competitor_url 
            ORDER BY avg_position ASC
        ");
        
        $analysis = array(
            'competitors' => array(),
            'keyword_gaps' => $this->identify_keyword_gaps(),
            'content_opportunities' => $this->identify_content_opportunities(),
            'market_position' => $this->calculate_market_position(),
            'trending_keywords' => $this->get_trending_keywords()
        );
        
        foreach ($competitors as $competitor) {
            $analysis['competitors'][] = array(
                'url' => $competitor->competitor_url,
                'domain' => parse_url($competitor->competitor_url, PHP_URL_HOST),
                'tracked_keywords' => intval($competitor->tracked_keywords),
                'avg_position' => round($competitor->avg_position, 1),
                'last_updated' => $competitor->last_updated,
                'strength_score' => $this->calculate_competitor_strength($competitor->competitor_url),
                'top_keywords' => $this->get_competitor_top_keywords($competitor->competitor_url)
            );
        }
        
        return $analysis;
    }
    
    /**
     * Add competitor for monitoring
     */
    public function add_competitor($competitor_url, $keywords = array()) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_competitive';
        
        // Validate URL
        if (!filter_var($competitor_url, FILTER_VALIDATE_URL)) {
            return new WP_Error('invalid_url', __('Invalid competitor URL', 'autonomous-ai-seo'));
        }
        
        // Add default keywords if none provided
        if (empty($keywords)) {
            $keywords = $this->get_default_keywords();
        }
        
        $success_count = 0;
        foreach ($keywords as $keyword) {
            $result = $wpdb->insert(
                $table,
                array(
                    'competitor_url' => $competitor_url,
                    'keyword' => $keyword,
                    'ranking_position' => null,
                    'content_analysis' => '',
                    'last_checked' => current_time('mysql')
                ),
                array('%s', '%s', '%d', '%s', '%s')
            );
            
            if ($result) {
                $success_count++;
            }
        }
        
        return array(
            'success' => true,
            'message' => sprintf(
                __('Added %d keywords for competitor monitoring', 'autonomous-ai-seo'),
                $success_count
            ),
            'keywords_added' => $success_count
        );
    }
    
    /**
     * Remove competitor
     */
    public function remove_competitor($competitor_url) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_competitive';
        
        $deleted = $wpdb->delete(
            $table,
            array('competitor_url' => $competitor_url),
            array('%s')
        );
        
        return array(
            'success' => $deleted !== false,
            'message' => $deleted ? 
                __('Competitor removed successfully', 'autonomous-ai-seo') : 
                __('Failed to remove competitor', 'autonomous-ai-seo'),
            'records_deleted' => $deleted
        );
    }
    
    /**
     * Run competitive analysis
     */
    public function run_competitive_analysis() {
        if (!get_option('aaiseo_competitive_monitoring')) {
            return;
        }
        
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_competitive';
        
        // Get competitors that need checking (older than 24 hours)
        $competitors = $wpdb->get_results("
            SELECT DISTINCT competitor_url 
            FROM $table 
            WHERE last_checked < DATE_SUB(NOW(), INTERVAL 24 HOUR)
            LIMIT 5
        ");
        
        foreach ($competitors as $competitor) {
            $this->analyze_competitor($competitor->competitor_url);
        }
    }
    
    /**
     * Check keyword ranking (mock implementation)
     */
    private function check_keyword_ranking($url, $keyword) {
        // In a real implementation, this would use APIs like SEMrush, Ahrefs, or Google Search Console
        // For now, return mock data
        
        return array(
            'position' => rand(1, 50),
            'analysis' => array(
                'title_optimization' => rand(60, 95),
                'content_relevance' => rand(70, 90),
                'backlink_strength' => rand(50, 85),
                'page_speed' => rand(65, 95),
                'mobile_friendly' => rand(80, 100)
            )
        );
    }
    
    /**
     * Identify keyword gaps
     */
    private function identify_keyword_gaps() {
        // Mock keyword gap analysis
        return array(
            array(
                'keyword' => 'AI SEO tools',
                'competitor_position' => 3,
                'our_position' => 15,
                'opportunity_score' => 85,
                'search_volume' => 2400,
                'difficulty' => 'medium'
            ),
            array(
                'keyword' => 'automated SEO optimization',
                'competitor_position' => 7,
                'our_position' => null,
                'opportunity_score' => 92,
                'search_volume' => 1800,
                'difficulty' => 'low'
            ),
            array(
                'keyword' => 'technical SEO audit',
                'competitor_position' => 5,
                'our_position' => 12,
                'opportunity_score' => 78,
                'search_volume' => 3200,
                'difficulty' => 'high'
            )
        );
    }
    
    /**
     * Identify content opportunities
     */
    private function identify_content_opportunities() {
        return array(
            array(
                'topic' => 'Voice Search Optimization Guide',
                'competitor_coverage' => 3,
                'content_gap_score' => 88,
                'estimated_traffic' => 1500,
                'content_type' => 'comprehensive_guide'
            ),
            array(
                'topic' => 'Core Web Vitals Optimization',
                'competitor_coverage' => 5,
                'content_gap_score' => 75,
                'estimated_traffic' => 2200,
                'content_type' => 'tutorial'
            ),
            array(
                'topic' => 'Local SEO Checklist',
                'competitor_coverage' => 2,
                'content_gap_score' => 95,
                'estimated_traffic' => 1800,
                'content_type' => 'checklist'
            )
        );
    }
    
    /**
     * Calculate market position
     */
    private function calculate_market_position() {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_competitive';
        
        // Get average positions
        $our_avg = $this->get_our_average_position();
        $competitor_avg = $wpdb->get_var("
            SELECT AVG(ranking_position) 
            FROM $table 
            WHERE ranking_position IS NOT NULL
        ");
        
        $market_share = $this->calculate_market_share();
        
        return array(
            'our_average_position' => round($our_avg, 1),
            'competitor_average_position' => round($competitor_avg, 1),
            'market_share_percentage' => $market_share,
            'position_trend' => $this->get_position_trend(),
            'competitive_strength' => $this->calculate_competitive_strength(),
            'opportunities' => $this->get_position_opportunities()
        );
    }
    
    /**
     * Get trending keywords
     */
    private function get_trending_keywords() {
        return array(
            array(
                'keyword' => 'AI content optimization',
                'trend' => 'rising',
                'growth_rate' => 45,
                'search_volume' => 1200,
                'competition_level' => 'medium'
            ),
            array(
                'keyword' => 'voice search SEO',
                'trend' => 'rising',
                'growth_rate' => 32,
                'search_volume' => 890,
                'competition_level' => 'low'
            ),
            array(
                'keyword' => 'mobile-first indexing',
                'trend' => 'stable',
                'growth_rate' => 8,
                'search_volume' => 2100,
                'competition_level' => 'high'
            )
        );
    }
    
    /**
     * Calculate competitor strength
     */
    private function calculate_competitor_strength($competitor_url) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_competitive';
        
        $stats = $wpdb->get_row($wpdb->prepare("
            SELECT 
                AVG(ranking_position) as avg_position,
                COUNT(*) as total_keywords,
                SUM(CASE WHEN ranking_position <= 10 THEN 1 ELSE 0 END) as top_10_keywords
            FROM $table 
            WHERE competitor_url = %s 
            AND ranking_position IS NOT NULL
        ", $competitor_url));
        
        if (!$stats || $stats->total_keywords == 0) {
            return 50;
        }
        
        $position_score = max(0, 100 - ($stats->avg_position * 2));
        $coverage_score = min(100, ($stats->total_keywords / 50) * 100);
        $top_10_ratio = ($stats->top_10_keywords / $stats->total_keywords) * 100;
        
        return round(($position_score + $coverage_score + $top_10_ratio) / 3, 1);
    }
    
    /**
     * Get competitor top keywords
     */
    private function get_competitor_top_keywords($competitor_url, $limit = 5) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_competitive';
        
        $keywords = $wpdb->get_results($wpdb->prepare("
            SELECT keyword, ranking_position 
            FROM $table 
            WHERE competitor_url = %s 
            AND ranking_position IS NOT NULL
            ORDER BY ranking_position ASC 
            LIMIT %d
        ", $competitor_url, $limit));
        
        $result = array();
        foreach ($keywords as $keyword) {
            $result[] = array(
                'keyword' => $keyword->keyword,
                'position' => intval($keyword->ranking_position)
            );
        }
        
        return $result;
    }
    
    /**
     * Get default keywords for monitoring
     */
    private function get_default_keywords() {
        return array(
            'SEO optimization',
            'WordPress SEO',
            'technical SEO',
            'content optimization',
            'keyword research',
            'link building',
            'local SEO',
            'mobile SEO',
            'page speed optimization',
            'schema markup'
        );
    }
    
    /**
     * Get our average position (mock)
     */
    private function get_our_average_position() {
        // In real implementation, this would come from Google Search Console API
        return 12.5;
    }
    
    /**
     * Calculate market share (mock)
     */
    private function calculate_market_share() {
        // Mock calculation based on visibility and traffic
        return 8.5;
    }
    
    /**
     * Get position trend (mock)
     */
    private function get_position_trend() {
        return array(
            'direction' => 'improving',
            'change' => '+2.3',
            'period' => '30 days'
        );
    }
    
    /**
     * Calculate competitive strength (mock)
     */
    private function calculate_competitive_strength() {
        return array(
            'content_quality' => 78,
            'technical_seo' => 85,
            'backlink_profile' => 72,
            'user_experience' => 88,
            'overall_score' => 81
        );
    }
    
    /**
     * Get position opportunities
     */
    private function get_position_opportunities() {
        return array(
            array(
                'type' => 'quick_win',
                'description' => 'Optimize meta descriptions for 15 pages',
                'potential_improvement' => '+3 positions',
                'effort' => 'low'
            ),
            array(
                'type' => 'content_gap',
                'description' => 'Create comprehensive guide on voice search',
                'potential_improvement' => '+8 positions',
                'effort' => 'medium'
            ),
            array(
                'type' => 'technical',
                'description' => 'Improve Core Web Vitals scores',
                'potential_improvement' => '+5 positions',
                'effort' => 'high'
            )
        );
    }
    
    /**
     * Update competitor data (called by cron)
     */
    public function update_competitor_data() {
        global $wpdb;
        
        // Get list of competitors to monitor
        $competitors = get_option('aaiseo_competitors', array());
        
        if (empty($competitors)) {
            return 0;
        }
        
        $updated_count = 0;
        
        foreach ($competitors as $competitor) {
            $competitor_data = $this->analyze_competitor($competitor['domain']);
            
            if ($competitor_data) {
                // Store competitor data
                $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'competitor_data';
                $wpdb->insert(
                    $table_name,
                    array(
                        'competitor_domain' => $competitor['domain'],
                        'analysis_data' => wp_json_encode($competitor_data),
                        'analyzed_at' => current_time('mysql')
                    ),
                    array('%s', '%s', '%s')
                );
                
                $updated_count++;
            }
            
            // Add delay to avoid overwhelming servers
            sleep(2);
        }
        
        // Update last check time
        update_option('aaiseo_last_competitor_update', current_time('mysql'));
        
        return $updated_count;
    }
    
    /**
     * Analyze a single competitor
     */
    private function analyze_competitor($domain) {
        // In a real implementation, this would scrape competitor data
        // For demo purposes, we'll simulate competitor analysis
        
        return array(
            'domain' => $domain,
            'estimated_traffic' => rand(10000, 100000),
            'top_keywords' => $this->simulate_competitor_keywords($domain),
            'content_gaps' => $this->simulate_content_gaps($domain),
            'backlink_profile' => array(
                'total_backlinks' => rand(1000, 50000),
                'referring_domains' => rand(100, 5000),
                'domain_authority' => rand(30, 90)
            ),
            'technical_score' => rand(70, 95),
            'content_freshness' => rand(60, 90),
            'social_signals' => rand(100, 10000)
        );
    }
    
    /**
     * Simulate competitor keywords
     */
    private function simulate_competitor_keywords($domain) {
        $sample_keywords = array(
            'seo optimization', 'content marketing', 'digital marketing',
            'search engine optimization', 'keyword research', 'link building',
            'technical seo', 'local seo', 'mobile optimization'
        );
        
        $keywords = array();
        $selected = array_rand($sample_keywords, min(5, count($sample_keywords)));
        
        foreach ((array)$selected as $index) {
            $keywords[] = array(
                'keyword' => $sample_keywords[$index],
                'position' => rand(1, 20),
                'search_volume' => rand(1000, 50000),
                'difficulty' => rand(30, 80)
            );
        }
        
        return $keywords;
    }
    
    /**
     * Simulate content gaps
     */
    private function simulate_content_gaps($domain) {
        return array(
            array(
                'topic' => 'Voice Search Optimization',
                'opportunity_score' => rand(70, 95),
                'competition_level' => 'medium'
            ),
            array(
                'topic' => 'Core Web Vitals Guide',
                'opportunity_score' => rand(60, 85),
                'competition_level' => 'high'
            ),
            array(
                'topic' => 'Local SEO Strategies',
                'opportunity_score' => rand(75, 90),
                'competition_level' => 'low'
            )
        );
    }
}

