<?php
/**
 * Advanced AI-Powered Keyword Research for Autonomous AI SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Keyword_Research {
    
    /**
     * Keyword data sources
     */
    private $data_sources = array();
    
    /**
     * AI models for keyword analysis
     */
    private $ai_models = array();
    
    /**
     * Keyword difficulty factors
     */
    private $difficulty_factors = array();
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize keyword research
     */
    public function init() {
        // Initialize data sources
        $this->init_data_sources();
        
        // Initialize AI models
        $this->init_ai_models();
        
        // Initialize difficulty factors
        $this->init_difficulty_factors();
        
        // Admin hooks
        add_action('wp_ajax_aaiseo_keyword_research', array($this, 'ajax_keyword_research'));
        add_action('wp_ajax_aaiseo_keyword_suggestions', array($this, 'ajax_keyword_suggestions'));
        add_action('wp_ajax_aaiseo_keyword_analysis', array($this, 'ajax_keyword_analysis'));
        add_action('wp_ajax_aaiseo_competitor_keywords', array($this, 'ajax_competitor_keywords'));
        add_action('wp_ajax_aaiseo_keyword_clustering', array($this, 'ajax_keyword_clustering'));
        add_action('wp_ajax_aaiseo_content_gap_analysis', array($this, 'ajax_content_gap_analysis'));
        
        // Cron hooks
        add_action('aaiseo_daily_keyword_update', array($this, 'update_keyword_data'));
        add_action('aaiseo_weekly_keyword_trends', array($this, 'analyze_keyword_trends'));
    }
    
    /**
     * Initialize data sources
     */
    private function init_data_sources() {
        $this->data_sources = array(
            'google_keyword_planner' => array(
                'name' => 'Google Keyword Planner',
                'enabled' => false,
                'api_key_required' => true,
                'rate_limit' => 1000,
                'accuracy' => 95
            ),
            'google_autocomplete' => array(
                'name' => 'Google Autocomplete',
                'enabled' => true,
                'api_key_required' => false,
                'rate_limit' => 100,
                'accuracy' => 80
            ),
            'google_related_searches' => array(
                'name' => 'Google Related Searches',
                'enabled' => true,
                'api_key_required' => false,
                'rate_limit' => 50,
                'accuracy' => 75
            ),
            'youtube_suggest' => array(
                'name' => 'YouTube Suggest',
                'enabled' => true,
                'api_key_required' => false,
                'rate_limit' => 100,
                'accuracy' => 70
            ),
            'amazon_suggest' => array(
                'name' => 'Amazon Suggest',
                'enabled' => true,
                'api_key_required' => false,
                'rate_limit' => 100,
                'accuracy' => 65
            ),
            'bing_suggest' => array(
                'name' => 'Bing Suggest',
                'enabled' => true,
                'api_key_required' => false,
                'rate_limit' => 100,
                'accuracy' => 70
            ),
            'semrush_api' => array(
                'name' => 'SEMrush API',
                'enabled' => false,
                'api_key_required' => true,
                'rate_limit' => 10000,
                'accuracy' => 90
            ),
            'ahrefs_api' => array(
                'name' => 'Ahrefs API',
                'enabled' => false,
                'api_key_required' => true,
                'rate_limit' => 1000,
                'accuracy' => 92
            )
        );
    }
    
    /**
     * Initialize AI models
     */
    private function init_ai_models() {
        $this->ai_models = array(
            'semantic_similarity' => array(
                'name' => 'Semantic Similarity Model',
                'description' => 'Finds semantically related keywords using AI',
                'enabled' => true
            ),
            'intent_classification' => array(
                'name' => 'Search Intent Classification',
                'description' => 'Classifies keywords by search intent',
                'enabled' => true
            ),
            'trend_prediction' => array(
                'name' => 'Trend Prediction Model',
                'description' => 'Predicts keyword trend changes',
                'enabled' => true
            ),
            'difficulty_prediction' => array(
                'name' => 'Difficulty Prediction Model',
                'description' => 'Predicts keyword ranking difficulty',
                'enabled' => true
            ),
            'content_optimization' => array(
                'name' => 'Content Optimization Model',
                'description' => 'Suggests content optimizations for keywords',
                'enabled' => true
            )
        );
    }
    
    /**
     * Initialize difficulty factors
     */
    private function init_difficulty_factors() {
        $this->difficulty_factors = array(
            'search_volume' => 0.25,
            'competition_level' => 0.30,
            'domain_authority' => 0.20,
            'content_quality' => 0.15,
            'backlink_profile' => 0.10
        );
    }
    
    /**
     * Perform comprehensive keyword research
     */
    public function research_keywords($seed_keyword, $options = array()) {
        $defaults = array(
            'max_keywords' => 500,
            'include_long_tail' => true,
            'include_questions' => true,
            'include_local' => false,
            'language' => 'en',
            'country' => 'US',
            'data_sources' => array('google_autocomplete', 'google_related_searches'),
            'ai_enhancement' => true
        );
        
        $options = wp_parse_args($options, $defaults);
        
        $keywords = array();
        
        // Gather keywords from multiple sources
        foreach ($options['data_sources'] as $source) {
            if (isset($this->data_sources[$source]) && $this->data_sources[$source]['enabled']) {
                $source_keywords = $this->get_keywords_from_source($seed_keyword, $source, $options);
                $keywords = array_merge($keywords, $source_keywords);
            }
        }
        
        // Remove duplicates
        $keywords = $this->deduplicate_keywords($keywords);
        
        // AI enhancement
        if ($options['ai_enhancement']) {
            $keywords = $this->enhance_keywords_with_ai($keywords, $seed_keyword, $options);
        }
        
        // Analyze and score keywords
        $analyzed_keywords = $this->analyze_keywords($keywords, $options);
        
        // Sort by opportunity score
        usort($analyzed_keywords, function($a, $b) {
            return $b['opportunity_score'] <=> $a['opportunity_score'];
        });
        
        // Limit results
        return array_slice($analyzed_keywords, 0, $options['max_keywords']);
    }
    
    /**
     * Get keywords from specific source
     */
    private function get_keywords_from_source($seed_keyword, $source, $options) {
        switch ($source) {
            case 'google_autocomplete':
                return $this->get_google_autocomplete_keywords($seed_keyword, $options);
            case 'google_related_searches':
                return $this->get_google_related_keywords($seed_keyword, $options);
            case 'youtube_suggest':
                return $this->get_youtube_suggest_keywords($seed_keyword, $options);
            case 'amazon_suggest':
                return $this->get_amazon_suggest_keywords($seed_keyword, $options);
            case 'bing_suggest':
                return $this->get_bing_suggest_keywords($seed_keyword, $options);
            case 'semrush_api':
                return $this->get_semrush_keywords($seed_keyword, $options);
            case 'ahrefs_api':
                return $this->get_ahrefs_keywords($seed_keyword, $options);
            default:
                return array();
        }
    }
    
    /**
     * Get Google Autocomplete keywords
     */
    private function get_google_autocomplete_keywords($seed_keyword, $options) {
        $keywords = array();
        $alphabet = range('a', 'z');
        $numbers = range('0', '9');
        $modifiers = array_merge($alphabet, $numbers, array('how', 'what', 'why', 'when', 'where', 'best', 'top'));
        
        foreach ($modifiers as $modifier) {
            $queries = array(
                $seed_keyword . ' ' . $modifier,
                $modifier . ' ' . $seed_keyword,
                $seed_keyword . ' ' . $modifier . ' *'
            );
            
            foreach ($queries as $query) {
                $suggestions = $this->fetch_google_suggestions($query, $options);
                $keywords = array_merge($keywords, $suggestions);
            }
            
            // Rate limiting
            usleep(100000); // 0.1 second delay
        }
        
        return array_unique($keywords);
    }
    
    /**
     * Fetch Google suggestions
     */
    private function fetch_google_suggestions($query, $options) {
        $url = 'http://suggestqueries.google.com/complete/search';
        $params = array(
            'client' => 'firefox',
            'q' => urlencode($query),
            'hl' => $options['language'],
            'gl' => $options['country']
        );
        
        $response = wp_remote_get($url . '?' . http_build_query($params), array(
            'timeout' => 10,
            'user-agent' => 'Mozilla/5.0 (compatible; AAISEO/2.0)'
        ));
        
        if (is_wp_error($response)) {
            return array();
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!isset($data[1]) || !is_array($data[1])) {
            return array();
        }
        
        return array_filter($data[1], function($suggestion) {
            return strlen($suggestion) > 3 && strlen($suggestion) < 100;
        });
    }
    
    /**
     * Get Google Related keywords
     */
    private function get_google_related_keywords($seed_keyword, $options) {
        // This would typically scrape Google's "People also search for" section
        // For now, return generated variations
        
        $variations = array();
        $modifiers = array(
            'best', 'top', 'how to', 'what is', 'guide', 'tips', 'review',
            'vs', 'comparison', 'alternative', 'free', 'online', 'near me'
        );
        
        foreach ($modifiers as $modifier) {
            $variations[] = $modifier . ' ' . $seed_keyword;
            $variations[] = $seed_keyword . ' ' . $modifier;
        }
        
        return $variations;
    }
    
    /**
     * Get YouTube Suggest keywords
     */
    private function get_youtube_suggest_keywords($seed_keyword, $options) {
        $url = 'http://suggestqueries.google.com/complete/search';
        $params = array(
            'client' => 'youtube',
            'ds' => 'yt',
            'q' => urlencode($seed_keyword),
            'hl' => $options['language']
        );
        
        $response = wp_remote_get($url . '?' . http_build_query($params), array(
            'timeout' => 10
        ));
        
        if (is_wp_error($response)) {
            return array();
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        if (!isset($data[1]) || !is_array($data[1])) {
            return array();
        }
        
        return array_map(function($item) {
            return $item[0];
        }, $data[1]);
    }
    
    /**
     * Enhance keywords with AI
     */
    private function enhance_keywords_with_ai($keywords, $seed_keyword, $options) {
        $enhanced_keywords = $keywords;
        
        // Semantic similarity expansion
        if ($this->ai_models['semantic_similarity']['enabled']) {
            $semantic_keywords = $this->find_semantic_keywords($seed_keyword, $keywords);
            $enhanced_keywords = array_merge($enhanced_keywords, $semantic_keywords);
        }
        
        // Intent-based keyword generation
        if ($this->ai_models['intent_classification']['enabled']) {
            $intent_keywords = $this->generate_intent_based_keywords($seed_keyword, $keywords);
            $enhanced_keywords = array_merge($enhanced_keywords, $intent_keywords);
        }
        
        // Long-tail keyword generation
        if ($options['include_long_tail']) {
            $long_tail_keywords = $this->generate_long_tail_keywords($seed_keyword, $keywords);
            $enhanced_keywords = array_merge($enhanced_keywords, $long_tail_keywords);
        }
        
        // Question-based keywords
        if ($options['include_questions']) {
            $question_keywords = $this->generate_question_keywords($seed_keyword, $keywords);
            $enhanced_keywords = array_merge($enhanced_keywords, $question_keywords);
        }
        
        return array_unique($enhanced_keywords);
    }
    
    /**
     * Find semantic keywords using AI
     */
    private function find_semantic_keywords($seed_keyword, $existing_keywords) {
        // This would use word embeddings or semantic similarity models
        // For now, return conceptually related terms
        
        $semantic_map = array(
            'seo' => array('search engine optimization', 'organic traffic', 'serp ranking', 'keyword optimization'),
            'marketing' => array('advertising', 'promotion', 'branding', 'lead generation'),
            'content' => array('blog posts', 'articles', 'copywriting', 'content strategy'),
            'website' => array('web design', 'user experience', 'conversion rate', 'landing page')
        );
        
        $semantic_keywords = array();
        $seed_lower = strtolower($seed_keyword);
        
        foreach ($semantic_map as $concept => $related_terms) {
            if (strpos($seed_lower, $concept) !== false) {
                $semantic_keywords = array_merge($semantic_keywords, $related_terms);
            }
        }
        
        return $semantic_keywords;
    }
    
    /**
     * Generate intent-based keywords
     */
    private function generate_intent_based_keywords($seed_keyword, $existing_keywords) {
        $intent_modifiers = array(
            'informational' => array('what is', 'how to', 'guide to', 'learn about', 'understand'),
            'commercial' => array('best', 'top', 'review', 'comparison', 'vs'),
            'transactional' => array('buy', 'purchase', 'order', 'get', 'download'),
            'navigational' => array('login', 'sign up', 'contact', 'support', 'official')
        );
        
        $intent_keywords = array();
        
        foreach ($intent_modifiers as $intent => $modifiers) {
            foreach ($modifiers as $modifier) {
                $intent_keywords[] = $modifier . ' ' . $seed_keyword;
                $intent_keywords[] = $seed_keyword . ' ' . $modifier;
            }
        }
        
        return $intent_keywords;
    }
    
    /**
     * Generate long-tail keywords
     */
    private function generate_long_tail_keywords($seed_keyword, $existing_keywords) {
        $long_tail_patterns = array(
            'how to {keyword} for beginners',
            'best {keyword} tools',
            '{keyword} tips and tricks',
            'complete guide to {keyword}',
            '{keyword} step by step',
            'free {keyword} resources',
            '{keyword} mistakes to avoid',
            'advanced {keyword} techniques'
        );
        
        $long_tail_keywords = array();
        
        foreach ($long_tail_patterns as $pattern) {
            $long_tail_keywords[] = str_replace('{keyword}', $seed_keyword, $pattern);
        }
        
        return $long_tail_keywords;
    }
    
    /**
     * Generate question keywords
     */
    private function generate_question_keywords($seed_keyword, $existing_keywords) {
        $question_patterns = array(
            'what is {keyword}',
            'how does {keyword} work',
            'why is {keyword} important',
            'when to use {keyword}',
            'where to find {keyword}',
            'who needs {keyword}',
            'which {keyword} is best',
            'how much does {keyword} cost'
        );
        
        $question_keywords = array();
        
        foreach ($question_patterns as $pattern) {
            $question_keywords[] = str_replace('{keyword}', $seed_keyword, $pattern);
        }
        
        return $question_keywords;
    }
    
    /**
     * Analyze keywords
     */
    private function analyze_keywords($keywords, $options) {
        $analyzed_keywords = array();
        
        foreach ($keywords as $keyword) {
            $analysis = array(
                'keyword' => $keyword,
                'search_volume' => $this->estimate_search_volume($keyword),
                'competition' => $this->calculate_competition($keyword),
                'difficulty' => $this->calculate_difficulty($keyword),
                'cpc' => $this->estimate_cpc($keyword),
                'trend' => $this->analyze_trend($keyword),
                'intent' => $this->classify_intent($keyword),
                'opportunity_score' => 0
            );
            
            // Calculate opportunity score
            $analysis['opportunity_score'] = $this->calculate_opportunity_score($analysis);
            
            $analyzed_keywords[] = $analysis;
        }
        
        return $analyzed_keywords;
    }
    
    /**
     * Calculate competition
     */
    private function calculate_competition($keyword) {
        // Estimate competition based on keyword characteristics
        $word_count = str_word_count($keyword);
        $has_commercial_intent = $this->has_commercial_intent($keyword);
        
        $competition = 0.5; // Base competition
        
        // Shorter keywords are more competitive
        if ($word_count <= 2) {
            $competition += 0.3;
        } elseif ($word_count >= 4) {
            $competition -= 0.2;
        }
        
        // Commercial keywords are more competitive
        if ($has_commercial_intent) {
            $competition += 0.2;
        }
        
        return max(0.1, min(1.0, $competition));
    }
    
    /**
     * Calculate keyword difficulty
     */
    private function calculate_difficulty($keyword) {
        $search_volume = $this->estimate_search_volume($keyword);
        $competition = $this->calculate_competition($keyword);
        
        // Normalize search volume (0-1 scale)
        $volume_score = min(1.0, $search_volume / 10000);
        
        // Calculate weighted difficulty
        $difficulty = ($volume_score * $this->difficulty_factors['search_volume']) +
                     ($competition * $this->difficulty_factors['competition_level']) +
                     (0.6 * $this->difficulty_factors['domain_authority']) + // Assume medium DA
                     (0.7 * $this->difficulty_factors['content_quality']) +   // Assume good content
                     (0.5 * $this->difficulty_factors['backlink_profile']);  // Assume medium backlinks
        
        return round($difficulty * 100);
    }
    
    /**
     * Estimate CPC
     */
    private function estimate_cpc($keyword) {
        $has_commercial_intent = $this->has_commercial_intent($keyword);
        $competition = $this->calculate_competition($keyword);
        
        $base_cpc = $has_commercial_intent ? 2.50 : 0.75;
        $cpc_modifier = 1 + ($competition * 2);
        
        return round($base_cpc * $cpc_modifier, 2);
    }
    
    /**
     * Analyze keyword trend
     */
    private function analyze_trend($keyword) {
        // This would use Google Trends API in production
        // For now, return mock trend data
        
        $trends = array('rising', 'stable', 'declining');
        $trend = $trends[array_rand($trends)];
        
        $trend_data = array(
            'direction' => $trend,
            'change_percentage' => rand(-30, 50),
            'seasonality' => $this->detect_seasonality($keyword),
            'forecast' => $this->forecast_trend($keyword)
        );
        
        return $trend_data;
    }
    
    /**
     * Classify search intent
     */
    private function classify_intent($keyword) {
        $keyword_lower = strtolower($keyword);
        
        // Transactional intent
        $transactional_words = array('buy', 'purchase', 'order', 'shop', 'price', 'cost', 'cheap', 'discount');
        foreach ($transactional_words as $word) {
            if (strpos($keyword_lower, $word) !== false) {
                return 'transactional';
            }
        }
        
        // Commercial intent
        $commercial_words = array('best', 'top', 'review', 'comparison', 'vs', 'alternative');
        foreach ($commercial_words as $word) {
            if (strpos($keyword_lower, $word) !== false) {
                return 'commercial';
            }
        }
        
        // Informational intent
        $informational_words = array('how', 'what', 'why', 'when', 'where', 'guide', 'tutorial', 'learn');
        foreach ($informational_words as $word) {
            if (strpos($keyword_lower, $word) !== false) {
                return 'informational';
            }
        }
        
        // Navigational intent
        $navigational_words = array('login', 'sign up', 'contact', 'support', 'official', 'website');
        foreach ($navigational_words as $word) {
            if (strpos($keyword_lower, $word) !== false) {
                return 'navigational';
            }
        }
        
        return 'informational'; // Default
    }
    
    /**
     * Calculate opportunity score
     */
    private function calculate_opportunity_score($analysis) {
        $volume_score = min(100, $analysis['search_volume'] / 100);
        $competition_score = (1 - $analysis['competition']) * 100;
        $difficulty_score = (100 - $analysis['difficulty']);
        $trend_score = $this->get_trend_score($analysis['trend']);
        
        $opportunity_score = ($volume_score * 0.3) +
                           ($competition_score * 0.25) +
                           ($difficulty_score * 0.25) +
                           ($trend_score * 0.2);
        
        return round($opportunity_score, 1);
    }
    
    /**
     * Get trend score
     */
    private function get_trend_score($trend_data) {
        switch ($trend_data['direction']) {
            case 'rising':
                return 80 + min(20, $trend_data['change_percentage']);
            case 'stable':
                return 60;
            case 'declining':
                return max(20, 60 + $trend_data['change_percentage']);
            default:
                return 50;
        }
    }
    
    /**
     * Check if keyword has commercial intent
     */
    private function has_commercial_intent($keyword) {
        $commercial_indicators = array(
            'buy', 'purchase', 'order', 'shop', 'price', 'cost', 'cheap',
            'discount', 'deal', 'sale', 'best', 'top', 'review', 'comparison'
        );
        
        $keyword_lower = strtolower($keyword);
        
        foreach ($commercial_indicators as $indicator) {
            if (strpos($keyword_lower, $indicator) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Detect seasonality
     */
    private function detect_seasonality($keyword) {
        $seasonal_keywords = array(
            'christmas' => 'winter',
            'halloween' => 'fall',
            'summer' => 'summer',
            'winter' => 'winter',
            'spring' => 'spring',
            'fall' => 'fall',
            'holiday' => 'winter',
            'vacation' => 'summer'
        );
        
        $keyword_lower = strtolower($keyword);
        
        foreach ($seasonal_keywords as $seasonal_term => $season) {
            if (strpos($keyword_lower, $seasonal_term) !== false) {
                return $season;
            }
        }
        
        return 'none';
    }
    
    /**
     * Forecast trend
     */
    private function forecast_trend($keyword) {
        // Simple trend forecasting based on keyword characteristics
        $has_tech_terms = preg_match('/\b(ai|machine learning|blockchain|iot|5g)\b/i', $keyword);
        $has_traditional_terms = preg_match('/\b(newspaper|fax|cd|dvd)\b/i', $keyword);
        
        if ($has_tech_terms) {
            return 'growing';
        } elseif ($has_traditional_terms) {
            return 'declining';
        } else {
            return 'stable';
        }
    }
    
    /**
     * Deduplicate keywords
     */
    private function deduplicate_keywords($keywords) {
        // Remove exact duplicates
        $unique_keywords = array_unique($keywords);
        
        // Remove similar keywords (basic similarity check)
        $filtered_keywords = array();
        
        foreach ($unique_keywords as $keyword) {
            $is_similar = false;
            
            foreach ($filtered_keywords as $existing_keyword) {
                if ($this->calculate_similarity($keyword, $existing_keyword) > 0.8) {
                    $is_similar = true;
                    break;
                }
            }
            
            if (!$is_similar) {
                $filtered_keywords[] = $keyword;
            }
        }
        
        return $filtered_keywords;
    }
    
    /**
     * Calculate similarity between keywords
     */
    private function calculate_similarity($keyword1, $keyword2) {
        $keyword1 = strtolower(trim($keyword1));
        $keyword2 = strtolower(trim($keyword2));
        
        if ($keyword1 === $keyword2) {
            return 1.0;
        }
        
        // Use Levenshtein distance for basic similarity
        $max_length = max(strlen($keyword1), strlen($keyword2));
        $distance = levenshtein($keyword1, $keyword2);
        
        return 1 - ($distance / $max_length);
    }
    
    /**
     * AJAX: Keyword research
     */
    public function ajax_keyword_research() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        $seed_keyword = sanitize_text_field($_POST['seed_keyword']);
        $options = isset($_POST['options']) ? $_POST['options'] : array();
        
        if (empty($seed_keyword)) {
            wp_send_json_error('Seed keyword is required');
        }
        
        $keywords = $this->research_keywords($seed_keyword, $options);
        
        wp_send_json_success(array(
            'keywords' => $keywords,
            'total_found' => count($keywords),
            'seed_keyword' => $seed_keyword
        ));
    }
    
    /**
     * AJAX: Keyword suggestions
     */
    public function ajax_keyword_suggestions() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        $content = sanitize_textarea_field($_POST['content']);
        $suggestions = $this->suggest_keywords_from_content($content);
        
        wp_send_json_success($suggestions);
    }
    
    /**
     * Suggest keywords from content
     */
    private function suggest_keywords_from_content($content) {
        // Extract potential keywords from content
        $text = wp_strip_all_tags($content);
        $words = str_word_count($text, 1);
        
        // Get word frequency
        $word_freq = array_count_values(array_map('strtolower', $words));
        arsort($word_freq);
        
        // Filter and score potential keywords
        $suggestions = array();
        foreach ($word_freq as $word => $freq) {
            if (strlen($word) > 3 && $freq > 1) {
                $suggestions[] = array(
                    'keyword' => $word,
                    'frequency' => $freq,
                    'relevance_score' => $this->calculate_content_relevance($word, $text)
                );
            }
        }
        
        // Sort by relevance
        usort($suggestions, function($a, $b) {
            return $b['relevance_score'] <=> $a['relevance_score'];
        });
        
        return array_slice($suggestions, 0, 20);
    }
    
    /**
     * Calculate content relevance
     */
    private function calculate_content_relevance($keyword, $content) {
        $content_lower = strtolower($content);
        $keyword_lower = strtolower($keyword);
        
        // Count occurrences
        $occurrences = substr_count($content_lower, $keyword_lower);
        
        // Calculate position score (keywords at beginning are more relevant)
        $first_position = strpos($content_lower, $keyword_lower);
        $position_score = $first_position ? (1 - ($first_position / strlen($content))) : 0;
        
        // Calculate density score
        $word_count = str_word_count($content);
        $density_score = ($occurrences / $word_count) * 100;
        
        return ($occurrences * 0.4) + ($position_score * 0.3) + ($density_score * 0.3);
    }
    
    /**
     * Get keyword suggestions
     */
    public function get_keyword_suggestions($seed_keyword, $options = array()) {
        $defaults = array(
            'content' => '',
            'post_id' => 0,
            'limit' => 20,
            'include_search_volume' => true,
            'include_difficulty' => true
        );
        
        $options = wp_parse_args($options, $defaults);
        
        $suggestions = array();
        
        // Get suggestions from different sources
        $suggestions = array_merge($suggestions, $this->get_google_suggestions($seed_keyword));
        $suggestions = array_merge($suggestions, $this->get_related_terms($seed_keyword));
        $suggestions = array_merge($suggestions, $this->get_semantic_keywords($seed_keyword));
        
        // Add search volume and difficulty if requested
        if ($options['include_search_volume'] || $options['include_difficulty']) {
            $suggestions = $this->enrich_keyword_data($suggestions, $options);
        }
        
        // Score and sort suggestions
        foreach ($suggestions as &$suggestion) {
            $suggestion['relevance_score'] = $this->calculate_keyword_relevance($suggestion['keyword'], $seed_keyword, $options['content']);
        }
        
        usort($suggestions, function($a, $b) {
            return $b['relevance_score'] <=> $a['relevance_score'];
        });
        
        return array_slice($suggestions, 0, $options['limit']);
    }
    
    /**
     * Get related keywords
     */
    public function get_related_keywords($seed_keyword, $limit = 15) {
        $related_keywords = array();
        
        // Get synonyms and related terms
        $synonyms = $this->get_synonyms($seed_keyword);
        $related_terms = $this->get_semantic_keywords($seed_keyword);
        $variations = $this->get_keyword_variations($seed_keyword);
        
        // Combine all related keywords
        $all_related = array_merge($synonyms, $related_terms, $variations);
        
        // Remove duplicates and score
        $unique_keywords = array();
        foreach ($all_related as $keyword) {
            $keyword_lower = strtolower($keyword['keyword']);
            if (!isset($unique_keywords[$keyword_lower])) {
                $unique_keywords[$keyword_lower] = $keyword;
            }
        }
        
        // Sort by relevance
        $related_keywords = array_values($unique_keywords);
        usort($related_keywords, function($a, $b) {
            return ($b['relevance_score'] ?? 0) <=> ($a['relevance_score'] ?? 0);
        });
        
        return array_slice($related_keywords, 0, $limit);
    }
    
    /**
     * Get long-tail keywords
     */
    public function get_long_tail_keywords($seed_keyword, $limit = 10) {
        $long_tail_keywords = array();
        
        // Generate question-based long-tail keywords
        $question_words = array('what', 'how', 'why', 'when', 'where', 'who', 'which');
        foreach ($question_words as $question) {
            $long_tail_keywords[] = array(
                'keyword' => $question . ' is ' . $seed_keyword,
                'type' => 'question',
                'search_volume' => $this->estimate_search_volume($question . ' is ' . $seed_keyword),
                'difficulty' => $this->estimate_difficulty($question . ' is ' . $seed_keyword),
                'relevance_score' => 0.8
            );
            
            $long_tail_keywords[] = array(
                'keyword' => $question . ' to ' . $seed_keyword,
                'type' => 'question',
                'search_volume' => $this->estimate_search_volume($question . ' to ' . $seed_keyword),
                'difficulty' => $this->estimate_difficulty($question . ' to ' . $seed_keyword),
                'relevance_score' => 0.7
            );
        }
        
        // Generate modifier-based long-tail keywords
        $modifiers = array('best', 'top', 'cheap', 'free', 'online', 'guide', 'tips', 'review', 'comparison');
        foreach ($modifiers as $modifier) {
            $long_tail_keywords[] = array(
                'keyword' => $modifier . ' ' . $seed_keyword,
                'type' => 'modifier',
                'search_volume' => $this->estimate_search_volume($modifier . ' ' . $seed_keyword),
                'difficulty' => $this->estimate_difficulty($modifier . ' ' . $seed_keyword),
                'relevance_score' => 0.6
            );
            
            $long_tail_keywords[] = array(
                'keyword' => $seed_keyword . ' ' . $modifier,
                'type' => 'modifier',
                'search_volume' => $this->estimate_search_volume($seed_keyword . ' ' . $modifier),
                'difficulty' => $this->estimate_difficulty($seed_keyword . ' ' . $modifier),
                'relevance_score' => 0.5
            );
        }
        
        // Generate location-based long-tail keywords
        $locations = array('near me', 'online', 'local', 'in [city]', 'for [location]');
        foreach ($locations as $location) {
            $long_tail_keywords[] = array(
                'keyword' => $seed_keyword . ' ' . $location,
                'type' => 'location',
                'search_volume' => $this->estimate_search_volume($seed_keyword . ' ' . $location),
                'difficulty' => $this->estimate_difficulty($seed_keyword . ' ' . $location),
                'relevance_score' => 0.4
            );
        }
        
        // Sort by relevance and search volume
        usort($long_tail_keywords, function($a, $b) {
            $score_a = ($a['relevance_score'] * 0.6) + (($a['search_volume'] / 1000) * 0.4);
            $score_b = ($b['relevance_score'] * 0.6) + (($b['search_volume'] / 1000) * 0.4);
            return $score_b <=> $score_a;
        });
        
        return array_slice($long_tail_keywords, 0, $limit);
    }
    
    /**
     * Get Google suggestions
     */
    private function get_google_suggestions($keyword) {
        $suggestions = array();
        
        // Simulate Google autocomplete suggestions
        $autocomplete_patterns = array(
            $keyword . ' guide',
            $keyword . ' tips',
            $keyword . ' tutorial',
            $keyword . ' review',
            $keyword . ' comparison',
            'best ' . $keyword,
            'how to ' . $keyword,
            $keyword . ' for beginners',
            $keyword . ' examples',
            $keyword . ' benefits'
        );
        
        foreach ($autocomplete_patterns as $pattern) {
            $suggestions[] = array(
                'keyword' => $pattern,
                'source' => 'google_autocomplete',
                'search_volume' => $this->estimate_search_volume($pattern),
                'difficulty' => $this->estimate_difficulty($pattern),
                'relevance_score' => 0.7
            );
        }
        
        return $suggestions;
    }
    
    /**
     * Get related terms
     */
    private function get_related_terms($keyword) {
        $related_terms = array();
        
        // Get terms from WordPress tags and categories
        $tags = get_tags(array('search' => $keyword, 'number' => 10));
        foreach ($tags as $tag) {
            $related_terms[] = array(
                'keyword' => $tag->name,
                'source' => 'wordpress_tags',
                'search_volume' => $this->estimate_search_volume($tag->name),
                'difficulty' => $this->estimate_difficulty($tag->name),
                'relevance_score' => 0.6
            );
        }
        
        $categories = get_categories(array('search' => $keyword, 'number' => 10));
        foreach ($categories as $category) {
            $related_terms[] = array(
                'keyword' => $category->name,
                'source' => 'wordpress_categories',
                'search_volume' => $this->estimate_search_volume($category->name),
                'difficulty' => $this->estimate_difficulty($category->name),
                'relevance_score' => 0.5
            );
        }
        
        return $related_terms;
    }
    
    /**
     * Get semantic keywords
     */
    private function get_semantic_keywords($keyword) {
        $semantic_keywords = array();
        
        // Generate semantic variations
        $keyword_parts = explode(' ', $keyword);
        
        if (count($keyword_parts) > 1) {
            // Create variations by rearranging words
            $variations = array(
                implode(' ', array_reverse($keyword_parts)),
                $keyword_parts[0] . ' and ' . implode(' ', array_slice($keyword_parts, 1)),
                implode(' ', array_slice($keyword_parts, 1)) . ' ' . $keyword_parts[0]
            );
            
            foreach ($variations as $variation) {
                $semantic_keywords[] = array(
                    'keyword' => $variation,
                    'source' => 'semantic_variation',
                    'search_volume' => $this->estimate_search_volume($variation),
                    'difficulty' => $this->estimate_difficulty($variation),
                    'relevance_score' => 0.4
                );
            }
        }
        
        return $semantic_keywords;
    }
    
    /**
     * Get synonyms
     */
    private function get_synonyms($keyword) {
        $synonyms = array();
        
        // Basic synonym mapping (in a real implementation, this would use an API)
        $synonym_map = array(
            'seo' => array('search engine optimization', 'search optimization', 'organic search'),
            'marketing' => array('promotion', 'advertising', 'branding'),
            'content' => array('articles', 'posts', 'material', 'information'),
            'website' => array('site', 'web page', 'online presence'),
            'business' => array('company', 'enterprise', 'organization'),
            'guide' => array('tutorial', 'manual', 'instructions', 'how-to'),
            'tips' => array('advice', 'suggestions', 'recommendations', 'hints')
        );
        
        $keyword_lower = strtolower($keyword);
        foreach ($synonym_map as $word => $word_synonyms) {
            if (strpos($keyword_lower, $word) !== false) {
                foreach ($word_synonyms as $synonym) {
                    $synonym_keyword = str_replace($word, $synonym, $keyword_lower);
                    $synonyms[] = array(
                        'keyword' => $synonym_keyword,
                        'source' => 'synonym',
                        'search_volume' => $this->estimate_search_volume($synonym_keyword),
                        'difficulty' => $this->estimate_difficulty($synonym_keyword),
                        'relevance_score' => 0.6
                    );
                }
            }
        }
        
        return $synonyms;
    }
    
    /**
     * Get keyword variations
     */
    private function get_keyword_variations($keyword) {
        $variations = array();
        
        // Plural/singular variations
        if (substr($keyword, -1) === 's') {
            $singular = rtrim($keyword, 's');
            $variations[] = array(
                'keyword' => $singular,
                'source' => 'singular_variation',
                'search_volume' => $this->estimate_search_volume($singular),
                'difficulty' => $this->estimate_difficulty($singular),
                'relevance_score' => 0.8
            );
        } else {
            $plural = $keyword . 's';
            $variations[] = array(
                'keyword' => $plural,
                'source' => 'plural_variation',
                'search_volume' => $this->estimate_search_volume($plural),
                'difficulty' => $this->estimate_difficulty($plural),
                'relevance_score' => 0.8
            );
        }
        
        // Add common prefixes and suffixes
        $prefixes = array('best', 'top', 'free', 'online');
        $suffixes = array('guide', 'tips', 'tutorial', 'review');
        
        foreach ($prefixes as $prefix) {
            $variations[] = array(
                'keyword' => $prefix . ' ' . $keyword,
                'source' => 'prefix_variation',
                'search_volume' => $this->estimate_search_volume($prefix . ' ' . $keyword),
                'difficulty' => $this->estimate_difficulty($prefix . ' ' . $keyword),
                'relevance_score' => 0.5
            );
        }
        
        foreach ($suffixes as $suffix) {
            $variations[] = array(
                'keyword' => $keyword . ' ' . $suffix,
                'source' => 'suffix_variation',
                'search_volume' => $this->estimate_search_volume($keyword . ' ' . $suffix),
                'difficulty' => $this->estimate_difficulty($keyword . ' ' . $suffix),
                'relevance_score' => 0.5
            );
        }
        
        return $variations;
    }
    
    /**
     * Enrich keyword data with search volume and difficulty
     */
    private function enrich_keyword_data($keywords, $options) {
        foreach ($keywords as &$keyword) {
            if ($options['include_search_volume'] && !isset($keyword['search_volume'])) {
                $keyword['search_volume'] = $this->estimate_search_volume($keyword['keyword']);
            }
            
            if ($options['include_difficulty'] && !isset($keyword['difficulty'])) {
                $keyword['difficulty'] = $this->estimate_difficulty($keyword['keyword']);
            }
        }
        
        return $keywords;
    }
    
    /**
     * Calculate keyword relevance
     */
    private function calculate_keyword_relevance($keyword, $seed_keyword, $content = '') {
        $relevance = 0;
        
        // Similarity to seed keyword
        $similarity = $this->calculate_string_similarity($keyword, $seed_keyword);
        $relevance += $similarity * 0.4;
        
        // Length factor (shorter keywords are often more valuable)
        $length_factor = 1 - (strlen($keyword) / 100);
        $relevance += $length_factor * 0.2;
        
        // Content relevance
        if (!empty($content)) {
            $content_relevance = $this->calculate_content_relevance($keyword, $content);
            $relevance += $content_relevance * 0.4;
        } else {
            $relevance += 0.4; // Default content relevance
        }
        
        return min(1, $relevance);
    }
    
    /**
     * Calculate string similarity
     */
    private function calculate_string_similarity($str1, $str2) {
        $str1_lower = strtolower($str1);
        $str2_lower = strtolower($str2);
        
        // Exact match
        if ($str1_lower === $str2_lower) {
            return 1.0;
        }
        
        // Contains match
        if (strpos($str1_lower, $str2_lower) !== false || strpos($str2_lower, $str1_lower) !== false) {
            return 0.8;
        }
        
        // Word overlap
        $words1 = explode(' ', $str1_lower);
        $words2 = explode(' ', $str2_lower);
        $common_words = array_intersect($words1, $words2);
        
        if (!empty($common_words)) {
            return count($common_words) / max(count($words1), count($words2));
        }
        
        // Levenshtein distance
        $distance = levenshtein($str1_lower, $str2_lower);
        $max_length = max(strlen($str1_lower), strlen($str2_lower));
        
        return 1 - ($distance / $max_length);
    }
    
    /**
     * Estimate search volume
     */
    private function estimate_search_volume($keyword) {
        // Simple estimation based on keyword characteristics
        $base_volume = 1000;
        $keyword_length = strlen($keyword);
        $word_count = str_word_count($keyword);
        
        // Shorter keywords typically have higher volume
        if ($keyword_length < 10) {
            $base_volume *= 2;
        } elseif ($keyword_length > 30) {
            $base_volume *= 0.3;
        }
        
        // Single words typically have higher volume
        if ($word_count === 1) {
            $base_volume *= 1.5;
        } elseif ($word_count > 4) {
            $base_volume *= 0.4;
        }
        
        // Add some randomness to make it more realistic
        $variation = rand(50, 150) / 100;
        
        return intval($base_volume * $variation);
    }
    
    /**
     * Estimate difficulty
     */
    private function estimate_difficulty($keyword) {
        // Simple estimation based on keyword characteristics
        $base_difficulty = 50;
        $keyword_length = strlen($keyword);
        $word_count = str_word_count($keyword);
        
        // Shorter keywords are typically more difficult
        if ($keyword_length < 10) {
            $base_difficulty += 20;
        } elseif ($keyword_length > 30) {
            $base_difficulty -= 15;
        }
        
        // Single words are typically more difficult
        if ($word_count === 1) {
            $base_difficulty += 15;
        } elseif ($word_count > 4) {
            $base_difficulty -= 10;
        }
        
        // Commercial intent keywords are more difficult
        $commercial_words = array('buy', 'purchase', 'price', 'cost', 'cheap', 'best', 'review');
        foreach ($commercial_words as $word) {
            if (strpos(strtolower($keyword), $word) !== false) {
                $base_difficulty += 10;
                break;
            }
        }
        
        return min(100, max(1, $base_difficulty));
    }
}

