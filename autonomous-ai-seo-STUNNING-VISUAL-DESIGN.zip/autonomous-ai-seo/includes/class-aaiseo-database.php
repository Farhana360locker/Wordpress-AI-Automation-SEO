<?php
/**
 * Database Management Class
 * Handles all database operations for Autonomous AI SEO
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Database {
    
    /**
     * Database version
     */
    const DB_VERSION = '2.0.0';
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'check_database_version'));
    }
    
    /**
     * Check if database needs updating
     */
    public function check_database_version() {
        $current_version = get_option('aaiseo_db_version', '0.0.0');
        
        if (version_compare($current_version, self::DB_VERSION, '<')) {
            $this->update_database();
        }
    }
    
    /**
     * Update database structure
     */
    public function update_database() {
        $this->create_tables();
        $this->create_indexes();
        $this->migrate_data();
        
        update_option('aaiseo_db_version', self::DB_VERSION);
    }
    
    /**
     * Create database tables
     */
    public function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        $table_prefix = $wpdb->prefix . AAISEO_TABLE_PREFIX;
        
        $tables = array(
            'seo_analysis' => "CREATE TABLE {$table_prefix}seo_analysis (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                post_id bigint(20) NOT NULL,
                seo_score int(3) DEFAULT 0,
                content_score int(3) DEFAULT 0,
                technical_score int(3) DEFAULT 0,
                focus_keyword varchar(255) DEFAULT '',
                secondary_keywords text DEFAULT '',
                meta_title varchar(255) DEFAULT '',
                meta_description text DEFAULT '',
                canonical_url varchar(500) DEFAULT '',
                schema_markup longtext DEFAULT '',
                analysis_data longtext DEFAULT '',
                recommendations longtext DEFAULT '',
                last_analyzed datetime DEFAULT CURRENT_TIMESTAMP,
                status enum('pending','analyzing','completed','error') DEFAULT 'pending',
                PRIMARY KEY (id),
                UNIQUE KEY post_id (post_id),
                KEY seo_score (seo_score),
                KEY status (status),
                KEY last_analyzed (last_analyzed)
            ) $charset_collate;",
            
            'keyword_rankings' => "CREATE TABLE {$table_prefix}keyword_rankings (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                keyword varchar(255) NOT NULL,
                url varchar(500) NOT NULL,
                position int(3) DEFAULT 0,
                previous_position int(3) DEFAULT 0,
                search_volume int(10) DEFAULT 0,
                difficulty int(3) DEFAULT 0,
                cpc decimal(10,2) DEFAULT 0,
                competition varchar(20) DEFAULT 'unknown',
                search_engine varchar(20) DEFAULT 'google',
                location varchar(100) DEFAULT 'global',
                device varchar(20) DEFAULT 'desktop',
                tracked_date date NOT NULL,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY keyword (keyword),
                KEY position (position),
                KEY tracked_date (tracked_date),
                KEY search_engine (search_engine),
                UNIQUE KEY unique_tracking (keyword, url, search_engine, location, device, tracked_date)
            ) $charset_collate;",
            
            'competitor_data' => "CREATE TABLE {$table_prefix}competitor_data (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                domain varchar(255) NOT NULL,
                company_name varchar(255) DEFAULT '',
                industry varchar(100) DEFAULT '',
                monitoring_level enum('basic','standard','deep','enterprise') DEFAULT 'standard',
                priority enum('low','medium','high','critical') DEFAULT 'medium',
                target_keywords text DEFAULT '',
                organic_keywords int(10) DEFAULT 0,
                organic_traffic int(10) DEFAULT 0,
                paid_keywords int(10) DEFAULT 0,
                backlinks int(10) DEFAULT 0,
                domain_authority int(3) DEFAULT 0,
                page_authority int(3) DEFAULT 0,
                trust_flow int(3) DEFAULT 0,
                citation_flow int(3) DEFAULT 0,
                social_signals longtext DEFAULT '',
                content_analysis longtext DEFAULT '',
                technical_analysis longtext DEFAULT '',
                analysis_data longtext DEFAULT '',
                last_analyzed datetime DEFAULT CURRENT_TIMESTAMP,
                status enum('active','paused','inactive','error') DEFAULT 'active',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY domain (domain),
                KEY industry (industry),
                KEY priority (priority),
                KEY status (status),
                KEY last_analyzed (last_analyzed)
            ) $charset_collate;",
            
            'performance_metrics' => "CREATE TABLE {$table_prefix}performance_metrics (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                metric_type varchar(50) NOT NULL,
                metric_name varchar(100) NOT NULL,
                metric_value decimal(15,4) NOT NULL,
                metric_unit varchar(20) DEFAULT '',
                page_url varchar(500) DEFAULT '',
                device_type varchar(20) DEFAULT 'desktop',
                location varchar(100) DEFAULT 'global',
                metric_data longtext DEFAULT '',
                recorded_date date NOT NULL,
                recorded_time time NOT NULL,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY metric_type (metric_type),
                KEY metric_name (metric_name),
                KEY recorded_date (recorded_date),
                KEY page_url (page_url),
                KEY device_type (device_type)
            ) $charset_collate;",
            
            'content_analysis' => "CREATE TABLE {$table_prefix}content_analysis (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                post_id bigint(20) NOT NULL,
                content_type varchar(50) DEFAULT 'post',
                content_score int(3) DEFAULT 0,
                readability_score int(3) DEFAULT 0,
                keyword_density decimal(5,2) DEFAULT 0,
                word_count int(10) DEFAULT 0,
                sentence_count int(10) DEFAULT 0,
                paragraph_count int(10) DEFAULT 0,
                heading_count int(10) DEFAULT 0,
                image_count int(10) DEFAULT 0,
                link_count int(10) DEFAULT 0,
                internal_links int(10) DEFAULT 0,
                external_links int(10) DEFAULT 0,
                flesch_reading_ease decimal(5,2) DEFAULT 0,
                flesch_kincaid_grade decimal(5,2) DEFAULT 0,
                automated_readability_index decimal(5,2) DEFAULT 0,
                sentiment_score decimal(5,2) DEFAULT 0,
                content_uniqueness decimal(5,2) DEFAULT 0,
                analysis_data longtext DEFAULT '',
                suggestions longtext DEFAULT '',
                ai_recommendations longtext DEFAULT '',
                last_analyzed datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY post_id (post_id),
                KEY content_score (content_score),
                KEY readability_score (readability_score),
                KEY last_analyzed (last_analyzed)
            ) $charset_collate;",
            
            'technical_audits' => "CREATE TABLE {$table_prefix}technical_audits (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                audit_type varchar(50) NOT NULL,
                audit_name varchar(100) NOT NULL,
                audit_score int(3) DEFAULT 0,
                issues_found int(5) DEFAULT 0,
                issues_fixed int(5) DEFAULT 0,
                critical_issues int(5) DEFAULT 0,
                warning_issues int(5) DEFAULT 0,
                info_issues int(5) DEFAULT 0,
                page_url varchar(500) DEFAULT '',
                audit_data longtext DEFAULT '',
                recommendations longtext DEFAULT '',
                fix_suggestions longtext DEFAULT '',
                audit_date datetime DEFAULT CURRENT_TIMESTAMP,
                status enum('pending','running','completed','failed') DEFAULT 'pending',
                PRIMARY KEY (id),
                KEY audit_type (audit_type),
                KEY audit_score (audit_score),
                KEY audit_date (audit_date),
                KEY status (status)
            ) $charset_collate;",
            
            'settings' => "CREATE TABLE {$table_prefix}settings (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                setting_group varchar(50) NOT NULL,
                setting_name varchar(100) NOT NULL,
                setting_value longtext DEFAULT '',
                setting_type varchar(20) DEFAULT 'string',
                is_encrypted tinyint(1) DEFAULT 0,
                autoload enum('yes','no') DEFAULT 'yes',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                UNIQUE KEY setting_key (setting_group, setting_name),
                KEY autoload (autoload),
                KEY setting_group (setting_group)
            ) $charset_collate;",
            
            'keyword_research' => "CREATE TABLE {$table_prefix}keyword_research (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                seed_keyword varchar(255) NOT NULL,
                related_keyword varchar(255) NOT NULL,
                search_volume int(10) DEFAULT 0,
                keyword_difficulty int(3) DEFAULT 0,
                cpc decimal(10,2) DEFAULT 0,
                competition varchar(20) DEFAULT 'unknown',
                search_intent varchar(50) DEFAULT 'unknown',
                trend_data longtext DEFAULT '',
                serp_features longtext DEFAULT '',
                questions longtext DEFAULT '',
                related_terms longtext DEFAULT '',
                search_engine varchar(20) DEFAULT 'google',
                location varchar(100) DEFAULT 'global',
                language varchar(10) DEFAULT 'en',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY seed_keyword (seed_keyword),
                KEY related_keyword (related_keyword),
                KEY search_volume (search_volume),
                KEY keyword_difficulty (keyword_difficulty),
                KEY search_intent (search_intent)
            ) $charset_collate;",
            
            'backlink_analysis' => "CREATE TABLE {$table_prefix}backlink_analysis (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                target_url varchar(500) NOT NULL,
                source_url varchar(500) NOT NULL,
                source_domain varchar(255) NOT NULL,
                anchor_text varchar(500) DEFAULT '',
                link_type enum('dofollow','nofollow','ugc','sponsored') DEFAULT 'dofollow',
                link_status enum('active','broken','redirect','noindex') DEFAULT 'active',
                domain_authority int(3) DEFAULT 0,
                page_authority int(3) DEFAULT 0,
                trust_flow int(3) DEFAULT 0,
                citation_flow int(3) DEFAULT 0,
                spam_score int(3) DEFAULT 0,
                first_seen date DEFAULT NULL,
                last_seen date DEFAULT NULL,
                link_context text DEFAULT '',
                analysis_data longtext DEFAULT '',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY target_url (target_url),
                KEY source_domain (source_domain),
                KEY link_type (link_type),
                KEY link_status (link_status),
                KEY domain_authority (domain_authority)
            ) $charset_collate;",
            
            'ai_content_queue' => "CREATE TABLE {$table_prefix}ai_content_queue (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                post_id bigint(20) DEFAULT NULL,
                content_type varchar(50) NOT NULL,
                target_keyword varchar(255) DEFAULT '',
                content_brief longtext DEFAULT '',
                ai_model varchar(50) DEFAULT 'gpt-3.5-turbo',
                content_length varchar(20) DEFAULT 'medium',
                tone varchar(50) DEFAULT 'professional',
                language varchar(10) DEFAULT 'en',
                generated_content longtext DEFAULT '',
                content_score int(3) DEFAULT 0,
                status enum('pending','generating','completed','failed','published') DEFAULT 'pending',
                error_message text DEFAULT '',
                generation_time int(5) DEFAULT 0,
                tokens_used int(10) DEFAULT 0,
                cost decimal(10,4) DEFAULT 0,
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY post_id (post_id),
                KEY content_type (content_type),
                KEY status (status),
                KEY created_at (created_at)
            ) $charset_collate;",
            
            'user_activity' => "CREATE TABLE {$table_prefix}user_activity (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                user_id bigint(20) NOT NULL,
                activity_type varchar(50) NOT NULL,
                activity_description text DEFAULT '',
                object_type varchar(50) DEFAULT '',
                object_id bigint(20) DEFAULT NULL,
                ip_address varchar(45) DEFAULT '',
                user_agent text DEFAULT '',
                activity_data longtext DEFAULT '',
                created_at datetime DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                KEY user_id (user_id),
                KEY activity_type (activity_type),
                KEY object_type (object_type),
                KEY created_at (created_at)
            ) $charset_collate;"
        );
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        
        foreach ($tables as $table_name => $sql) {
            dbDelta($sql);
        }
    }
    
    /**
     * Create database indexes for performance
     */
    public function create_indexes() {
        global $wpdb;
        
        $table_prefix = $wpdb->prefix . AAISEO_TABLE_PREFIX;
        
        // Additional indexes for performance
        $indexes = array(
            "CREATE INDEX idx_seo_analysis_score_date ON {$table_prefix}seo_analysis (seo_score, last_analyzed)",
            "CREATE INDEX idx_keyword_rankings_position_date ON {$table_prefix}keyword_rankings (position, tracked_date)",
            "CREATE INDEX idx_competitor_priority_status ON {$table_prefix}competitor_data (priority, status)",
            "CREATE INDEX idx_performance_type_date ON {$table_prefix}performance_metrics (metric_type, recorded_date)",
            "CREATE INDEX idx_content_score_date ON {$table_prefix}content_analysis (content_score, last_analyzed)",
            "CREATE INDEX idx_technical_type_score ON {$table_prefix}technical_audits (audit_type, audit_score)",
            "CREATE INDEX idx_keyword_research_volume ON {$table_prefix}keyword_research (search_volume DESC)",
            "CREATE INDEX idx_backlink_domain_authority ON {$table_prefix}backlink_analysis (domain_authority DESC)",
            "CREATE INDEX idx_ai_queue_status_created ON {$table_prefix}ai_content_queue (status, created_at)"
        );
        
        foreach ($indexes as $index_sql) {
            $wpdb->query($index_sql);
        }
    }
    
    /**
     * Migrate data from previous versions
     */
    public function migrate_data() {
        $current_version = get_option('aaiseo_db_version', '0.0.0');
        
        // Migration logic based on version
        if (version_compare($current_version, '1.0.0', '<')) {
            $this->migrate_from_1_0_0();
        }
        
        if (version_compare($current_version, '1.5.0', '<')) {
            $this->migrate_from_1_5_0();
        }
    }
    
    /**
     * Migration from version 1.0.0
     */
    private function migrate_from_1_0_0() {
        // Migrate old post meta to new table structure
        global $wpdb;
        
        $old_meta = $wpdb->get_results("
            SELECT post_id, meta_key, meta_value 
            FROM {$wpdb->postmeta} 
            WHERE meta_key LIKE '_aaiseo_%'
        ");
        
        foreach ($old_meta as $meta) {
            // Process and migrate old meta data
            $this->migrate_post_meta($meta);
        }
    }
    
    /**
     * Migration from version 1.5.0
     */
    private function migrate_from_1_5_0() {
        // Add new columns or update data structure
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        
        // Check if new columns exist, if not add them
        $columns = $wpdb->get_col("DESCRIBE {$table_name}");
        
        if (!in_array('technical_score', $columns)) {
            $wpdb->query("ALTER TABLE {$table_name} ADD COLUMN technical_score int(3) DEFAULT 0 AFTER content_score");
        }
    }
    
    /**
     * Migrate individual post meta
     */
    private function migrate_post_meta($meta) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        
        // Extract data from old meta format
        $post_id = $meta->post_id;
        $meta_key = str_replace('_aaiseo_', '', $meta->meta_key);
        $meta_value = $meta->meta_value;
        
        // Insert or update in new table structure
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$table_name} WHERE post_id = %d",
            $post_id
        ));
        
        if ($existing) {
            $wpdb->update(
                $table_name,
                array($meta_key => $meta_value),
                array('post_id' => $post_id),
                array('%s'),
                array('%d')
            );
        } else {
            $wpdb->insert(
                $table_name,
                array(
                    'post_id' => $post_id,
                    $meta_key => $meta_value,
                    'last_analyzed' => current_time('mysql')
                ),
                array('%d', '%s', '%s')
            );
        }
    }
    
    /**
     * Get SEO analysis data
     */
    public function get_seo_analysis($post_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE post_id = %d",
            $post_id
        ));
    }
    
    /**
     * Save SEO analysis data
     */
    public function save_seo_analysis($data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        
        $existing = $this->get_seo_analysis($data['post_id']);
        
        if ($existing) {
            return $wpdb->update(
                $table_name,
                $data,
                array('post_id' => $data['post_id']),
                null,
                array('%d')
            );
        } else {
            return $wpdb->insert($table_name, $data);
        }
    }
    
    /**
     * Get keyword rankings
     */
    public function get_keyword_rankings($limit = 50, $offset = 0) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'keyword_rankings';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} 
             ORDER BY tracked_date DESC, position ASC 
             LIMIT %d OFFSET %d",
            $limit,
            $offset
        ));
    }
    
    /**
     * Save keyword ranking
     */
    public function save_keyword_ranking($data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'keyword_rankings';
        
        return $wpdb->replace($table_name, $data);
    }
    
    /**
     * Get competitor data
     */
    public function get_competitors($status = 'active') {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'competitor_data';
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE status = %s ORDER BY priority DESC, last_analyzed ASC",
            $status
        ));
    }
    
    /**
     * Save competitor data
     */
    public function save_competitor_data($data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'competitor_data';
        
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM {$table_name} WHERE domain = %s",
            $data['domain']
        ));
        
        if ($existing) {
            return $wpdb->update(
                $table_name,
                $data,
                array('domain' => $data['domain']),
                null,
                array('%s')
            );
        } else {
            return $wpdb->insert($table_name, $data);
        }
    }
    
    /**
     * Get performance metrics
     */
    public function get_performance_metrics($metric_type = null, $days = 30) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'performance_metrics';
        
        $where_clause = "WHERE recorded_date >= DATE_SUB(CURDATE(), INTERVAL %d DAY)";
        $params = array($days);
        
        if ($metric_type) {
            $where_clause .= " AND metric_type = %s";
            $params[] = $metric_type;
        }
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} {$where_clause} ORDER BY recorded_date DESC",
            ...$params
        ));
    }
    
    /**
     * Save performance metric
     */
    public function save_performance_metric($data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'performance_metrics';
        
        return $wpdb->insert($table_name, $data);
    }
    
    /**
     * Get content analysis
     */
    public function get_content_analysis($post_id) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'content_analysis';
        
        return $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE post_id = %d",
            $post_id
        ));
    }
    
    /**
     * Save content analysis
     */
    public function save_content_analysis($data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'content_analysis';
        
        $existing = $this->get_content_analysis($data['post_id']);
        
        if ($existing) {
            return $wpdb->update(
                $table_name,
                $data,
                array('post_id' => $data['post_id']),
                null,
                array('%d')
            );
        } else {
            return $wpdb->insert($table_name, $data);
        }
    }
    
    /**
     * Get technical audits
     */
    public function get_technical_audits($audit_type = null, $limit = 50) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'technical_audits';
        
        $where_clause = "";
        $params = array();
        
        if ($audit_type) {
            $where_clause = "WHERE audit_type = %s";
            $params[] = $audit_type;
        }
        
        $params[] = $limit;
        
        return $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$table_name} {$where_clause} ORDER BY audit_date DESC LIMIT %d",
            ...$params
        ));
    }
    
    /**
     * Save technical audit
     */
    public function save_technical_audit($data) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'technical_audits';
        
        return $wpdb->insert($table_name, $data);
    }
    
    /**
     * Get plugin setting
     */
    public function get_setting($group, $name, $default = null) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'settings';
        
        $result = $wpdb->get_var($wpdb->prepare(
            "SELECT setting_value FROM {$table_name} WHERE setting_group = %s AND setting_name = %s",
            $group,
            $name
        ));
        
        if ($result === null) {
            return $default;
        }
        
        // Decrypt if needed
        $is_encrypted = $wpdb->get_var($wpdb->prepare(
            "SELECT is_encrypted FROM {$table_name} WHERE setting_group = %s AND setting_name = %s",
            $group,
            $name
        ));
        
        if ($is_encrypted) {
            $result = $this->decrypt_setting($result);
        }
        
        return maybe_unserialize($result);
    }
    
    /**
     * Save plugin setting
     */
    public function save_setting($group, $name, $value, $type = 'string', $encrypt = false) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'settings';
        
        $serialized_value = maybe_serialize($value);
        
        if ($encrypt) {
            $serialized_value = $this->encrypt_setting($serialized_value);
        }
        
        return $wpdb->replace(
            $table_name,
            array(
                'setting_group' => $group,
                'setting_name' => $name,
                'setting_value' => $serialized_value,
                'setting_type' => $type,
                'is_encrypted' => $encrypt ? 1 : 0
            ),
            array('%s', '%s', '%s', '%s', '%d')
        );
    }
    
    /**
     * Encrypt sensitive setting
     */
    private function encrypt_setting($value) {
        if (!function_exists('openssl_encrypt')) {
            return $value; // Fallback if OpenSSL not available
        }
        
        $key = $this->get_encryption_key();
        $iv = openssl_random_pseudo_bytes(16);
        $encrypted = openssl_encrypt($value, 'AES-256-CBC', $key, 0, $iv);
        
        return base64_encode($iv . $encrypted);
    }
    
    /**
     * Decrypt sensitive setting
     */
    private function decrypt_setting($encrypted_value) {
        if (!function_exists('openssl_decrypt')) {
            return $encrypted_value; // Fallback if OpenSSL not available
        }
        
        $key = $this->get_encryption_key();
        $data = base64_decode($encrypted_value);
        $iv = substr($data, 0, 16);
        $encrypted = substr($data, 16);
        
        return openssl_decrypt($encrypted, 'AES-256-CBC', $key, 0, $iv);
    }
    
    /**
     * Get encryption key
     */
    private function get_encryption_key() {
        $key = get_option('aaiseo_encryption_key');
        
        if (!$key) {
            $key = wp_generate_password(32, false);
            update_option('aaiseo_encryption_key', $key);
        }
        
        return $key;
    }
    
    /**
     * Clean up old data
     */
    public function cleanup_old_data($days = 90) {
        global $wpdb;
        
        $table_prefix = $wpdb->prefix . AAISEO_TABLE_PREFIX;
        
        // Clean up old performance metrics
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$table_prefix}performance_metrics WHERE recorded_date < DATE_SUB(CURDATE(), INTERVAL %d DAY)",
            $days
        ));
        
        // Clean up old technical audits
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$table_prefix}technical_audits WHERE audit_date < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
        
        // Clean up old user activity
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$table_prefix}user_activity WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            $days
        ));
        
        // Clean up completed AI content queue items
        $wpdb->query($wpdb->prepare(
            "DELETE FROM {$table_prefix}ai_content_queue WHERE status IN ('completed', 'published') AND updated_at < DATE_SUB(NOW(), INTERVAL %d DAY)",
            30 // Keep completed items for 30 days
        ));
    }
    
    /**
     * Get database statistics
     */
    public function get_database_stats() {
        global $wpdb;
        
        $table_prefix = $wpdb->prefix . AAISEO_TABLE_PREFIX;
        
        $stats = array();
        
        $tables = array(
            'seo_analysis',
            'keyword_rankings',
            'competitor_data',
            'performance_metrics',
            'content_analysis',
            'technical_audits',
            'keyword_research',
            'backlink_analysis',
            'ai_content_queue',
            'user_activity'
        );
        
        foreach ($tables as $table) {
            $count = $wpdb->get_var("SELECT COUNT(*) FROM {$table_prefix}{$table}");
            $stats[$table] = intval($count);
        }
        
        return $stats;
    }
    
    /**
     * Optimize database tables
     */
    public function optimize_tables() {
        global $wpdb;
        
        $table_prefix = $wpdb->prefix . AAISEO_TABLE_PREFIX;
        
        $tables = array(
            'seo_analysis',
            'keyword_rankings',
            'competitor_data',
            'performance_metrics',
            'content_analysis',
            'technical_audits',
            'settings',
            'keyword_research',
            'backlink_analysis',
            'ai_content_queue',
            'user_activity'
        );
        
        foreach ($tables as $table) {
            $wpdb->query("OPTIMIZE TABLE {$table_prefix}{$table}");
        }
        
        return true;
    }
    
    /**
     * Export data for backup
     */
    public function export_data($tables = null) {
        global $wpdb;
        
        $table_prefix = $wpdb->prefix . AAISEO_TABLE_PREFIX;
        
        if (!$tables) {
            $tables = array(
                'seo_analysis',
                'keyword_rankings',
                'competitor_data',
                'settings'
            );
        }
        
        $export_data = array();
        
        foreach ($tables as $table) {
            $data = $wpdb->get_results("SELECT * FROM {$table_prefix}{$table}", ARRAY_A);
            $export_data[$table] = $data;
        }
        
        return $export_data;
    }
    
    /**
     * Import data from backup
     */
    public function import_data($import_data) {
        global $wpdb;
        
        $table_prefix = $wpdb->prefix . AAISEO_TABLE_PREFIX;
        
        foreach ($import_data as $table => $data) {
            if (!is_array($data)) {
                continue;
            }
            
            foreach ($data as $row) {
                $wpdb->replace("{$table_prefix}{$table}", $row);
            }
        }
        
        return true;
    }
}

