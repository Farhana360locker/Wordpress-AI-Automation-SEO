<?php
/**
 * Google API Class
 * 
 * @package Autonomous_AI_SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Google API integration class
 */
class AAISEO_Google_API {
    
    /**
     * API key
     */
    private $api_key;
    
    /**
     * Base URLs
     */
    private $search_console_url = 'https://www.googleapis.com/webmasters/v3/';
    private $analytics_url = 'https://analyticsreporting.googleapis.com/v4/';
    private $keyword_planner_url = 'https://googleads.googleapis.com/v14/';
    
    /**
     * Constructor
     */
    public function __construct($api_key = null) {
        $this->api_key = $api_key ?: get_option('aaiseo_google_api_key');
    }
    
    /**
     * Test API connection
     */
    public function test_connection() {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'message' => 'Google API key is not configured'
            );
        }
        
        // Test with a simple Search Console API call
        $response = $this->make_request('sites', 'GET');
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => 'Connection failed: ' . $response->get_error_message()
            );
        }
        
        return array(
            'success' => true,
            'message' => 'Google API connection successful'
        );
    }
    
    /**
     * Get Search Console data
     */
    public function get_search_console_data($site_url, $start_date, $end_date, $dimensions = array('query')) {
        $endpoint = "sites/" . urlencode($site_url) . "/searchAnalytics/query";
        
        $body = array(
            'startDate' => $start_date,
            'endDate' => $end_date,
            'dimensions' => $dimensions,
            'rowLimit' => 1000
        );
        
        $response = $this->make_request($endpoint, 'POST', $body, $this->search_console_url);
        
        if (is_wp_error($response)) {
            return array('error' => $response->get_error_message());
        }
        
        return $response;
    }
    
    /**
     * Get keyword suggestions from Google Ads Keyword Planner
     */
    public function get_keyword_suggestions($seed_keywords, $location = 'US', $language = 'en') {
        // Note: This requires Google Ads API access
        $endpoint = 'customers/{customer_id}/keywordPlanAdGroupKeywords:generateKeywordIdeas';
        
        $body = array(
            'keywordSeed' => array(
                'keywords' => $seed_keywords
            ),
            'geoTargetConstants' => array('geoTargets/' . $this->get_location_id($location)),
            'language' => 'languageConstants/' . $this->get_language_id($language),
            'includeAdultKeywords' => false
        );
        
        $response = $this->make_request($endpoint, 'POST', $body, $this->keyword_planner_url);
        
        if (is_wp_error($response)) {
            return array('error' => $response->get_error_message());
        }
        
        return $this->process_keyword_suggestions($response);
    }
    
    /**
     * Get Analytics data
     */
    public function get_analytics_data($view_id, $start_date, $end_date, $metrics, $dimensions = array()) {
        $endpoint = 'reports:batchGet';
        
        $body = array(
            'reportRequests' => array(
                array(
                    'viewId' => $view_id,
                    'dateRanges' => array(
                        array(
                            'startDate' => $start_date,
                            'endDate' => $end_date
                        )
                    ),
                    'metrics' => $metrics,
                    'dimensions' => $dimensions,
                    'pageSize' => 1000
                )
            )
        );
        
        $response = $this->make_request($endpoint, 'POST', $body, $this->analytics_url);
        
        if (is_wp_error($response)) {
            return array('error' => $response->get_error_message());
        }
        
        return $this->process_analytics_data($response);
    }
    
    /**
     * Get PageSpeed Insights data
     */
    public function get_pagespeed_insights($url, $strategy = 'mobile') {
        $endpoint = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';
        
        $params = array(
            'url' => $url,
            'strategy' => $strategy,
            'category' => 'performance,accessibility,best-practices,seo',
            'key' => $this->api_key
        );
        
        $url_with_params = $endpoint . '?' . http_build_query($params);
        
        $response = wp_remote_get($url_with_params, array(
            'timeout' => 30,
            'headers' => array(
                'Content-Type' => 'application/json'
            )
        ));
        
        if (is_wp_error($response)) {
            return array('error' => $response->get_error_message());
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        return $this->process_pagespeed_data($data);
    }
    
    /**
     * Make API request
     */
    private function make_request($endpoint, $method = 'GET', $body = null, $base_url = null) {
        $base_url = $base_url ?: $this->search_console_url;
        $url = $base_url . $endpoint;
        
        $args = array(
            'method' => $method,
            'timeout' => 30,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            )
        );
        
        if ($body && in_array($method, array('POST', 'PUT', 'PATCH'))) {
            $args['body'] = json_encode($body);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return $response;
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        if ($response_code >= 400) {
            $error_data = json_decode($response_body, true);
            $error_message = isset($error_data['error']['message']) ? 
                $error_data['error']['message'] : 
                'HTTP ' . $response_code . ' error';
            
            return new WP_Error('google_api_error', $error_message);
        }
        
        return json_decode($response_body, true);
    }
    
    /**
     * Process keyword suggestions
     */
    private function process_keyword_suggestions($response) {
        $keywords = array();
        
        if (isset($response['results'])) {
            foreach ($response['results'] as $result) {
                $keywords[] = array(
                    'keyword' => $result['keywordIdeaMetrics']['keywordText'],
                    'search_volume' => $result['keywordIdeaMetrics']['avgMonthlySearches'] ?? 0,
                    'competition' => $result['keywordIdeaMetrics']['competition'] ?? 'UNKNOWN',
                    'cpc' => $result['keywordIdeaMetrics']['suggestedBidMicros'] ?? 0
                );
            }
        }
        
        return $keywords;
    }
    
    /**
     * Process Analytics data
     */
    private function process_analytics_data($response) {
        $processed = array();
        
        if (isset($response['reports'][0]['data']['rows'])) {
            foreach ($response['reports'][0]['data']['rows'] as $row) {
                $processed[] = array(
                    'dimensions' => $row['dimensions'] ?? array(),
                    'metrics' => $row['metrics'][0]['values'] ?? array()
                );
            }
        }
        
        return $processed;
    }
    
    /**
     * Process PageSpeed data
     */
    private function process_pagespeed_data($data) {
        if (!isset($data['lighthouseResult'])) {
            return array('error' => 'Invalid PageSpeed response');
        }
        
        $lighthouse = $data['lighthouseResult'];
        $categories = $lighthouse['categories'];
        
        return array(
            'performance_score' => round($categories['performance']['score'] * 100),
            'accessibility_score' => round($categories['accessibility']['score'] * 100),
            'best_practices_score' => round($categories['best-practices']['score'] * 100),
            'seo_score' => round($categories['seo']['score'] * 100),
            'core_web_vitals' => array(
                'lcp' => $lighthouse['audits']['largest-contentful-paint']['numericValue'] ?? 0,
                'fid' => $lighthouse['audits']['max-potential-fid']['numericValue'] ?? 0,
                'cls' => $lighthouse['audits']['cumulative-layout-shift']['numericValue'] ?? 0
            ),
            'opportunities' => $this->extract_opportunities($lighthouse['audits'])
        );
    }
    
    /**
     * Extract optimization opportunities
     */
    private function extract_opportunities($audits) {
        $opportunities = array();
        
        $opportunity_audits = array(
            'unused-css-rules',
            'unused-javascript',
            'modern-image-formats',
            'offscreen-images',
            'render-blocking-resources'
        );
        
        foreach ($opportunity_audits as $audit_id) {
            if (isset($audits[$audit_id]) && $audits[$audit_id]['score'] < 1) {
                $opportunities[] = array(
                    'id' => $audit_id,
                    'title' => $audits[$audit_id]['title'],
                    'description' => $audits[$audit_id]['description'],
                    'score' => $audits[$audit_id]['score'],
                    'savings' => $audits[$audit_id]['details']['overallSavingsMs'] ?? 0
                );
            }
        }
        
        return $opportunities;
    }
    
    /**
     * Get location ID for targeting
     */
    private function get_location_id($location) {
        $locations = array(
            'US' => '2840',
            'UK' => '2826',
            'CA' => '2124',
            'AU' => '2036',
            'DE' => '2276',
            'FR' => '2250',
            'IT' => '2380',
            'ES' => '2724',
            'BR' => '2076',
            'IN' => '2356',
            'JP' => '2392'
        );
        
        return isset($locations[$location]) ? $locations[$location] : '2840'; // Default to US
    }
    
    /**
     * Get language ID
     */
    private function get_language_id($language) {
        $languages = array(
            'en' => '1000',
            'es' => '1003',
            'fr' => '1002',
            'de' => '1001',
            'it' => '1004',
            'pt' => '1014',
            'ja' => '1005',
            'ko' => '1012',
            'zh' => '1017'
        );
        
        return isset($languages[$language]) ? $languages[$language] : '1000'; // Default to English
    }
}

