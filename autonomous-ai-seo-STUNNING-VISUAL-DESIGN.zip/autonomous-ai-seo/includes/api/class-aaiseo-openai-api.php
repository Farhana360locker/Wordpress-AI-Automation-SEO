<?php
/**
 * OpenAI API Class
 * 
 * @package Autonomous_AI_SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * OpenAI API integration class
 */
class AAISEO_OpenAI_API {
    
    /**
     * API key
     */
    private $api_key;
    
    /**
     * Base URL
     */
    private $base_url = 'https://api.openai.com/v1/';
    
    /**
     * Constructor
     */
    public function __construct($api_key = null) {
        $this->api_key = $api_key ?: get_option('aaiseo_openai_api_key');
    }
    
    /**
     * Test API connection
     */
    public function test_connection() {
        if (empty($this->api_key)) {
            return array(
                'success' => false,
                'message' => 'OpenAI API key is not configured'
            );
        }
        
        // Test with a simple completion
        $response = $this->generate_completion('Test', 5);
        
        if (isset($response['error'])) {
            return array(
                'success' => false,
                'message' => 'Connection failed: ' . $response['error']
            );
        }
        
        return array(
            'success' => true,
            'message' => 'OpenAI API connection successful'
        );
    }
    
    /**
     * Generate text completion
     */
    public function generate_completion($prompt, $max_tokens = 150, $model = 'gpt-3.5-turbo') {
        $endpoint = 'chat/completions';
        
        $body = array(
            'model' => $model,
            'messages' => array(
                array(
                    'role' => 'user',
                    'content' => $prompt
                )
            ),
            'max_tokens' => $max_tokens,
            'temperature' => 0.7,
            'top_p' => 1,
            'frequency_penalty' => 0,
            'presence_penalty' => 0
        );
        
        $response = $this->make_request($endpoint, 'POST', $body);
        
        if (isset($response['error'])) {
            return $response;
        }
        
        return array(
            'text' => $response['choices'][0]['message']['content'] ?? '',
            'tokens_used' => $response['usage']['total_tokens'] ?? 0,
            'model' => $model
        );
    }
    
    /**
     * Generate SEO meta description
     */
    public function generate_meta_description($title, $content, $keyword = '') {
        $keyword_instruction = $keyword ? "Focus on the keyword '$keyword'. " : '';
        
        $prompt = "Write a compelling SEO meta description (150-160 characters) for this content. {$keyword_instruction}
        
Title: $title

Content: " . substr(strip_tags($content), 0, 500) . "

Meta description:";
        
        return $this->generate_completion($prompt, 50);
    }
    
    /**
     * Generate SEO title suggestions
     */
    public function generate_title_suggestions($content, $keyword = '', $count = 5) {
        $keyword_instruction = $keyword ? "Include the keyword '$keyword' naturally. " : '';
        
        $prompt = "Generate $count SEO-optimized title suggestions for this content. {$keyword_instruction}Titles should be 50-60 characters, compelling, and click-worthy.

Content: " . substr(strip_tags($content), 0, 500) . "

Title suggestions:";
        
        $response = $this->generate_completion($prompt, 150);
        
        if (isset($response['error'])) {
            return $response;
        }
        
        // Parse titles from response
        $titles = array_filter(array_map('trim', explode("\n", $response['text'])));
        
        return array(
            'titles' => $titles,
            'tokens_used' => $response['tokens_used']
        );
    }
    
    /**
     * Generate content outline
     */
    public function generate_content_outline($topic, $keyword = '', $target_length = 'medium') {
        $length_instruction = array(
            'short' => '5-7 sections',
            'medium' => '8-12 sections',
            'long' => '12-15 sections'
        );
        
        $keyword_instruction = $keyword ? "Focus on the keyword '$keyword'. " : '';
        
        $prompt = "Create a comprehensive content outline for an article about '$topic'. {$keyword_instruction}Include {$length_instruction[$target_length]} with descriptive headings and brief descriptions.

Topic: $topic

Outline:";
        
        return $this->generate_completion($prompt, 300);
    }
    
    /**
     * Improve content readability
     */
    public function improve_readability($content, $target_audience = 'general') {
        $audience_instruction = array(
            'general' => 'general audience (8th grade reading level)',
            'technical' => 'technical audience with industry knowledge',
            'beginner' => 'beginners with no prior knowledge'
        );
        
        $prompt = "Improve the readability of this content for a {$audience_instruction[$target_audience]}. Make it clearer, more engaging, and easier to understand while maintaining the original meaning and SEO value.

Original content:
" . substr(strip_tags($content), 0, 1000) . "

Improved content:";
        
        return $this->generate_completion($prompt, 500);
    }
    
    /**
     * Generate FAQ section
     */
    public function generate_faq($topic, $keyword = '', $count = 5) {
        $keyword_instruction = $keyword ? "Include questions related to '$keyword'. " : '';
        
        $prompt = "Generate $count frequently asked questions and answers about '$topic'. {$keyword_instruction}Make them relevant, helpful, and SEO-friendly.

Topic: $topic

FAQ:";
        
        return $this->generate_completion($prompt, 400);
    }
    
    /**
     * Analyze content sentiment
     */
    public function analyze_sentiment($content) {
        $prompt = "Analyze the sentiment and tone of this content. Provide a brief analysis including:
1. Overall sentiment (positive/negative/neutral)
2. Tone (professional/casual/friendly/etc.)
3. Emotional impact
4. Suggestions for improvement

Content: " . substr(strip_tags($content), 0, 800) . "

Analysis:";
        
        return $this->generate_completion($prompt, 200);
    }
    
    /**
     * Generate schema markup
     */
    public function generate_schema_markup($content_type, $data) {
        $prompt = "Generate JSON-LD schema markup for a $content_type with this information:

" . json_encode($data, JSON_PRETTY_PRINT) . "

Provide valid, complete schema markup:";
        
        return $this->generate_completion($prompt, 300);
    }
    
    /**
     * Make API request
     */
    private function make_request($endpoint, $method = 'GET', $body = null) {
        $url = $this->base_url . $endpoint;
        
        $args = array(
            'method' => $method,
            'timeout' => 60,
            'headers' => array(
                'Authorization' => 'Bearer ' . $this->api_key,
                'Content-Type' => 'application/json'
            )
        );
        
        if ($body && in_array($method, array('POST', 'PUT', 'PATCH'))) {
            $args['body'] = json_encode($body);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return array('error' => $response->get_error_message());
        }
        
        $response_code = wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        
        $data = json_decode($response_body, true);
        
        if ($response_code >= 400) {
            $error_message = isset($data['error']['message']) ? 
                $data['error']['message'] : 
                'HTTP ' . $response_code . ' error';
            
            return array('error' => $error_message);
        }
        
        return $data;
    }
    
    /**
     * Get available models
     */
    public function get_available_models() {
        $response = $this->make_request('models');
        
        if (isset($response['error'])) {
            return $response;
        }
        
        $models = array();
        foreach ($response['data'] as $model) {
            if (strpos($model['id'], 'gpt') !== false) {
                $models[] = array(
                    'id' => $model['id'],
                    'name' => $model['id'],
                    'owned_by' => $model['owned_by']
                );
            }
        }
        
        return $models;
    }
    
    /**
     * Calculate token count (approximate)
     */
    public function estimate_tokens($text) {
        // Rough estimation: 1 token ≈ 4 characters for English text
        return ceil(strlen($text) / 4);
    }
    
    /**
     * Get pricing for model
     */
    public function get_model_pricing($model) {
        $pricing = array(
            'gpt-3.5-turbo' => array(
                'input' => 0.0015,  // per 1K tokens
                'output' => 0.002   // per 1K tokens
            ),
            'gpt-4' => array(
                'input' => 0.03,    // per 1K tokens
                'output' => 0.06    // per 1K tokens
            ),
            'gpt-4-turbo' => array(
                'input' => 0.01,    // per 1K tokens
                'output' => 0.03    // per 1K tokens
            )
        );
        
        return isset($pricing[$model]) ? $pricing[$model] : $pricing['gpt-3.5-turbo'];
    }
    
    /**
     * Calculate cost for request
     */
    public function calculate_cost($model, $input_tokens, $output_tokens) {
        $pricing = $this->get_model_pricing($model);
        
        $input_cost = ($input_tokens / 1000) * $pricing['input'];
        $output_cost = ($output_tokens / 1000) * $pricing['output'];
        
        return $input_cost + $output_cost;
    }
}

