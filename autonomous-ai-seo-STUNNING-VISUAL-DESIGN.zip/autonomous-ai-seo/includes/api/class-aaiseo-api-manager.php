<?php
/**
 * API Manager Class
 * 
 * @package Autonomous_AI_SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * API management class
 */
class AAISEO_API_Manager {
    
    /**
     * API endpoints
     */
    private $endpoints = array();
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('rest_api_init', array($this, 'register_api_routes'));
        add_action('wp_ajax_aaiseo_test_api', array($this, 'test_api_connection'));
    }
    
    /**
     * Register REST API routes
     */
    public function register_api_routes() {
        // SEO Analysis endpoint
        register_rest_route('aaiseo/v1', '/analyze', array(
            'methods' => 'POST',
            'callback' => array($this, 'analyze_content'),
            'permission_callback' => array($this, 'check_permissions'),
            'args' => array(
                'content' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_textarea_field'
                ),
                'keyword' => array(
                    'required' => false,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field'
                )
            )
        ));
        
        // Keyword Research endpoint
        register_rest_route('aaiseo/v1', '/keywords', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_keyword_suggestions'),
            'permission_callback' => array($this, 'check_permissions'),
            'args' => array(
                'seed' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_text_field'
                ),
                'limit' => array(
                    'required' => false,
                    'type' => 'integer',
                    'default' => 50
                )
            )
        ));
        
        // Competitor Analysis endpoint
        register_rest_route('aaiseo/v1', '/competitors', array(
            'methods' => 'POST',
            'callback' => array($this, 'analyze_competitors'),
            'permission_callback' => array($this, 'check_permissions'),
            'args' => array(
                'domain' => array(
                    'required' => true,
                    'type' => 'string',
                    'sanitize_callback' => 'sanitize_url'
                ),
                'keywords' => array(
                    'required' => false,
                    'type' => 'array'
                )
            )
        ));
        
        // Performance Metrics endpoint
        register_rest_route('aaiseo/v1', '/metrics', array(
            'methods' => 'GET',
            'callback' => array($this, 'get_performance_metrics'),
            'permission_callback' => array($this, 'check_permissions'),
            'args' => array(
                'period' => array(
                    'required' => false,
                    'type' => 'string',
                    'default' => '30d'
                )
            )
        ));
    }
    
    /**
     * Check API permissions
     */
    public function check_permissions() {
        return current_user_can('manage_options');
    }
    
    /**
     * Analyze content via API
     */
    public function analyze_content($request) {
        $content = $request->get_param('content');
        $keyword = $request->get_param('keyword');
        
        // Initialize SEO analyzer
        $analyzer = new AAISEO_SEO_Analyzer();
        
        // Perform analysis
        $analysis = $analyzer->analyze_content($content, $keyword);
        
        return rest_ensure_response($analysis);
    }
    
    /**
     * Get keyword suggestions via API
     */
    public function get_keyword_suggestions($request) {
        $seed = $request->get_param('seed');
        $limit = $request->get_param('limit');
        
        // Initialize keyword research
        $keyword_research = new AAISEO_Keyword_Research();
        
        // Get suggestions
        $suggestions = $keyword_research->get_keyword_suggestions($seed, $limit);
        
        return rest_ensure_response($suggestions);
    }
    
    /**
     * Analyze competitors via API
     */
    public function analyze_competitors($request) {
        $domain = $request->get_param('domain');
        $keywords = $request->get_param('keywords');
        
        // Initialize competitor intelligence
        $competitor_intel = new AAISEO_Competitive_Intelligence();
        
        // Perform analysis
        $analysis = $competitor_intel->analyze_competitor($domain, $keywords);
        
        return rest_ensure_response($analysis);
    }
    
    /**
     * Get performance metrics via API
     */
    public function get_performance_metrics($request) {
        $period = $request->get_param('period');
        
        // Initialize analytics
        $analytics = new AAISEO_Analytics();
        
        // Get metrics
        $metrics = $analytics->get_performance_metrics($period);
        
        return rest_ensure_response($metrics);
    }
    
    /**
     * Test API connection
     */
    public function test_api_connection() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'aaiseo_api_nonce')) {
            wp_die('Security check failed');
        }
        
        $api_type = sanitize_text_field($_POST['api_type']);
        $api_key = sanitize_text_field($_POST['api_key']);
        
        $result = array('success' => false, 'message' => '');
        
        switch ($api_type) {
            case 'openai':
                $result = $this->test_openai_connection($api_key);
                break;
            case 'google':
                $result = $this->test_google_connection($api_key);
                break;
            default:
                $result['message'] = 'Unknown API type';
        }
        
        wp_send_json($result);
    }
    
    /**
     * Test OpenAI API connection
     */
    private function test_openai_connection($api_key) {
        $openai = new AAISEO_OpenAI_API($api_key);
        return $openai->test_connection();
    }
    
    /**
     * Test Google API connection
     */
    private function test_google_connection($api_key) {
        $google = new AAISEO_Google_API($api_key);
        return $google->test_connection();
    }
    
    /**
     * Get API usage statistics
     */
    public function get_api_usage() {
        global $wpdb;
        
        $table = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'api_usage';
        
        $usage = $wpdb->get_results("
            SELECT api_service, 
                   COUNT(*) as requests,
                   SUM(tokens_used) as total_tokens,
                   DATE(created_at) as date
            FROM $table 
            WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            GROUP BY api_service, DATE(created_at)
            ORDER BY date DESC
        ");
        
        return $usage;
    }
    
    /**
     * Log API usage
     */
    public function log_api_usage($service, $endpoint, $tokens_used = 0, $cost = 0) {
        global $wpdb;
        
        $table = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'api_usage';
        
        $wpdb->insert(
            $table,
            array(
                'api_service' => $service,
                'endpoint' => $endpoint,
                'tokens_used' => $tokens_used,
                'cost' => $cost,
                'created_at' => current_time('mysql')
            ),
            array('%s', '%s', '%d', '%f', '%s')
        );
    }
    
    /**
     * Get API rate limits
     */
    public function get_rate_limits($service) {
        $limits = array(
            'openai' => array(
                'requests_per_minute' => 60,
                'tokens_per_minute' => 90000,
                'requests_per_day' => 1000
            ),
            'google' => array(
                'requests_per_minute' => 100,
                'requests_per_day' => 10000
            )
        );
        
        return isset($limits[$service]) ? $limits[$service] : array();
    }
    
    /**
     * Check rate limit
     */
    public function check_rate_limit($service) {
        global $wpdb;
        
        $table = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'api_usage';
        $limits = $this->get_rate_limits($service);
        
        if (empty($limits)) {
            return true;
        }
        
        // Check requests per minute
        if (isset($limits['requests_per_minute'])) {
            $recent_requests = $wpdb->get_var($wpdb->prepare("
                SELECT COUNT(*) 
                FROM $table 
                WHERE api_service = %s 
                AND created_at >= DATE_SUB(NOW(), INTERVAL 1 MINUTE)
            ", $service));
            
            if ($recent_requests >= $limits['requests_per_minute']) {
                return false;
            }
        }
        
        // Check requests per day
        if (isset($limits['requests_per_day'])) {
            $daily_requests = $wpdb->get_var($wpdb->prepare("
                SELECT COUNT(*) 
                FROM $table 
                WHERE api_service = %s 
                AND DATE(created_at) = CURDATE()
            ", $service));
            
            if ($daily_requests >= $limits['requests_per_day']) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Handle API errors
     */
    public function handle_api_error($service, $error_code, $error_message) {
        // Log the error
        error_log("AAISEO API Error - Service: $service, Code: $error_code, Message: $error_message");
        
        // Store error for admin notification
        $errors = get_option('aaiseo_api_errors', array());
        $errors[] = array(
            'service' => $service,
            'code' => $error_code,
            'message' => $error_message,
            'timestamp' => current_time('mysql')
        );
        
        // Keep only last 50 errors
        if (count($errors) > 50) {
            $errors = array_slice($errors, -50);
        }
        
        update_option('aaiseo_api_errors', $errors);
        
        // Return standardized error response
        return array(
            'success' => false,
            'error_code' => $error_code,
            'error_message' => $error_message,
            'service' => $service
        );
    }
}

