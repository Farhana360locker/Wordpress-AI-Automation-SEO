<?php
/**
 * Advanced Schema Generator for Autonomous AI SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Schema_Generator {
    
    /**
     * Schema types and their properties
     */
    private $schema_types = array();
    
    /**
     * Current page schema data
     */
    private $page_schema = array();
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize schema generator
     */
    public function init() {
        // Initialize schema types
        $this->init_schema_types();
        
        // Hook into WordPress
        add_action('wp_head', array($this, 'output_schema'), 5);
        add_action('save_post', array($this, 'generate_post_schema'), 10, 2);
        
        // Admin hooks
        add_action('add_meta_boxes', array($this, 'add_schema_meta_box'));
        add_action('wp_ajax_aaiseo_generate_schema', array($this, 'ajax_generate_schema'));
        add_action('wp_ajax_aaiseo_validate_schema', array($this, 'ajax_validate_schema'));
    }
    
    /**
     * Initialize schema types
     */
    private function init_schema_types() {
        $this->schema_types = array(
            'Article' => array(
                'required' => array('headline', 'author', 'datePublished'),
                'recommended' => array('image', 'dateModified', 'publisher', 'mainEntityOfPage'),
                'properties' => array(
                    'headline' => 'text',
                    'author' => 'Person',
                    'datePublished' => 'date',
                    'dateModified' => 'date',
                    'image' => 'ImageObject',
                    'publisher' => 'Organization',
                    'mainEntityOfPage' => 'WebPage',
                    'articleBody' => 'text',
                    'wordCount' => 'number',
                    'articleSection' => 'text',
                    'keywords' => 'text'
                )
            ),
            'Product' => array(
                'required' => array('name', 'image', 'description'),
                'recommended' => array('brand', 'offers', 'aggregateRating', 'review'),
                'properties' => array(
                    'name' => 'text',
                    'image' => 'ImageObject',
                    'description' => 'text',
                    'brand' => 'Brand',
                    'offers' => 'Offer',
                    'aggregateRating' => 'AggregateRating',
                    'review' => 'Review',
                    'sku' => 'text',
                    'mpn' => 'text',
                    'gtin' => 'text',
                    'category' => 'text',
                    'color' => 'text',
                    'material' => 'text',
                    'weight' => 'QuantitativeValue'
                )
            ),
            'LocalBusiness' => array(
                'required' => array('name', 'address', 'telephone'),
                'recommended' => array('image', 'url', 'openingHours', 'aggregateRating'),
                'properties' => array(
                    'name' => 'text',
                    'address' => 'PostalAddress',
                    'telephone' => 'text',
                    'image' => 'ImageObject',
                    'url' => 'url',
                    'openingHours' => 'text',
                    'aggregateRating' => 'AggregateRating',
                    'priceRange' => 'text',
                    'geo' => 'GeoCoordinates',
                    'email' => 'email',
                    'sameAs' => 'url'
                )
            ),
            'Recipe' => array(
                'required' => array('name', 'image', 'author', 'datePublished', 'description', 'recipeIngredient', 'recipeInstructions'),
                'recommended' => array('aggregateRating', 'review', 'nutrition', 'prepTime', 'cookTime'),
                'properties' => array(
                    'name' => 'text',
                    'image' => 'ImageObject',
                    'author' => 'Person',
                    'datePublished' => 'date',
                    'description' => 'text',
                    'recipeIngredient' => 'array',
                    'recipeInstructions' => 'array',
                    'aggregateRating' => 'AggregateRating',
                    'review' => 'Review',
                    'nutrition' => 'NutritionInformation',
                    'prepTime' => 'duration',
                    'cookTime' => 'duration',
                    'totalTime' => 'duration',
                    'recipeYield' => 'text',
                    'recipeCategory' => 'text',
                    'recipeCuisine' => 'text',
                    'keywords' => 'text'
                )
            ),
            'Event' => array(
                'required' => array('name', 'startDate', 'location'),
                'recommended' => array('image', 'description', 'endDate', 'offers'),
                'properties' => array(
                    'name' => 'text',
                    'startDate' => 'datetime',
                    'location' => 'Place',
                    'image' => 'ImageObject',
                    'description' => 'text',
                    'endDate' => 'datetime',
                    'offers' => 'Offer',
                    'performer' => 'Person',
                    'organizer' => 'Organization',
                    'url' => 'url',
                    'eventStatus' => 'text',
                    'eventAttendanceMode' => 'text'
                )
            ),
            'FAQ' => array(
                'required' => array('mainEntity'),
                'recommended' => array(),
                'properties' => array(
                    'mainEntity' => 'Question'
                )
            ),
            'HowTo' => array(
                'required' => array('name', 'step'),
                'recommended' => array('image', 'description', 'totalTime', 'estimatedCost', 'supply', 'tool'),
                'properties' => array(
                    'name' => 'text',
                    'step' => 'HowToStep',
                    'image' => 'ImageObject',
                    'description' => 'text',
                    'totalTime' => 'duration',
                    'estimatedCost' => 'MonetaryAmount',
                    'supply' => 'HowToSupply',
                    'tool' => 'HowToTool',
                    'yield' => 'text'
                )
            ),
            'Course' => array(
                'required' => array('name', 'description', 'provider'),
                'recommended' => array('aggregateRating', 'offers', 'hasCourseInstance'),
                'properties' => array(
                    'name' => 'text',
                    'description' => 'text',
                    'provider' => 'Organization',
                    'aggregateRating' => 'AggregateRating',
                    'offers' => 'Offer',
                    'hasCourseInstance' => 'CourseInstance',
                    'courseCode' => 'text',
                    'educationalLevel' => 'text',
                    'teaches' => 'text'
                )
            ),
            'JobPosting' => array(
                'required' => array('title', 'description', 'hiringOrganization', 'jobLocation', 'datePosted'),
                'recommended' => array('validThrough', 'employmentType', 'baseSalary'),
                'properties' => array(
                    'title' => 'text',
                    'description' => 'text',
                    'hiringOrganization' => 'Organization',
                    'jobLocation' => 'Place',
                    'datePosted' => 'date',
                    'validThrough' => 'date',
                    'employmentType' => 'text',
                    'baseSalary' => 'MonetaryAmount',
                    'qualifications' => 'text',
                    'responsibilities' => 'text',
                    'skills' => 'text',
                    'workHours' => 'text'
                )
            )
        );
        
        // Allow filtering of schema types
        $this->schema_types = apply_filters('aaiseo_schema_types', $this->schema_types);
    }
    
    /**
     * Generate schema for current page
     */
    public function generate_page_schema() {
        global $post;
        
        $schema = array();
        
        // Always include Organization schema
        $schema[] = $this->generate_organization_schema();
        
        // Always include WebSite schema
        $schema[] = $this->generate_website_schema();
        
        if (is_singular()) {
            // Generate post-specific schema
            $post_schema = $this->generate_post_schema($post->ID, $post);
            if ($post_schema) {
                $schema[] = $post_schema;
            }
            
            // Generate breadcrumb schema
            $breadcrumb_schema = $this->generate_breadcrumb_schema();
            if ($breadcrumb_schema) {
                $schema[] = $breadcrumb_schema;
            }
        } elseif (is_home() || is_front_page()) {
            // Generate homepage schema
            $schema[] = $this->generate_homepage_schema();
        } elseif (is_category() || is_tag() || is_tax()) {
            // Generate taxonomy schema
            $schema[] = $this->generate_taxonomy_schema();
        } elseif (is_author()) {
            // Generate author schema
            $schema[] = $this->generate_author_schema();
        }
        
        // Filter schema before output
        $schema = apply_filters('aaiseo_page_schema', $schema);
        
        return array_filter($schema);
    }
    
    /**
     * Generate Organization schema
     */
    private function generate_organization_schema() {
        $site_name = get_bloginfo('name');
        $site_url = home_url();
        $site_description = get_bloginfo('description');
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Organization',
            'name' => $site_name,
            'url' => $site_url,
            'description' => $site_description,
            'logo' => array(
                '@type' => 'ImageObject',
                'url' => $this->get_site_logo()
            )
        );
        
        // Add social media profiles
        $social_profiles = $this->get_social_profiles();
        if (!empty($social_profiles)) {
            $schema['sameAs'] = $social_profiles;
        }
        
        // Add contact information
        $contact_info = $this->get_contact_information();
        if (!empty($contact_info)) {
            $schema = array_merge($schema, $contact_info);
        }
        
        return $schema;
    }
    
    /**
     * Generate WebSite schema
     */
    private function generate_website_schema() {
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'WebSite',
            'name' => get_bloginfo('name'),
            'url' => home_url(),
            'description' => get_bloginfo('description'),
            'inLanguage' => get_locale(),
            'publisher' => array(
                '@type' => 'Organization',
                'name' => get_bloginfo('name'),
                'url' => home_url()
            )
        );
        
        // Add search action if search is enabled
        if (get_option('blog_public')) {
            $schema['potentialAction'] = array(
                '@type' => 'SearchAction',
                'target' => array(
                    '@type' => 'EntryPoint',
                    'urlTemplate' => home_url('/?s={search_term_string}')
                ),
                'query-input' => 'required name=search_term_string'
            );
        }
        
        return $schema;
    }
    
    /**
     * Generate post schema
     */
    public function generate_post_schema($post_id, $post = null) {
        if (!$post) {
            $post = get_post($post_id);
        }
        
        if (!$post) {
            return null;
        }
        
        // Determine schema type based on post type and content
        $schema_type = $this->determine_schema_type($post);
        
        switch ($schema_type) {
            case 'Article':
                return $this->generate_article_schema($post);
            case 'Product':
                return $this->generate_product_schema($post);
            case 'Recipe':
                return $this->generate_recipe_schema($post);
            case 'Event':
                return $this->generate_event_schema($post);
            case 'FAQ':
                return $this->generate_faq_schema($post);
            case 'HowTo':
                return $this->generate_howto_schema($post);
            case 'Course':
                return $this->generate_course_schema($post);
            case 'JobPosting':
                return $this->generate_job_posting_schema($post);
            default:
                return $this->generate_article_schema($post);
        }
    }
    
    /**
     * Determine schema type for post
     */
    private function determine_schema_type($post) {
        // Check for custom schema type meta
        $custom_type = get_post_meta($post->ID, '_aaiseo_schema_type', true);
        if ($custom_type && isset($this->schema_types[$custom_type])) {
            return $custom_type;
        }
        
        // Auto-detect based on post type
        switch ($post->post_type) {
            case 'product':
                return 'Product';
            case 'event':
                return 'Event';
            case 'recipe':
                return 'Recipe';
            case 'course':
                return 'Course';
            case 'job':
                return 'JobPosting';
            default:
                // Auto-detect based on content
                return $this->auto_detect_schema_type($post);
        }
    }
    
    /**
     * Auto-detect schema type based on content
     */
    private function auto_detect_schema_type($post) {
        $content = strtolower($post->post_content . ' ' . $post->post_title);
        
        // Recipe indicators
        if (preg_match('/\b(recipe|ingredient|cooking|baking|preparation|serves|prep time|cook time)\b/', $content)) {
            return 'Recipe';
        }
        
        // FAQ indicators
        if (preg_match('/\b(faq|frequently asked|questions|q&a)\b/', $content) || 
            preg_match_all('/\?/', $post->post_content) >= 3) {
            return 'FAQ';
        }
        
        // How-to indicators
        if (preg_match('/\b(how to|step by step|tutorial|guide|instructions)\b/', $content)) {
            return 'HowTo';
        }
        
        // Event indicators
        if (preg_match('/\b(event|conference|workshop|seminar|meeting|date|time|location)\b/', $content)) {
            return 'Event';
        }
        
        // Product indicators
        if (preg_match('/\b(price|buy|purchase|product|sale|discount|\$\d+)\b/', $content)) {
            return 'Product';
        }
        
        // Default to Article
        return 'Article';
    }
    
    /**
     * Generate Article schema
     */
    private function generate_article_schema($post) {
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Article',
            'headline' => $post->post_title,
            'description' => $this->get_post_description($post),
            'author' => $this->get_author_schema($post->post_author),
            'publisher' => $this->get_publisher_schema(),
            'datePublished' => get_the_date('c', $post),
            'dateModified' => get_the_modified_date('c', $post),
            'mainEntityOfPage' => array(
                '@type' => 'WebPage',
                '@id' => get_permalink($post)
            ),
            'url' => get_permalink($post),
            'articleBody' => wp_strip_all_tags($post->post_content),
            'wordCount' => str_word_count(wp_strip_all_tags($post->post_content))
        );
        
        // Add featured image
        $featured_image = $this->get_featured_image_schema($post);
        if ($featured_image) {
            $schema['image'] = $featured_image;
        }
        
        // Add article section (category)
        $categories = get_the_category($post->ID);
        if (!empty($categories)) {
            $schema['articleSection'] = $categories[0]->name;
        }
        
        // Add keywords (tags)
        $tags = get_the_tags($post->ID);
        if (!empty($tags)) {
            $keywords = array();
            foreach ($tags as $tag) {
                $keywords[] = $tag->name;
            }
            $schema['keywords'] = implode(', ', $keywords);
        }
        
        return $schema;
    }
    
    /**
     * Generate Product schema
     */
    private function generate_product_schema($post) {
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'Product',
            'name' => $post->post_title,
            'description' => $this->get_post_description($post),
            'url' => get_permalink($post)
        );
        
        // Add featured image
        $featured_image = $this->get_featured_image_schema($post);
        if ($featured_image) {
            $schema['image'] = $featured_image;
        }
        
        // Add product-specific meta data
        $price = get_post_meta($post->ID, '_price', true);
        $currency = get_post_meta($post->ID, '_currency', true) ?: 'USD';
        $availability = get_post_meta($post->ID, '_availability', true) ?: 'InStock';
        
        if ($price) {
            $schema['offers'] = array(
                '@type' => 'Offer',
                'price' => $price,
                'priceCurrency' => $currency,
                'availability' => 'https://schema.org/' . $availability,
                'url' => get_permalink($post)
            );
        }
        
        // Add brand
        $brand = get_post_meta($post->ID, '_brand', true);
        if ($brand) {
            $schema['brand'] = array(
                '@type' => 'Brand',
                'name' => $brand
            );
        }
        
        // Add SKU
        $sku = get_post_meta($post->ID, '_sku', true);
        if ($sku) {
            $schema['sku'] = $sku;
        }
        
        return $schema;
    }
    
    /**
     * Generate FAQ schema
     */
    private function generate_faq_schema($post) {
        $content = $post->post_content;
        $questions = $this->extract_faq_questions($content);
        
        if (empty($questions)) {
            return null;
        }
        
        $schema = array(
            '@context' => 'https://schema.org',
            '@type' => 'FAQPage',
            'mainEntity' => array()
        );
        
        foreach ($questions as $qa) {
            $schema['mainEntity'][] = array(
                '@type' => 'Question',
                'name' => $qa['question'],
                'acceptedAnswer' => array(
                    '@type' => 'Answer',
                    'text' => $qa['answer']
                )
            );
        }
        
        return $schema;
    }
    
    /**
     * Extract FAQ questions from content
     */
    private function extract_faq_questions($content) {
        $questions = array();
        
        // Pattern 1: H3/H4 headings followed by content
        preg_match_all('/<h[3-4][^>]*>(.*?)<\/h[3-4]>(.*?)(?=<h[3-4]|$)/is', $content, $matches, PREG_SET_ORDER);
        
        foreach ($matches as $match) {
            $question = wp_strip_all_tags($match[1]);
            $answer = wp_strip_all_tags($match[2]);
            
            if (strlen($question) > 10 && strlen($answer) > 20) {
                $questions[] = array(
                    'question' => trim($question),
                    'answer' => trim($answer)
                );
            }
        }
        
        // Pattern 2: Question/Answer blocks
        preg_match_all('/(?:Q:|Question:)\s*(.*?)\s*(?:A:|Answer:)\s*(.*?)(?=(?:Q:|Question:)|$)/is', $content, $matches, PREG_SET_ORDER);
        
        foreach ($matches as $match) {
            $question = wp_strip_all_tags($match[1]);
            $answer = wp_strip_all_tags($match[2]);
            
            if (strlen($question) > 10 && strlen($answer) > 20) {
                $questions[] = array(
                    'question' => trim($question),
                    'answer' => trim($answer)
                );
            }
        }
        
        return array_slice($questions, 0, 10); // Limit to 10 questions
    }
    
    /**
     * Get author schema
     */
    private function get_author_schema($author_id) {
        $author = get_userdata($author_id);
        
        if (!$author) {
            return null;
        }
        
        $schema = array(
            '@type' => 'Person',
            'name' => $author->display_name,
            'url' => get_author_posts_url($author_id)
        );
        
        // Add author description
        $description = get_user_meta($author_id, 'description', true);
        if ($description) {
            $schema['description'] = $description;
        }
        
        // Add author image
        $avatar_url = get_avatar_url($author_id, array('size' => 200));
        if ($avatar_url) {
            $schema['image'] = array(
                '@type' => 'ImageObject',
                'url' => $avatar_url
            );
        }
        
        return $schema;
    }
    
    /**
     * Get publisher schema
     */
    private function get_publisher_schema() {
        return array(
            '@type' => 'Organization',
            'name' => get_bloginfo('name'),
            'url' => home_url(),
            'logo' => array(
                '@type' => 'ImageObject',
                'url' => $this->get_site_logo()
            )
        );
    }
    
    /**
     * Get featured image schema
     */
    private function get_featured_image_schema($post) {
        $image_id = get_post_thumbnail_id($post);
        
        if (!$image_id) {
            return null;
        }
        
        $image_url = wp_get_attachment_image_url($image_id, 'full');
        $image_meta = wp_get_attachment_metadata($image_id);
        
        $schema = array(
            '@type' => 'ImageObject',
            'url' => $image_url
        );
        
        if (isset($image_meta['width']) && isset($image_meta['height'])) {
            $schema['width'] = $image_meta['width'];
            $schema['height'] = $image_meta['height'];
        }
        
        return $schema;
    }
    
    /**
     * Get site logo URL
     */
    private function get_site_logo() {
        $custom_logo_id = get_theme_mod('custom_logo');
        
        if ($custom_logo_id) {
            return wp_get_attachment_image_url($custom_logo_id, 'full');
        }
        
        // Fallback to site icon
        $site_icon_url = get_site_icon_url();
        if ($site_icon_url) {
            return $site_icon_url;
        }
        
        // Default fallback
        return AAISEO_PLUGIN_URL . 'assets/images/default-logo.png';
    }
    
    /**
     * Get social profiles
     */
    private function get_social_profiles() {
        $profiles = array();
        
        $social_options = array(
            'facebook_url',
            'twitter_url',
            'instagram_url',
            'linkedin_url',
            'youtube_url',
            'pinterest_url'
        );
        
        foreach ($social_options as $option) {
            $url = get_option('aaiseo_' . $option);
            if ($url) {
                $profiles[] = $url;
            }
        }
        
        return $profiles;
    }
    
    /**
     * Get contact information
     */
    private function get_contact_information() {
        $contact = array();
        
        $email = get_option('aaiseo_contact_email');
        if ($email) {
            $contact['email'] = $email;
        }
        
        $phone = get_option('aaiseo_contact_phone');
        if ($phone) {
            $contact['telephone'] = $phone;
        }
        
        $address = get_option('aaiseo_contact_address');
        if ($address) {
            $contact['address'] = array(
                '@type' => 'PostalAddress',
                'streetAddress' => $address
            );
        }
        
        return $contact;
    }
    
    /**
     * Get post description
     */
    private function get_post_description($post) {
        // Try meta description first
        $meta_desc = get_post_meta($post->ID, '_yoast_wpseo_metadesc', true);
        if ($meta_desc) {
            return $meta_desc;
        }
        
        // Try excerpt
        if ($post->post_excerpt) {
            return $post->post_excerpt;
        }
        
        // Generate from content
        $content = wp_strip_all_tags($post->post_content);
        return wp_trim_words($content, 30);
    }
    
    /**
     * Output schema markup
     */
    public function output_schema() {
        $schema = $this->generate_page_schema();
        
        if (empty($schema)) {
            return;
        }
        
        echo '<script type="application/ld+json">' . "\n";
        echo wp_json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT);
        echo "\n" . '</script>' . "\n";
    }
    
    /**
     * Add schema meta box
     */
    public function add_schema_meta_box() {
        add_meta_box(
            'aaiseo_schema',
            __('Schema Markup', 'autonomous-ai-seo'),
            array($this, 'render_schema_meta_box'),
            array('post', 'page'),
            'side',
            'default'
        );
    }
    
    /**
     * Render schema meta box
     */
    public function render_schema_meta_box($post) {
        $current_type = get_post_meta($post->ID, '_aaiseo_schema_type', true);
        $auto_detected = $this->determine_schema_type($post);
        
        wp_nonce_field('aaiseo_schema_nonce', 'aaiseo_schema_nonce');
        
        echo '<p><label for="aaiseo_schema_type">' . __('Schema Type:', 'autonomous-ai-seo') . '</label></p>';
        echo '<select name="aaiseo_schema_type" id="aaiseo_schema_type">';
        echo '<option value="">' . sprintf(__('Auto-detect (%s)', 'autonomous-ai-seo'), $auto_detected) . '</option>';
        
        foreach ($this->schema_types as $type => $config) {
            $selected = selected($current_type, $type, false);
            echo '<option value="' . esc_attr($type) . '"' . $selected . '>' . esc_html($type) . '</option>';
        }
        
        echo '</select>';
        
        echo '<p><button type="button" class="button" id="aaiseo-preview-schema">' . __('Preview Schema', 'autonomous-ai-seo') . '</button></p>';
        echo '<div id="aaiseo-schema-preview"></div>';
    }
    
    /**
     * AJAX: Generate schema
     */
    public function ajax_generate_schema() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        $post_id = intval($_POST['post_id']);
        $schema = $this->generate_post_schema($post_id);
        
        wp_send_json_success($schema);
    }
    
    /**
     * AJAX: Validate schema
     */
    public function ajax_validate_schema() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        $schema = json_decode(stripslashes($_POST['schema']), true);
        $validation_result = $this->validate_schema($schema);
        
        wp_send_json_success($validation_result);
    }
    
    /**
     * Validate schema markup
     */
    private function validate_schema($schema) {
        $errors = array();
        $warnings = array();
        
        if (!isset($schema['@type'])) {
            $errors[] = __('Missing @type property', 'autonomous-ai-seo');
            return array('errors' => $errors, 'warnings' => $warnings);
        }
        
        $type = $schema['@type'];
        
        if (!isset($this->schema_types[$type])) {
            $warnings[] = sprintf(__('Unknown schema type: %s', 'autonomous-ai-seo'), $type);
            return array('errors' => $errors, 'warnings' => $warnings);
        }
        
        $type_config = $this->schema_types[$type];
        
        // Check required properties
        foreach ($type_config['required'] as $required_prop) {
            if (!isset($schema[$required_prop]) || empty($schema[$required_prop])) {
                $errors[] = sprintf(__('Missing required property: %s', 'autonomous-ai-seo'), $required_prop);
            }
        }
        
        // Check recommended properties
        foreach ($type_config['recommended'] as $recommended_prop) {
            if (!isset($schema[$recommended_prop]) || empty($schema[$recommended_prop])) {
                $warnings[] = sprintf(__('Missing recommended property: %s', 'autonomous-ai-seo'), $recommended_prop);
            }
        }
        
        return array(
            'errors' => $errors,
            'warnings' => $warnings,
            'valid' => empty($errors)
        );
    }
}

