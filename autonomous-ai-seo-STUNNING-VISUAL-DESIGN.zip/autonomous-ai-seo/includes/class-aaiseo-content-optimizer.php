<?php
/**
 * Content Optimizer for Autonomous AI SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Content_Optimizer {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize content optimizer
     */
    public function init() {
        // Hook into post save for automatic optimization
        add_action('save_post', array($this, 'optimize_content_on_save'), 20, 2);
        
        // Add meta boxes for content optimization
        add_action('add_meta_boxes', array($this, 'add_content_optimization_meta_box'));
        
        // AJAX handlers
        add_action('wp_ajax_aaiseo_optimize_content', array($this, 'ajax_optimize_content'));
        add_action('wp_ajax_aaiseo_get_content_suggestions', array($this, 'ajax_get_content_suggestions'));
    }
    
    /**
     * Get optimization status
     */
    public function getOptimizationStatus($post_id = 0) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_content_optimization';
        
        if ($post_id > 0) {
            $optimizations = $wpdb->get_results($wpdb->prepare("
                SELECT * FROM $table 
                WHERE post_id = %d 
                ORDER BY created_at DESC 
                LIMIT 10
            ", $post_id));
        } else {
            $optimizations = $wpdb->get_results("
                SELECT co.*, p.post_title 
                FROM $table co
                LEFT JOIN {$wpdb->posts} p ON co.post_id = p.ID
                ORDER BY co.created_at DESC 
                LIMIT 20
            ");
        }
        
        $status = array(
            'total_optimizations' => count($optimizations),
            'pending_optimizations' => 0,
            'completed_optimizations' => 0,
            'recent_optimizations' => array(),
            'optimization_score' => $this->calculate_optimization_score($post_id)
        );
        
        foreach ($optimizations as $optimization) {
            if ($optimization->status === 'pending') {
                $status['pending_optimizations']++;
            } elseif ($optimization->status === 'completed') {
                $status['completed_optimizations']++;
            }
            
            $status['recent_optimizations'][] = array(
                'id' => $optimization->id,
                'post_id' => $optimization->post_id,
                'post_title' => isset($optimization->post_title) ? $optimization->post_title : get_the_title($optimization->post_id),
                'optimization_type' => $optimization->optimization_type,
                'status' => $optimization->status,
                'created_at' => $optimization->created_at,
                'ai_suggestions' => maybe_unserialize($optimization->ai_suggestions)
            );
        }
        
        return $status;
    }
    
    /**
     * Get recent optimizations
     */
    public function getRecentOptimizations($limit = 10) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_content_optimization';
        
        $optimizations = $wpdb->get_results($wpdb->prepare("
            SELECT co.*, p.post_title 
            FROM $table co
            LEFT JOIN {$wpdb->posts} p ON co.post_id = p.ID
            WHERE co.created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            ORDER BY co.created_at DESC 
            LIMIT %d
        ", $limit));
        
        $recent = array();
        foreach ($optimizations as $optimization) {
            $recent[] = array(
                'id' => $optimization->id,
                'post_id' => $optimization->post_id,
                'post_title' => $optimization->post_title,
                'optimization_type' => $optimization->optimization_type,
                'status' => $optimization->status,
                'created_at' => $optimization->created_at,
                'time_ago' => human_time_diff(strtotime($optimization->created_at), current_time('timestamp'))
            );
        }
        
        return $recent;
    }
    
    /**
     * Get content strategy data
     */
    public function getContentStrategy() {
        return array(
            'content_performance' => $this->get_content_performance_stats(),
            'content_calendar' => $this->generate_content_calendar(),
            'content_analysis' => $this->get_content_analysis(),
            'trending_topics' => $this->get_trending_topics(),
            'content_gaps' => $this->identify_content_gaps()
        );
    }
    
    /**
     * Optimize content automatically on save
     */
    public function optimize_content_on_save($post_id, $post) {
        // Skip for revisions and autosaves
        if (wp_is_post_revision($post_id) || wp_is_post_autosave($post_id)) {
            return;
        }
        
        // Skip if auto-optimization is disabled
        if (!get_option('aaiseo_auto_optimize')) {
            return;
        }
        
        // Only optimize published posts and pages
        if ($post->post_status !== 'publish' || !in_array($post->post_type, array('post', 'page'))) {
            return;
        }
        
        // Run optimization
        $this->optimize_post_content($post_id);
    }
    
    /**
     * Optimize specific post content
     */
    public function optimize_post_content($post_id) {
        $post = get_post($post_id);
        if (!$post) {
            return false;
        }
        
        // Get AI engine for content analysis
        $ai_engine = new AAISEO_AI_Engine();
        
        // Analyze content
        $analysis = $ai_engine->analyze_content($post->post_content, $post->post_title);
        
        if (isset($analysis['error'])) {
            return false;
        }
        
        // Generate optimized content suggestions
        $suggestions = $this->generate_optimization_suggestions($post, $analysis);
        
        // Store optimization record
        $this->store_optimization_record($post_id, 'ai_content_optimization', $suggestions);
        
        // Apply automatic optimizations if enabled
        if (get_option('aaiseo_auto_apply_optimizations')) {
            $this->apply_optimizations($post_id, $suggestions);
        }
        
        return true;
    }
    
    /**
     * Generate optimization suggestions
     */
    private function generate_optimization_suggestions($post, $analysis) {
        $suggestions = array(
            'meta_title' => $this->suggest_meta_title($post, $analysis),
            'meta_description' => $this->suggest_meta_description($post, $analysis),
            'content_improvements' => $this->suggest_content_improvements($post, $analysis),
            'keyword_optimization' => $this->suggest_keyword_optimization($post, $analysis),
            'readability_improvements' => $this->suggest_readability_improvements($post, $analysis),
            'structure_improvements' => $this->suggest_structure_improvements($post, $analysis)
        );
        
        return $suggestions;
    }
    
    /**
     * Suggest meta title optimization
     */
    private function suggest_meta_title($post, $analysis) {
        $ai_engine = new AAISEO_AI_Engine();
        $optimized_title = $ai_engine->generate_seo_title($post->post_content, $post->post_title);
        
        return array(
            'current' => $post->post_title,
            'suggested' => $optimized_title,
            'reason' => __('AI-optimized title for better search visibility', 'autonomous-ai-seo'),
            'priority' => 'high'
        );
    }
    
    /**
     * Suggest meta description optimization
     */
    private function suggest_meta_description($post, $analysis) {
        $ai_engine = new AAISEO_AI_Engine();
        $current_meta = get_post_meta($post->ID, '_yoast_wpseo_metadesc', true);
        $optimized_meta = $ai_engine->generate_meta_description($post->post_content, $post->post_title);
        
        return array(
            'current' => $current_meta,
            'suggested' => $optimized_meta,
            'reason' => __('AI-generated meta description to improve click-through rates', 'autonomous-ai-seo'),
            'priority' => 'high'
        );
    }
    
    /**
     * Suggest content improvements
     */
    private function suggest_content_improvements($post, $analysis) {
        $improvements = array();
        
        if (isset($analysis['content_gaps']) && !empty($analysis['content_gaps'])) {
            foreach ($analysis['content_gaps'] as $gap) {
                $improvements[] = array(
                    'type' => 'content_gap',
                    'suggestion' => sprintf(__('Add content about: %s', 'autonomous-ai-seo'), $gap),
                    'priority' => 'medium'
                );
            }
        }
        
        if (isset($analysis['recommendations']) && !empty($analysis['recommendations'])) {
            foreach ($analysis['recommendations'] as $recommendation) {
                $improvements[] = array(
                    'type' => 'ai_recommendation',
                    'suggestion' => $recommendation,
                    'priority' => 'medium'
                );
            }
        }
        
        return $improvements;
    }
    
    /**
     * Suggest keyword optimization
     */
    private function suggest_keyword_optimization($post, $analysis) {
        $suggestions = array();
        
        if (isset($analysis['keyword_suggestions']) && !empty($analysis['keyword_suggestions'])) {
            foreach ($analysis['keyword_suggestions'] as $keyword) {
                $suggestions[] = array(
                    'keyword' => $keyword,
                    'suggestion' => sprintf(__('Consider targeting keyword: %s', 'autonomous-ai-seo'), $keyword),
                    'priority' => 'medium'
                );
            }
        }
        
        return $suggestions;
    }
    
    /**
     * Suggest readability improvements
     */
    private function suggest_readability_improvements($post, $analysis) {
        $ai_engine = new AAISEO_AI_Engine();
        $readability = $ai_engine->calculate_readability_score($post->post_content);
        
        $suggestions = array();
        
        if ($readability['score'] < 60) {
            $suggestions[] = array(
                'type' => 'readability',
                'suggestion' => $readability['recommendation'],
                'current_score' => $readability['score'],
                'target_score' => 70,
                'priority' => 'high'
            );
        }
        
        return $suggestions;
    }
    
    /**
     * Suggest structure improvements
     */
    private function suggest_structure_improvements($post, $analysis) {
        $suggestions = array();
        
        // Check for heading structure
        $content = $post->post_content;
        $h1_count = substr_count($content, '<h1');
        $h2_count = substr_count($content, '<h2');
        
        if ($h1_count > 1) {
            $suggestions[] = array(
                'type' => 'heading_structure',
                'suggestion' => __('Use only one H1 tag per page', 'autonomous-ai-seo'),
                'priority' => 'high'
            );
        }
        
        if ($h2_count === 0 && strlen(strip_tags($content)) > 500) {
            $suggestions[] = array(
                'type' => 'heading_structure',
                'suggestion' => __('Add H2 headings to break up long content', 'autonomous-ai-seo'),
                'priority' => 'medium'
            );
        }
        
        return $suggestions;
    }
    
    /**
     * Store optimization record
     */
    private function store_optimization_record($post_id, $optimization_type, $suggestions) {
        global $wpdb;
        
        $table = $wpdb->prefix . 'aaiseo_content_optimization';
        
        return $wpdb->insert(
            $table,
            array(
                'post_id' => $post_id,
                'optimization_type' => $optimization_type,
                'original_content' => get_post_field('post_content', $post_id),
                'optimized_content' => '', // Will be filled when optimizations are applied
                'ai_suggestions' => maybe_serialize($suggestions),
                'status' => 'pending'
            ),
            array('%d', '%s', '%s', '%s', '%s', '%s')
        );
    }
    
    /**
     * Apply optimizations
     */
    private function apply_optimizations($post_id, $suggestions) {
        // Apply meta title if suggested
        if (isset($suggestions['meta_title']['suggested']) && !empty($suggestions['meta_title']['suggested'])) {
            update_post_meta($post_id, '_aaiseo_optimized_title', $suggestions['meta_title']['suggested']);
        }
        
        // Apply meta description if suggested
        if (isset($suggestions['meta_description']['suggested']) && !empty($suggestions['meta_description']['suggested'])) {
            update_post_meta($post_id, '_aaiseo_optimized_meta_desc', $suggestions['meta_description']['suggested']);
        }
        
        // Mark optimization as completed
        global $wpdb;
        $table = $wpdb->prefix . 'aaiseo_content_optimization';
        
        $wpdb->update(
            $table,
            array('status' => 'completed'),
            array('post_id' => $post_id, 'status' => 'pending'),
            array('%s'),
            array('%d', '%s')
        );
    }
    
    /**
     * Calculate optimization score
     */
    private function calculate_optimization_score($post_id = 0) {
        global $wpdb;
        
        if ($post_id > 0) {
            // Score for specific post
            $core = new AAISEO_Core();
            $audit_results = $core->get_audit_results($post_id, 'ai_content_analysis');
            return !empty($audit_results) ? $audit_results[0]->score : 0;
        } else {
            // Overall optimization score
            $avg_score = $wpdb->get_var("
                SELECT AVG(score) 
                FROM {$wpdb->prefix}aaiseo_audit_results 
                WHERE audit_type = 'ai_content_analysis'
                AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)
            ");
            
            return $avg_score ? round($avg_score, 1) : 0;
        }
    }
    
    /**
     * Get content performance stats
     */
    private function get_content_performance_stats() {
        global $wpdb;
        
        $stats = array(
            'total_posts' => wp_count_posts('post')->publish,
            'optimized_posts' => 0,
            'avg_seo_score' => 0,
            'top_performing_posts' => array()
        );
        
        // Get optimized posts count
        $stats['optimized_posts'] = $wpdb->get_var("
            SELECT COUNT(DISTINCT post_id) 
            FROM {$wpdb->prefix}aaiseo_content_optimization 
            WHERE status = 'completed'
        ");
        
        // Get average SEO score
        $stats['avg_seo_score'] = $wpdb->get_var("
            SELECT AVG(score) 
            FROM {$wpdb->prefix}aaiseo_audit_results 
            WHERE audit_type = 'ai_content_analysis'
        ");
        
        $stats['avg_seo_score'] = $stats['avg_seo_score'] ? round($stats['avg_seo_score'], 1) : 0;
        
        return $stats;
    }
    
    /**
     * Generate content calendar
     */
    private function generate_content_calendar() {
        // Mock content calendar for the next 30 days
        $calendar = array();
        $topics = array(
            'SEO Best Practices',
            'Content Marketing Strategies',
            'Technical SEO Guide',
            'Keyword Research Tips',
            'Link Building Techniques'
        );
        
        for ($i = 1; $i <= 30; $i++) {
            $date = date('Y-m-d', strtotime("+$i days"));
            $calendar[] = array(
                'date' => $date,
                'topic' => $topics[array_rand($topics)],
                'type' => rand(0, 1) ? 'blog_post' : 'guide',
                'priority' => array('high', 'medium', 'low')[rand(0, 2)],
                'estimated_words' => rand(800, 2000)
            );
        }
        
        return array_slice($calendar, 0, 10); // Return next 10 items
    }
    
    /**
     * Get content analysis
     */
    private function get_content_analysis() {
        global $wpdb;
        
        // Get recent posts with their SEO scores
        $posts = $wpdb->get_results("
            SELECT p.ID, p.post_title, p.post_date, ar.score
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->prefix}aaiseo_audit_results ar ON p.ID = ar.post_id AND ar.audit_type = 'ai_content_analysis'
            WHERE p.post_status = 'publish' 
            AND p.post_type = 'post'
            ORDER BY p.post_date DESC
            LIMIT 20
        ");
        
        $analysis = array();
        foreach ($posts as $post) {
            $analysis[] = array(
                'id' => $post->ID,
                'title' => $post->post_title,
                'date' => $post->post_date,
                'seo_score' => $post->score ? intval($post->score) : 0,
                'status' => $post->score >= 80 ? 'excellent' : ($post->score >= 60 ? 'good' : 'needs_improvement'),
                'url' => get_permalink($post->ID)
            );
        }
        
        return $analysis;
    }
    
    /**
     * Get trending topics
     */
    private function get_trending_topics() {
        return array(
            array(
                'topic' => 'AI in SEO',
                'trend' => 'rising',
                'search_volume' => 2400,
                'competition' => 'medium',
                'opportunity_score' => 85
            ),
            array(
                'topic' => 'Core Web Vitals',
                'trend' => 'stable',
                'search_volume' => 1800,
                'competition' => 'high',
                'opportunity_score' => 70
            ),
            array(
                'topic' => 'Voice Search Optimization',
                'trend' => 'rising',
                'search_volume' => 1200,
                'competition' => 'low',
                'opportunity_score' => 92
            )
        );
    }
    
    /**
     * Identify content gaps
     */
    private function identify_content_gaps() {
        return array(
            array(
                'gap' => 'Mobile SEO Best Practices',
                'opportunity_score' => 88,
                'search_volume' => 1500,
                'competition' => 'medium',
                'content_type' => 'comprehensive_guide'
            ),
            array(
                'gap' => 'Local SEO for Small Business',
                'opportunity_score' => 92,
                'search_volume' => 2200,
                'competition' => 'low',
                'content_type' => 'step_by_step_guide'
            ),
            array(
                'gap' => 'Schema Markup Implementation',
                'opportunity_score' => 78,
                'search_volume' => 800,
                'competition' => 'high',
                'content_type' => 'technical_tutorial'
            )
        );
    }
    
    /**
     * Add content optimization meta box
     */
    public function add_content_optimization_meta_box() {
        add_meta_box(
            'aaiseo_content_optimization',
            __('AI SEO Optimization', 'autonomous-ai-seo'),
            array($this, 'render_content_optimization_meta_box'),
            array('post', 'page'),
            'side',
            'high'
        );
    }
    
    /**
     * Render content optimization meta box
     */
    public function render_content_optimization_meta_box($post) {
        $optimization_status = $this->getOptimizationStatus($post->ID);
        
        echo '<div class="aaiseo-meta-box">';
        echo '<p><strong>' . __('SEO Score:', 'autonomous-ai-seo') . '</strong> ' . $optimization_status['optimization_score'] . '/100</p>';
        echo '<button type="button" class="button" id="aaiseo-optimize-content" data-post-id="' . $post->ID . '">';
        echo __('Optimize Content', 'autonomous-ai-seo');
        echo '</button>';
        echo '</div>';
    }
    
    /**
     * AJAX handler for content optimization
     */
    public function ajax_optimize_content() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_die(__('Insufficient permissions', 'autonomous-ai-seo'));
        }
        
        $post_id = intval($_POST['post_id']);
        
        $result = $this->optimize_post_content($post_id);
        
        if ($result) {
            wp_send_json_success(array(
                'message' => __('Content optimization completed', 'autonomous-ai-seo')
            ));
        } else {
            wp_send_json_error(array(
                'message' => __('Content optimization failed', 'autonomous-ai-seo')
            ));
        }
    }
    
    /**
     * AJAX handler for getting content suggestions
     */
    public function ajax_get_content_suggestions() {
        check_ajax_referer('aaiseo_nonce', 'nonce');
        
        if (!current_user_can('edit_posts')) {
            wp_die(__('Insufficient permissions', 'autonomous-ai-seo'));
        }
        
        $post_id = intval($_POST['post_id']);
        $optimization_status = $this->getOptimizationStatus($post_id);
        
        wp_send_json_success($optimization_status);
    }
    
    /**
     * Get optimization suggestions for content
     */
    public function get_optimization_suggestions($content, $focus_keyword) {
        $suggestions = array(
            'keyword_suggestions' => array(),
            'content_suggestions' => array(),
            'structure_suggestions' => array(),
            'readability_suggestions' => array(),
            'seo_score' => 0
        );
        
        // Analyze keyword usage
        $keyword_analysis = $this->analyze_keyword_usage($content, $focus_keyword);
        $suggestions['keyword_suggestions'] = $this->get_keyword_suggestions_from_analysis($keyword_analysis, $focus_keyword);
        
        // Analyze content structure
        $structure_analysis = $this->analyze_content_structure($content);
        $suggestions['structure_suggestions'] = $this->get_structure_suggestions_from_analysis($structure_analysis);
        
        // Analyze readability
        $readability_analysis = $this->analyze_readability($content);
        $suggestions['readability_suggestions'] = $this->get_readability_suggestions_from_analysis($readability_analysis);
        
        // Generate content suggestions
        $suggestions['content_suggestions'] = $this->generate_content_suggestions($content, $focus_keyword);
        
        // Calculate overall SEO score
        $suggestions['seo_score'] = $this->calculate_content_seo_score($content, $focus_keyword);
        
        return $suggestions;
    }
    
    /**
     * Auto optimize content
     */
    public function auto_optimize_content($content, $focus_keyword) {
        $optimized_content = $content;
        
        // Add focus keyword to first paragraph if missing
        if (!empty($focus_keyword) && stripos($content, $focus_keyword) === false) {
            $paragraphs = explode('</p>', $content);
            if (!empty($paragraphs[0])) {
                $first_paragraph = $paragraphs[0];
                if (stripos($first_paragraph, $focus_keyword) === false) {
                    // Add keyword naturally to first paragraph
                    $first_paragraph = str_replace('</p>', '', $first_paragraph);
                    $sentences = explode('.', $first_paragraph);
                    if (count($sentences) > 1) {
                        $sentences[1] = ' ' . ucfirst($focus_keyword) . ' is an important topic that' . ltrim($sentences[1]);
                        $first_paragraph = implode('.', $sentences) . '</p>';
                        $paragraphs[0] = $first_paragraph;
                        $optimized_content = implode('</p>', $paragraphs);
                    }
                }
            }
        }
        
        // Optimize headings
        $optimized_content = $this->optimize_headings($optimized_content, $focus_keyword);
        
        // Add internal links
        $optimized_content = $this->add_internal_links($optimized_content);
        
        // Optimize images
        $optimized_content = $this->optimize_images($optimized_content, $focus_keyword);
        
        return $optimized_content;
    }
    
    /**
     * Analyze keyword usage in content
     */
    private function analyze_keyword_usage($content, $focus_keyword) {
        $analysis = array(
            'keyword_density' => 0,
            'keyword_count' => 0,
            'word_count' => 0,
            'in_title' => false,
            'in_first_paragraph' => false,
            'in_headings' => false,
            'in_alt_tags' => false
        );
        
        if (empty($focus_keyword)) {
            return $analysis;
        }
        
        $content_text = strip_tags($content);
        $analysis['word_count'] = str_word_count($content_text);
        $analysis['keyword_count'] = substr_count(strtolower($content_text), strtolower($focus_keyword));
        
        if ($analysis['word_count'] > 0) {
            $analysis['keyword_density'] = ($analysis['keyword_count'] / $analysis['word_count']) * 100;
        }
        
        // Check if keyword is in first paragraph
        $paragraphs = explode('</p>', $content);
        if (!empty($paragraphs[0])) {
            $analysis['in_first_paragraph'] = stripos($paragraphs[0], $focus_keyword) !== false;
        }
        
        // Check if keyword is in headings
        $analysis['in_headings'] = preg_match('/<h[1-6][^>]*>.*?' . preg_quote($focus_keyword, '/') . '.*?<\/h[1-6]>/i', $content);
        
        // Check if keyword is in alt tags
        $analysis['in_alt_tags'] = preg_match('/alt=["\'][^"\']*' . preg_quote($focus_keyword, '/') . '[^"\']*["\']/i', $content);
        
        return $analysis;
    }
    
    /**
     * Analyze content structure
     */
    private function analyze_content_structure($content) {
        $analysis = array(
            'heading_count' => 0,
            'paragraph_count' => 0,
            'image_count' => 0,
            'link_count' => 0,
            'list_count' => 0,
            'has_h1' => false,
            'has_h2' => false,
            'proper_heading_hierarchy' => true
        );
        
        // Count headings
        $analysis['heading_count'] = preg_match_all('/<h[1-6][^>]*>/i', $content);
        $analysis['has_h1'] = preg_match('/<h1[^>]*>/i', $content);
        $analysis['has_h2'] = preg_match('/<h2[^>]*>/i', $content);
        
        // Count other elements
        $analysis['paragraph_count'] = preg_match_all('/<p[^>]*>/i', $content);
        $analysis['image_count'] = preg_match_all('/<img[^>]*>/i', $content);
        $analysis['link_count'] = preg_match_all('/<a[^>]*>/i', $content);
        $analysis['list_count'] = preg_match_all('/<(ul|ol)[^>]*>/i', $content);
        
        return $analysis;
    }
    
    /**
     * Analyze readability
     */
    private function analyze_readability($content) {
        $text = strip_tags($content);
        $sentences = preg_split('/[.!?]+/', $text, -1, PREG_SPLIT_NO_EMPTY);
        $words = str_word_count($text);
        $syllables = $this->count_syllables($text);
        
        $analysis = array(
            'word_count' => $words,
            'sentence_count' => count($sentences),
            'syllable_count' => $syllables,
            'avg_words_per_sentence' => 0,
            'avg_syllables_per_word' => 0,
            'flesch_score' => 0,
            'reading_level' => 'Unknown'
        );
        
        if (count($sentences) > 0) {
            $analysis['avg_words_per_sentence'] = $words / count($sentences);
        }
        
        if ($words > 0) {
            $analysis['avg_syllables_per_word'] = $syllables / $words;
        }
        
        // Calculate Flesch Reading Ease Score
        if (count($sentences) > 0 && $words > 0) {
            $analysis['flesch_score'] = 206.835 - (1.015 * $analysis['avg_words_per_sentence']) - (84.6 * $analysis['avg_syllables_per_word']);
            $analysis['reading_level'] = $this->get_reading_level($analysis['flesch_score']);
        }
        
        return $analysis;
    }
    
    /**
     * Count syllables in text
     */
    private function count_syllables($text) {
        $words = str_word_count(strtolower($text), 1);
        $syllable_count = 0;
        
        foreach ($words as $word) {
            $syllable_count += $this->count_word_syllables($word);
        }
        
        return $syllable_count;
    }
    
    /**
     * Count syllables in a single word
     */
    private function count_word_syllables($word) {
        $word = strtolower($word);
        $syllables = 0;
        $vowels = array('a', 'e', 'i', 'o', 'u', 'y');
        $previous_was_vowel = false;
        
        for ($i = 0; $i < strlen($word); $i++) {
            $is_vowel = in_array($word[$i], $vowels);
            if ($is_vowel && !$previous_was_vowel) {
                $syllables++;
            }
            $previous_was_vowel = $is_vowel;
        }
        
        // Handle silent e
        if (substr($word, -1) === 'e' && $syllables > 1) {
            $syllables--;
        }
        
        return max(1, $syllables);
    }
    
    /**
     * Get reading level from Flesch score
     */
    private function get_reading_level($score) {
        if ($score >= 90) return 'Very Easy';
        if ($score >= 80) return 'Easy';
        if ($score >= 70) return 'Fairly Easy';
        if ($score >= 60) return 'Standard';
        if ($score >= 50) return 'Fairly Difficult';
        if ($score >= 30) return 'Difficult';
        return 'Very Difficult';
    }
    
    /**
     * Generate keyword suggestions from analysis
     */
    private function get_keyword_suggestions_from_analysis($analysis, $focus_keyword) {
        $suggestions = array();
        
        if ($analysis['keyword_density'] < 0.5) {
            $suggestions[] = array(
                'type' => 'warning',
                'message' => sprintf(__('Keyword density is too low (%.1f%%). Consider adding "%s" more naturally throughout your content.', 'autonomous-ai-seo'), $analysis['keyword_density'], $focus_keyword)
            );
        } elseif ($analysis['keyword_density'] > 3) {
            $suggestions[] = array(
                'type' => 'error',
                'message' => sprintf(__('Keyword density is too high (%.1f%%). Reduce usage of "%s" to avoid keyword stuffing.', 'autonomous-ai-seo'), $analysis['keyword_density'], $focus_keyword)
            );
        } else {
            $suggestions[] = array(
                'type' => 'success',
                'message' => sprintf(__('Good keyword density (%.1f%%) for "%s".', 'autonomous-ai-seo'), $analysis['keyword_density'], $focus_keyword)
            );
        }
        
        if (!$analysis['in_first_paragraph']) {
            $suggestions[] = array(
                'type' => 'warning',
                'message' => sprintf(__('Consider adding "%s" to your first paragraph for better SEO.', 'autonomous-ai-seo'), $focus_keyword)
            );
        }
        
        if (!$analysis['in_headings']) {
            $suggestions[] = array(
                'type' => 'warning',
                'message' => sprintf(__('Consider adding "%s" to at least one heading (H1, H2, etc.).', 'autonomous-ai-seo'), $focus_keyword)
            );
        }
        
        return $suggestions;
    }
    
    /**
     * Generate structure suggestions from analysis
     */
    private function get_structure_suggestions_from_analysis($analysis) {
        $suggestions = array();
        
        if ($analysis['heading_count'] < 2) {
            $suggestions[] = array(
                'type' => 'warning',
                'message' => __('Add more headings to improve content structure and readability.', 'autonomous-ai-seo')
            );
        }
        
        if (!$analysis['has_h2']) {
            $suggestions[] = array(
                'type' => 'warning',
                'message' => __('Consider adding H2 headings to break up your content.', 'autonomous-ai-seo')
            );
        }
        
        if ($analysis['paragraph_count'] < 3) {
            $suggestions[] = array(
                'type' => 'info',
                'message' => __('Consider breaking up long paragraphs for better readability.', 'autonomous-ai-seo')
            );
        }
        
        if ($analysis['image_count'] === 0) {
            $suggestions[] = array(
                'type' => 'info',
                'message' => __('Consider adding relevant images to make your content more engaging.', 'autonomous-ai-seo')
            );
        }
        
        return $suggestions;
    }
    
    /**
     * Generate readability suggestions from analysis
     */
    private function get_readability_suggestions_from_analysis($analysis) {
        $suggestions = array();
        
        if ($analysis['avg_words_per_sentence'] > 20) {
            $suggestions[] = array(
                'type' => 'warning',
                'message' => sprintf(__('Average sentence length is %.1f words. Consider shorter sentences for better readability.', 'autonomous-ai-seo'), $analysis['avg_words_per_sentence'])
            );
        }
        
        if ($analysis['flesch_score'] < 60) {
            $suggestions[] = array(
                'type' => 'warning',
                'message' => sprintf(__('Reading level is "%s" (Flesch score: %.1f). Consider simplifying your language.', 'autonomous-ai-seo'), $analysis['reading_level'], $analysis['flesch_score'])
            );
        } else {
            $suggestions[] = array(
                'type' => 'success',
                'message' => sprintf(__('Good readability level: "%s" (Flesch score: %.1f).', 'autonomous-ai-seo'), $analysis['reading_level'], $analysis['flesch_score'])
            );
        }
        
        return $suggestions;
    }
    
    /**
     * Generate content suggestions
     */
    private function generate_content_suggestions($content, $focus_keyword) {
        $suggestions = array();
        $word_count = str_word_count(strip_tags($content));
        
        if ($word_count < 300) {
            $suggestions[] = array(
                'type' => 'warning',
                'message' => sprintf(__('Content is only %d words. Consider expanding to at least 300 words for better SEO.', 'autonomous-ai-seo'), $word_count)
            );
        } elseif ($word_count > 2000) {
            $suggestions[] = array(
                'type' => 'info',
                'message' => sprintf(__('Content is %d words. Consider breaking into multiple pages or adding a table of contents.', 'autonomous-ai-seo'), $word_count)
            );
        }
        
        // Check for external links
        $external_links = preg_match_all('/<a[^>]+href=["\']https?:\/\/(?!' . preg_quote(home_url(), '/') . ')[^"\']+["\'][^>]*>/i', $content);
        if ($external_links === 0) {
            $suggestions[] = array(
                'type' => 'info',
                'message' => __('Consider adding relevant external links to authoritative sources.', 'autonomous-ai-seo')
            );
        }
        
        // Check for internal links
        $internal_links = preg_match_all('/<a[^>]+href=["\'][^"\']*' . preg_quote(home_url(), '/') . '[^"\']*["\'][^>]*>/i', $content);
        if ($internal_links === 0) {
            $suggestions[] = array(
                'type' => 'info',
                'message' => __('Consider adding internal links to related content on your site.', 'autonomous-ai-seo')
            );
        }
        
        return $suggestions;
    }
    
    /**
     * Calculate content SEO score
     */
    private function calculate_content_seo_score($content, $focus_keyword) {
        $score = 0;
        $max_score = 100;
        
        // Keyword analysis
        $keyword_analysis = $this->analyze_keyword_usage($content, $focus_keyword);
        if ($keyword_analysis['keyword_density'] >= 0.5 && $keyword_analysis['keyword_density'] <= 3) {
            $score += 20;
        }
        if ($keyword_analysis['in_first_paragraph']) {
            $score += 10;
        }
        if ($keyword_analysis['in_headings']) {
            $score += 10;
        }
        
        // Content structure
        $structure_analysis = $this->analyze_content_structure($content);
        if ($structure_analysis['heading_count'] >= 2) {
            $score += 15;
        }
        if ($structure_analysis['has_h2']) {
            $score += 10;
        }
        if ($structure_analysis['image_count'] > 0) {
            $score += 10;
        }
        
        // Readability
        $readability_analysis = $this->analyze_readability($content);
        if ($readability_analysis['flesch_score'] >= 60) {
            $score += 15;
        }
        
        // Content length
        if ($readability_analysis['word_count'] >= 300) {
            $score += 10;
        }
        
        return min($max_score, $score);
    }
    
    /**
     * Optimize headings
     */
    private function optimize_headings($content, $focus_keyword) {
        // Add focus keyword to H2 if not present
        if (!empty($focus_keyword) && !preg_match('/<h2[^>]*>.*?' . preg_quote($focus_keyword, '/') . '.*?<\/h2>/i', $content)) {
            $content = preg_replace('/<h2([^>]*)>([^<]+)<\/h2>/i', '<h2$1>$2 - ' . $focus_keyword . '</h2>', $content, 1);
        }
        
        return $content;
    }
    
    /**
     * Add internal links
     */
    private function add_internal_links($content) {
        // Get related posts
        $related_posts = get_posts(array(
            'numberposts' => 5,
            'post_status' => 'publish',
            'orderby' => 'rand'
        ));
        
        foreach ($related_posts as $post) {
            $post_title = get_the_title($post->ID);
            $post_url = get_permalink($post->ID);
            
            // Add link if title appears in content
            $content = preg_replace('/\b' . preg_quote($post_title, '/') . '\b/i', '<a href="' . $post_url . '">' . $post_title . '</a>', $content, 1);
        }
        
        return $content;
    }
    
    /**
     * Optimize images
     */
    private function optimize_images($content, $focus_keyword) {
        // Add alt text with focus keyword if missing
        if (!empty($focus_keyword)) {
            $content = preg_replace('/<img([^>]*?)(?:alt=["\'][^"\']*["\'])?([^>]*?)>/i', '<img$1 alt="' . esc_attr($focus_keyword) . ' related image"$2>', $content);
        }
        
        return $content;
    }
}

