<?php
/**
 * SEO Analyzer Class
 * Analyzes content and provides SEO scores and recommendations
 */

if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_SEO_Analyzer {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('wp_ajax_aaiseo_analyze_content', array($this, 'ajax_analyze_content'));
        add_action('wp_ajax_aaiseo_get_seo_score', array($this, 'ajax_get_seo_score'));
    }
    
    /**
     * Analyze content for SEO
     */
    public function analyze_content($post_id, $content = null, $focus_keyword = '') {
        if (!$content) {
            $post = get_post($post_id);
            $content = $post->post_content;
        }
        
        $analysis = array(
            'post_id' => $post_id,
            'focus_keyword' => $focus_keyword,
            'seo_score' => 0,
            'content_score' => 0,
            'technical_score' => 0,
            'analysis_data' => array(),
            'recommendations' => array(),
            'last_analyzed' => current_time('mysql')
        );
        
        // Analyze different aspects
        $analysis['analysis_data']['title'] = $this->analyze_title($post_id, $focus_keyword);
        $analysis['analysis_data']['meta_description'] = $this->analyze_meta_description($post_id, $focus_keyword);
        $analysis['analysis_data']['content'] = $this->analyze_content_quality($content, $focus_keyword);
        $analysis['analysis_data']['headings'] = $this->analyze_headings($content, $focus_keyword);
        $analysis['analysis_data']['images'] = $this->analyze_images($content);
        $analysis['analysis_data']['links'] = $this->analyze_links($content);
        $analysis['analysis_data']['readability'] = $this->analyze_readability($content);
        $analysis['analysis_data']['keyword_usage'] = $this->analyze_keyword_usage($content, $focus_keyword);
        
        // Calculate scores
        $analysis['seo_score'] = $this->calculate_seo_score($analysis['analysis_data']);
        $analysis['content_score'] = $this->calculate_content_score($analysis['analysis_data']);
        $analysis['technical_score'] = $this->calculate_technical_score($post_id);
        
        // Generate recommendations
        $analysis['recommendations'] = $this->generate_recommendations($analysis['analysis_data']);
        
        return $analysis;
    }
    
    /**
     * Analyze title
     */
    private function analyze_title($post_id, $focus_keyword) {
        $post = get_post($post_id);
        $title = $post->post_title;
        $meta_title = get_post_meta($post_id, '_aaiseo_meta_title', true);
        
        if ($meta_title) {
            $title = $meta_title;
        }
        
        $analysis = array(
            'title' => $title,
            'length' => strlen($title),
            'word_count' => str_word_count($title),
            'has_focus_keyword' => false,
            'keyword_position' => -1,
            'score' => 0
        );
        
        // Check if focus keyword is in title
        if (!empty($focus_keyword) && stripos($title, $focus_keyword) !== false) {
            $analysis['has_focus_keyword'] = true;
            $analysis['keyword_position'] = stripos($title, $focus_keyword);
        }
        
        // Score based on length (optimal: 50-60 characters)
        if ($analysis['length'] >= 50 && $analysis['length'] <= 60) {
            $analysis['score'] += 40;
        } elseif ($analysis['length'] >= 40 && $analysis['length'] <= 70) {
            $analysis['score'] += 30;
        } elseif ($analysis['length'] >= 30 && $analysis['length'] <= 80) {
            $analysis['score'] += 20;
        } else {
            $analysis['score'] += 10;
        }
        
        // Score for keyword presence
        if ($analysis['has_focus_keyword']) {
            $analysis['score'] += 40;
            
            // Bonus for keyword at beginning
            if ($analysis['keyword_position'] <= 10) {
                $analysis['score'] += 20;
            }
        }
        
        return $analysis;
    }
    
    /**
     * Analyze meta description
     */
    private function analyze_meta_description($post_id, $focus_keyword) {
        $meta_description = get_post_meta($post_id, '_aaiseo_meta_description', true);
        
        if (!$meta_description) {
            $post = get_post($post_id);
            $meta_description = wp_trim_words($post->post_excerpt ?: $post->post_content, 25);
        }
        
        $analysis = array(
            'description' => $meta_description,
            'length' => strlen($meta_description),
            'word_count' => str_word_count($meta_description),
            'has_focus_keyword' => false,
            'score' => 0
        );
        
        // Check if focus keyword is in description
        if (!empty($focus_keyword) && stripos($meta_description, $focus_keyword) !== false) {
            $analysis['has_focus_keyword'] = true;
        }
        
        // Score based on length (optimal: 150-160 characters)
        if ($analysis['length'] >= 150 && $analysis['length'] <= 160) {
            $analysis['score'] += 50;
        } elseif ($analysis['length'] >= 120 && $analysis['length'] <= 180) {
            $analysis['score'] += 40;
        } elseif ($analysis['length'] >= 100 && $analysis['length'] <= 200) {
            $analysis['score'] += 30;
        } else {
            $analysis['score'] += 10;
        }
        
        // Score for keyword presence
        if ($analysis['has_focus_keyword']) {
            $analysis['score'] += 50;
        }
        
        return $analysis;
    }
    
    /**
     * Analyze content quality
     */
    private function analyze_content_quality($content, $focus_keyword) {
        $text_content = wp_strip_all_tags($content);
        $word_count = str_word_count($text_content);
        $sentence_count = preg_split('/[.!?]+/', $text_content, -1, PREG_SPLIT_NO_EMPTY);
        $paragraph_count = substr_count($content, '</p>');
        
        $analysis = array(
            'word_count' => $word_count,
            'sentence_count' => count($sentence_count),
            'paragraph_count' => $paragraph_count,
            'avg_words_per_sentence' => $word_count / max(count($sentence_count), 1),
            'avg_sentences_per_paragraph' => count($sentence_count) / max($paragraph_count, 1),
            'has_focus_keyword' => false,
            'keyword_density' => 0,
            'score' => 0
        );
        
        // Check keyword usage
        if (!empty($focus_keyword)) {
            $keyword_count = substr_count(strtolower($text_content), strtolower($focus_keyword));
            $analysis['has_focus_keyword'] = $keyword_count > 0;
            $analysis['keyword_density'] = ($keyword_count / $word_count) * 100;
        }
        
        // Score based on word count
        if ($word_count >= 300 && $word_count <= 2000) {
            $analysis['score'] += 40;
        } elseif ($word_count >= 200 && $word_count <= 3000) {
            $analysis['score'] += 30;
        } elseif ($word_count >= 100) {
            $analysis['score'] += 20;
        } else {
            $analysis['score'] += 5;
        }
        
        // Score for keyword density (optimal: 0.5-2.5%)
        if ($analysis['keyword_density'] >= 0.5 && $analysis['keyword_density'] <= 2.5) {
            $analysis['score'] += 30;
        } elseif ($analysis['keyword_density'] > 0 && $analysis['keyword_density'] <= 4) {
            $analysis['score'] += 20;
        } elseif ($analysis['keyword_density'] > 0) {
            $analysis['score'] += 10;
        }
        
        // Score for readability
        if ($analysis['avg_words_per_sentence'] <= 20) {
            $analysis['score'] += 15;
        } elseif ($analysis['avg_words_per_sentence'] <= 25) {
            $analysis['score'] += 10;
        } else {
            $analysis['score'] += 5;
        }
        
        // Score for paragraph structure
        if ($analysis['avg_sentences_per_paragraph'] <= 4) {
            $analysis['score'] += 15;
        } elseif ($analysis['avg_sentences_per_paragraph'] <= 6) {
            $analysis['score'] += 10;
        } else {
            $analysis['score'] += 5;
        }
        
        return $analysis;
    }
    
    /**
     * Analyze headings
     */
    private function analyze_headings($content, $focus_keyword) {
        $headings = array();
        
        // Extract all headings
        preg_match_all('/<h([1-6])[^>]*>(.*?)<\/h[1-6]>/i', $content, $matches, PREG_SET_ORDER);
        
        foreach ($matches as $match) {
            $level = intval($match[1]);
            $text = wp_strip_all_tags($match[2]);
            
            $headings[] = array(
                'level' => $level,
                'text' => $text,
                'has_keyword' => !empty($focus_keyword) && stripos($text, $focus_keyword) !== false
            );
        }
        
        $analysis = array(
            'headings' => $headings,
            'total_count' => count($headings),
            'h1_count' => 0,
            'h2_count' => 0,
            'h3_count' => 0,
            'keyword_in_headings' => 0,
            'score' => 0
        );
        
        // Count heading levels and keyword usage
        foreach ($headings as $heading) {
            if ($heading['level'] == 1) $analysis['h1_count']++;
            if ($heading['level'] == 2) $analysis['h2_count']++;
            if ($heading['level'] == 3) $analysis['h3_count']++;
            
            if ($heading['has_keyword']) {
                $analysis['keyword_in_headings']++;
            }
        }
        
        // Score for proper heading structure
        if ($analysis['h1_count'] == 1) {
            $analysis['score'] += 25;
        } elseif ($analysis['h1_count'] == 0) {
            $analysis['score'] += 5;
        }
        
        if ($analysis['h2_count'] >= 1) {
            $analysis['score'] += 25;
        }
        
        if ($analysis['total_count'] >= 3) {
            $analysis['score'] += 25;
        } elseif ($analysis['total_count'] >= 1) {
            $analysis['score'] += 15;
        }
        
        // Score for keyword in headings
        if ($analysis['keyword_in_headings'] > 0) {
            $analysis['score'] += 25;
        }
        
        return $analysis;
    }
    
    /**
     * Analyze images
     */
    private function analyze_images($content) {
        preg_match_all('/<img[^>]+>/i', $content, $matches);
        $images = $matches[0];
        
        $analysis = array(
            'total_count' => count($images),
            'with_alt' => 0,
            'with_title' => 0,
            'optimized' => 0,
            'score' => 0
        );
        
        foreach ($images as $img) {
            if (preg_match('/alt=["\']([^"\']*)["\']/', $img, $alt_match)) {
                if (!empty(trim($alt_match[1]))) {
                    $analysis['with_alt']++;
                }
            }
            
            if (preg_match('/title=["\']([^"\']*)["\']/', $img, $title_match)) {
                if (!empty(trim($title_match[1]))) {
                    $analysis['with_title']++;
                }
            }
        }
        
        $analysis['optimized'] = $analysis['with_alt'];
        
        // Score for image optimization
        if ($analysis['total_count'] > 0) {
            $optimization_ratio = $analysis['optimized'] / $analysis['total_count'];
            
            if ($optimization_ratio >= 0.9) {
                $analysis['score'] += 50;
            } elseif ($optimization_ratio >= 0.7) {
                $analysis['score'] += 40;
            } elseif ($optimization_ratio >= 0.5) {
                $analysis['score'] += 30;
            } else {
                $analysis['score'] += 10;
            }
        } else {
            $analysis['score'] += 25; // No images is neutral
        }
        
        return $analysis;
    }
    
    /**
     * Analyze links
     */
    private function analyze_links($content) {
        preg_match_all('/<a[^>]+href=["\']([^"\']*)["\'][^>]*>(.*?)<\/a>/i', $content, $matches, PREG_SET_ORDER);
        
        $analysis = array(
            'total_count' => count($matches),
            'internal_count' => 0,
            'external_count' => 0,
            'nofollow_count' => 0,
            'score' => 0
        );
        
        $site_url = get_site_url();
        
        foreach ($matches as $match) {
            $url = $match[1];
            $link_html = $match[0];
            
            if (strpos($url, $site_url) !== false || strpos($url, '/') === 0) {
                $analysis['internal_count']++;
            } else {
                $analysis['external_count']++;
            }
            
            if (strpos($link_html, 'rel="nofollow"') !== false) {
                $analysis['nofollow_count']++;
            }
        }
        
        // Score for link usage
        if ($analysis['internal_count'] >= 2) {
            $analysis['score'] += 30;
        } elseif ($analysis['internal_count'] >= 1) {
            $analysis['score'] += 20;
        }
        
        if ($analysis['external_count'] >= 1 && $analysis['external_count'] <= 5) {
            $analysis['score'] += 20;
        } elseif ($analysis['external_count'] > 5) {
            $analysis['score'] += 10;
        }
        
        return $analysis;
    }
    
    /**
     * Analyze readability
     */
    private function analyze_readability($content) {
        $text = wp_strip_all_tags($content);
        $sentences = preg_split('/[.!?]+/', $text, -1, PREG_SPLIT_NO_EMPTY);
        $words = str_word_count($text, 1);
        $syllables = $this->count_syllables($text);
        
        $sentence_count = count($sentences);
        $word_count = count($words);
        $syllable_count = $syllables;
        
        // Flesch Reading Ease
        $flesch_score = 0;
        if ($sentence_count > 0 && $word_count > 0) {
            $flesch_score = 206.835 - (1.015 * ($word_count / $sentence_count)) - (84.6 * ($syllable_count / $word_count));
        }
        
        // Flesch-Kincaid Grade Level
        $fk_grade = 0;
        if ($sentence_count > 0 && $word_count > 0) {
            $fk_grade = (0.39 * ($word_count / $sentence_count)) + (11.8 * ($syllable_count / $word_count)) - 15.59;
        }
        
        $analysis = array(
            'flesch_reading_ease' => round($flesch_score, 2),
            'flesch_kincaid_grade' => round($fk_grade, 2),
            'avg_sentence_length' => $sentence_count > 0 ? round($word_count / $sentence_count, 2) : 0,
            'avg_syllables_per_word' => $word_count > 0 ? round($syllable_count / $word_count, 2) : 0,
            'score' => 0
        );
        
        // Score based on readability
        if ($flesch_score >= 60) {
            $analysis['score'] += 50;
        } elseif ($flesch_score >= 30) {
            $analysis['score'] += 30;
        } else {
            $analysis['score'] += 10;
        }
        
        return $analysis;
    }
    
    /**
     * Analyze keyword usage
     */
    private function analyze_keyword_usage($content, $focus_keyword) {
        if (empty($focus_keyword)) {
            return array(
                'keyword' => '',
                'density' => 0,
                'count' => 0,
                'in_first_paragraph' => false,
                'in_last_paragraph' => false,
                'score' => 0
            );
        }
        
        $text = wp_strip_all_tags($content);
        $word_count = str_word_count($text);
        $keyword_count = substr_count(strtolower($text), strtolower($focus_keyword));
        $density = $word_count > 0 ? ($keyword_count / $word_count) * 100 : 0;
        
        // Check first and last paragraphs
        $paragraphs = explode('</p>', $content);
        $first_paragraph = wp_strip_all_tags($paragraphs[0] ?? '');
        $last_paragraph = wp_strip_all_tags(end($paragraphs));
        
        $analysis = array(
            'keyword' => $focus_keyword,
            'density' => round($density, 2),
            'count' => $keyword_count,
            'in_first_paragraph' => stripos($first_paragraph, $focus_keyword) !== false,
            'in_last_paragraph' => stripos($last_paragraph, $focus_keyword) !== false,
            'score' => 0
        );
        
        // Score based on keyword density (optimal: 0.5-2.5%)
        if ($density >= 0.5 && $density <= 2.5) {
            $analysis['score'] += 40;
        } elseif ($density > 0 && $density <= 4) {
            $analysis['score'] += 25;
        } elseif ($density > 0) {
            $analysis['score'] += 10;
        }
        
        // Bonus for keyword in first paragraph
        if ($analysis['in_first_paragraph']) {
            $analysis['score'] += 30;
        }
        
        // Bonus for keyword in last paragraph
        if ($analysis['in_last_paragraph']) {
            $analysis['score'] += 30;
        }
        
        return $analysis;
    }
    
    /**
     * Calculate overall SEO score
     */
    private function calculate_seo_score($analysis_data) {
        $total_score = 0;
        $max_score = 0;
        
        // Weight different factors
        $weights = array(
            'title' => 0.20,
            'meta_description' => 0.15,
            'content' => 0.25,
            'headings' => 0.15,
            'images' => 0.10,
            'links' => 0.10,
            'keyword_usage' => 0.05
        );
        
        foreach ($weights as $factor => $weight) {
            if (isset($analysis_data[$factor]['score'])) {
                $total_score += $analysis_data[$factor]['score'] * $weight;
                $max_score += 100 * $weight;
            }
        }
        
        return $max_score > 0 ? round(($total_score / $max_score) * 100) : 0;
    }
    
    /**
     * Calculate content score
     */
    private function calculate_content_score($analysis_data) {
        $factors = array('content', 'readability', 'keyword_usage');
        $total_score = 0;
        $count = 0;
        
        foreach ($factors as $factor) {
            if (isset($analysis_data[$factor]['score'])) {
                $total_score += $analysis_data[$factor]['score'];
                $count++;
            }
        }
        
        return $count > 0 ? round($total_score / $count) : 0;
    }
    
    /**
     * Calculate technical score
     */
    private function calculate_technical_score($post_id) {
        // This would integrate with technical SEO analysis
        // For now, return a basic score
        return 75;
    }
    
    /**
     * Generate recommendations
     */
    private function generate_recommendations($analysis_data) {
        $recommendations = array();
        
        // Title recommendations
        if (isset($analysis_data['title'])) {
            $title = $analysis_data['title'];
            
            if ($title['length'] < 30) {
                $recommendations[] = array(
                    'type' => 'warning',
                    'category' => 'title',
                    'message' => 'Your title is too short. Consider making it longer for better SEO.',
                    'priority' => 'high'
                );
            } elseif ($title['length'] > 70) {
                $recommendations[] = array(
                    'type' => 'warning',
                    'category' => 'title',
                    'message' => 'Your title is too long and may be truncated in search results.',
                    'priority' => 'high'
                );
            }
            
            if (!$title['has_focus_keyword']) {
                $recommendations[] = array(
                    'type' => 'error',
                    'category' => 'title',
                    'message' => 'Include your focus keyword in the title for better SEO.',
                    'priority' => 'high'
                );
            }
        }
        
        // Meta description recommendations
        if (isset($analysis_data['meta_description'])) {
            $meta = $analysis_data['meta_description'];
            
            if ($meta['length'] < 120) {
                $recommendations[] = array(
                    'type' => 'warning',
                    'category' => 'meta_description',
                    'message' => 'Your meta description is too short. Consider making it longer.',
                    'priority' => 'medium'
                );
            } elseif ($meta['length'] > 200) {
                $recommendations[] = array(
                    'type' => 'warning',
                    'category' => 'meta_description',
                    'message' => 'Your meta description is too long and may be truncated.',
                    'priority' => 'medium'
                );
            }
            
            if (!$meta['has_focus_keyword']) {
                $recommendations[] = array(
                    'type' => 'warning',
                    'category' => 'meta_description',
                    'message' => 'Include your focus keyword in the meta description.',
                    'priority' => 'medium'
                );
            }
        }
        
        // Content recommendations
        if (isset($analysis_data['content'])) {
            $content = $analysis_data['content'];
            
            if ($content['word_count'] < 300) {
                $recommendations[] = array(
                    'type' => 'warning',
                    'category' => 'content',
                    'message' => 'Your content is quite short. Consider adding more valuable information.',
                    'priority' => 'medium'
                );
            }
            
            if ($content['keyword_density'] > 3) {
                $recommendations[] = array(
                    'type' => 'error',
                    'category' => 'content',
                    'message' => 'Your keyword density is too high. This might be seen as keyword stuffing.',
                    'priority' => 'high'
                );
            } elseif ($content['keyword_density'] < 0.5 && $content['keyword_density'] > 0) {
                $recommendations[] = array(
                    'type' => 'info',
                    'category' => 'content',
                    'message' => 'Consider using your focus keyword a bit more in the content.',
                    'priority' => 'low'
                );
            }
        }
        
        // Heading recommendations
        if (isset($analysis_data['headings'])) {
            $headings = $analysis_data['headings'];
            
            if ($headings['h1_count'] == 0) {
                $recommendations[] = array(
                    'type' => 'error',
                    'category' => 'headings',
                    'message' => 'Add an H1 heading to your content.',
                    'priority' => 'high'
                );
            } elseif ($headings['h1_count'] > 1) {
                $recommendations[] = array(
                    'type' => 'warning',
                    'category' => 'headings',
                    'message' => 'You have multiple H1 headings. Consider using only one H1 per page.',
                    'priority' => 'medium'
                );
            }
            
            if ($headings['h2_count'] == 0 && $headings['total_count'] > 1) {
                $recommendations[] = array(
                    'type' => 'info',
                    'category' => 'headings',
                    'message' => 'Consider adding H2 headings to improve content structure.',
                    'priority' => 'low'
                );
            }
            
            if ($headings['keyword_in_headings'] == 0) {
                $recommendations[] = array(
                    'type' => 'info',
                    'category' => 'headings',
                    'message' => 'Consider including your focus keyword in at least one heading.',
                    'priority' => 'low'
                );
            }
        }
        
        // Image recommendations
        if (isset($analysis_data['images'])) {
            $images = $analysis_data['images'];
            
            if ($images['total_count'] > 0 && $images['with_alt'] < $images['total_count']) {
                $missing_alt = $images['total_count'] - $images['with_alt'];
                $recommendations[] = array(
                    'type' => 'warning',
                    'category' => 'images',
                    'message' => "Add alt text to {$missing_alt} image(s) for better accessibility and SEO.",
                    'priority' => 'medium'
                );
            }
        }
        
        return $recommendations;
    }
    
    /**
     * Count syllables in text
     */
    private function count_syllables($text) {
        $words = str_word_count(strtolower($text), 1);
        $syllable_count = 0;
        
        foreach ($words as $word) {
            $syllable_count += $this->count_word_syllables($word);
        }
        
        return $syllable_count;
    }
    
    /**
     * Count syllables in a single word
     */
    private function count_word_syllables($word) {
        $word = strtolower($word);
        $vowels = 'aeiouy';
        $syllables = 0;
        $previous_was_vowel = false;
        
        for ($i = 0; $i < strlen($word); $i++) {
            $is_vowel = strpos($vowels, $word[$i]) !== false;
            
            if ($is_vowel && !$previous_was_vowel) {
                $syllables++;
            }
            
            $previous_was_vowel = $is_vowel;
        }
        
        // Handle silent e
        if (substr($word, -1) === 'e' && $syllables > 1) {
            $syllables--;
        }
        
        return max(1, $syllables);
    }
    
    /**
     * AJAX analyze content
     */
    public function ajax_analyze_content() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        $post_id = intval($_POST['post_id']);
        $content = wp_kses_post($_POST['content']);
        $focus_keyword = sanitize_text_field($_POST['focus_keyword']);
        
        if (!current_user_can('edit_post', $post_id)) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        $analysis = $this->analyze_content($post_id, $content, $focus_keyword);
        
        wp_send_json_success($analysis);
    }
    
    /**
     * AJAX get SEO score
     */
    public function ajax_get_seo_score() {
        check_ajax_referer('aaiseo_admin_nonce', 'nonce');
        
        $post_id = intval($_POST['post_id']);
        
        if (!current_user_can('edit_post', $post_id)) {
            wp_send_json_error(__('Unauthorized', 'autonomous-ai-seo'));
        }
        
        global $wpdb;
        $table_name = $wpdb->prefix . AAISEO_TABLE_PREFIX . 'seo_analysis';
        
        $analysis = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE post_id = %d",
            $post_id
        ));
        
        if ($analysis) {
            wp_send_json_success($analysis);
        } else {
            wp_send_json_error(__('No analysis found', 'autonomous-ai-seo'));
        }
    }
}

