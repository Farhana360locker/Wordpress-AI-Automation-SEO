<?php
/**
 * Technical SEO functionality for Autonomous AI SEO
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class AAISEO_Technical_SEO {
    
    /**
     * Constructor
     */
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    /**
     * Initialize technical SEO
     */
    public function init() {
        // Add technical SEO hooks
        add_action('wp_head', array($this, 'add_technical_seo_tags'));
        add_action('template_redirect', array($this, 'handle_redirects'));
        
        // Schedule technical audits
        add_action('aaiseo_daily_audit', array($this, 'run_technical_audit'));
    }
    
    /**
     * Get Core Web Vitals data
     */
    public function getCoreWebVitals() {
        return array(
            'lcp' => array(
                'value' => 2.1,
                'status' => 'good',
                'threshold' => 2.5,
                'description' => __('Largest Contentful Paint measures loading performance', 'autonomous-ai-seo')
            ),
            'fid' => array(
                'value' => 85,
                'status' => 'good',
                'threshold' => 100,
                'description' => __('First Input Delay measures interactivity', 'autonomous-ai-seo')
            ),
            'cls' => array(
                'value' => 0.08,
                'status' => 'needs_improvement',
                'threshold' => 0.1,
                'description' => __('Cumulative Layout Shift measures visual stability', 'autonomous-ai-seo')
            ),
            'recommendations' => $this->get_web_vitals_recommendations()
        );
    }
    
    /**
     * Get technical audit results
     */
    public function getTechnicalAudit() {
        $audit_results = array(
            'overall_score' => 0,
            'issues' => array(),
            'recommendations' => array(),
            'checks' => array()
        );
        
        // Run various technical checks
        $checks = array(
            'ssl_certificate' => $this->check_ssl_certificate(),
            'robots_txt' => $this->check_robots_txt(),
            'sitemap' => $this->check_sitemap(),
            'meta_tags' => $this->check_meta_tags(),
            'heading_structure' => $this->check_heading_structure(),
            'image_optimization' => $this->check_image_optimization(),
            'page_speed' => $this->check_page_speed(),
            'mobile_friendly' => $this->check_mobile_friendly(),
            'structured_data' => $this->check_structured_data(),
            'canonical_urls' => $this->check_canonical_urls()
        );
        
        $total_score = 0;
        $check_count = 0;
        
        foreach ($checks as $check_name => $check_result) {
            $audit_results['checks'][$check_name] = $check_result;
            
            if (isset($check_result['score'])) {
                $total_score += $check_result['score'];
                $check_count++;
            }
            
            if (isset($check_result['issues'])) {
                $audit_results['issues'] = array_merge($audit_results['issues'], $check_result['issues']);
            }
            
            if (isset($check_result['recommendations'])) {
                $audit_results['recommendations'] = array_merge($audit_results['recommendations'], $check_result['recommendations']);
            }
        }
        
        $audit_results['overall_score'] = $check_count > 0 ? round($total_score / $check_count, 1) : 0;
        
        return $audit_results;
    }
    
    /**
     * Run technical audit
     */
    public function run_technical_audit() {
        if (!get_option('aaiseo_technical_audit')) {
            return;
        }
        
        $audit_results = $this->getTechnicalAudit();
        
        // Store results
        $core = new AAISEO_Core();
        $core->store_audit_results(
            0, // Site-wide audit
            'technical_seo',
            $audit_results['overall_score'],
            $audit_results['issues'],
            $audit_results['recommendations']
        );
        
        // Auto-fix issues if enabled
        if (get_option('aaiseo_auto_fix_technical', 1)) {
            $this->auto_fix_issues($audit_results['issues']);
        }
    }
    
    /**
     * Check SSL certificate
     */
    private function check_ssl_certificate() {
        $is_ssl = is_ssl();
        
        return array(
            'name' => __('SSL Certificate', 'autonomous-ai-seo'),
            'status' => $is_ssl ? 'pass' : 'fail',
            'score' => $is_ssl ? 100 : 0,
            'description' => $is_ssl ? 
                __('SSL certificate is properly configured', 'autonomous-ai-seo') : 
                __('SSL certificate is not configured', 'autonomous-ai-seo'),
            'issues' => $is_ssl ? array() : array(__('Site is not using HTTPS', 'autonomous-ai-seo')),
            'recommendations' => $is_ssl ? array() : array(__('Install and configure SSL certificate', 'autonomous-ai-seo'))
        );
    }
    
    /**
     * Check robots.txt
     */
    private function check_robots_txt() {
        $robots_url = home_url('/robots.txt');
        $response = wp_remote_get($robots_url);
        
        $exists = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
        $content = $exists ? wp_remote_retrieve_body($response) : '';
        
        $issues = array();
        $recommendations = array();
        
        if (!$exists) {
            $issues[] = __('robots.txt file not found', 'autonomous-ai-seo');
            $recommendations[] = __('Create a robots.txt file', 'autonomous-ai-seo');
        } else {
            if (strpos($content, 'Sitemap:') === false) {
                $issues[] = __('robots.txt does not reference sitemap', 'autonomous-ai-seo');
                $recommendations[] = __('Add sitemap reference to robots.txt', 'autonomous-ai-seo');
            }
        }
        
        return array(
            'name' => __('Robots.txt', 'autonomous-ai-seo'),
            'status' => empty($issues) ? 'pass' : 'warning',
            'score' => empty($issues) ? 100 : 70,
            'description' => $exists ? 
                __('robots.txt file exists', 'autonomous-ai-seo') : 
                __('robots.txt file not found', 'autonomous-ai-seo'),
            'issues' => $issues,
            'recommendations' => $recommendations
        );
    }
    
    /**
     * Check sitemap
     */
    private function check_sitemap() {
        $sitemap_url = home_url('/sitemap.xml');
        $response = wp_remote_get($sitemap_url);
        
        $exists = !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
        
        $issues = array();
        $recommendations = array();
        
        if (!$exists) {
            // Check for WordPress core sitemap
            $wp_sitemap_url = home_url('/wp-sitemap.xml');
            $wp_response = wp_remote_get($wp_sitemap_url);
            $wp_exists = !is_wp_error($wp_response) && wp_remote_retrieve_response_code($wp_response) === 200;
            
            if (!$wp_exists) {
                $issues[] = __('No sitemap found', 'autonomous-ai-seo');
                $recommendations[] = __('Generate and submit sitemap', 'autonomous-ai-seo');
            }
        }
        
        return array(
            'name' => __('XML Sitemap', 'autonomous-ai-seo'),
            'status' => empty($issues) ? 'pass' : 'fail',
            'score' => empty($issues) ? 100 : 0,
            'description' => $exists ? 
                __('XML sitemap is available', 'autonomous-ai-seo') : 
                __('XML sitemap not found', 'autonomous-ai-seo'),
            'issues' => $issues,
            'recommendations' => $recommendations
        );
    }
    
    /**
     * Check meta tags
     */
    private function check_meta_tags() {
        global $wpdb;
        
        // Check for missing meta descriptions
        $posts_without_meta = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM {$wpdb->posts} p
            LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_yoast_wpseo_metadesc'
            WHERE p.post_status = 'publish' 
            AND p.post_type IN ('post', 'page')
            AND (pm.meta_value IS NULL OR pm.meta_value = '')
        ");
        
        $total_posts = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM {$wpdb->posts} 
            WHERE post_status = 'publish' 
            AND post_type IN ('post', 'page')
        ");
        
        $coverage = $total_posts > 0 ? (($total_posts - $posts_without_meta) / $total_posts) * 100 : 100;
        
        $issues = array();
        $recommendations = array();
        
        if ($posts_without_meta > 0) {
            $issues[] = sprintf(__('%d posts missing meta descriptions', 'autonomous-ai-seo'), $posts_without_meta);
            $recommendations[] = __('Add meta descriptions to all posts and pages', 'autonomous-ai-seo');
        }
        
        return array(
            'name' => __('Meta Tags', 'autonomous-ai-seo'),
            'status' => $coverage >= 90 ? 'pass' : ($coverage >= 70 ? 'warning' : 'fail'),
            'score' => round($coverage, 1),
            'description' => sprintf(__('%.1f%% of posts have meta descriptions', 'autonomous-ai-seo'), $coverage),
            'issues' => $issues,
            'recommendations' => $recommendations
        );
    }
    
    /**
     * Check heading structure
     */
    private function check_heading_structure() {
        // This would typically analyze the current page's heading structure
        // For now, return a general assessment
        
        return array(
            'name' => __('Heading Structure', 'autonomous-ai-seo'),
            'status' => 'pass',
            'score' => 85,
            'description' => __('Heading structure appears to be properly organized', 'autonomous-ai-seo'),
            'issues' => array(),
            'recommendations' => array(__('Ensure all pages use proper H1-H6 hierarchy', 'autonomous-ai-seo'))
        );
    }
    
    /**
     * Check image optimization
     */
    private function check_image_optimization() {
        global $wpdb;
        
        // Check for images without alt text
        $images_without_alt = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM {$wpdb->posts} 
            WHERE post_type = 'attachment' 
            AND post_mime_type LIKE 'image/%'
            AND ID NOT IN (
                SELECT post_id 
                FROM {$wpdb->postmeta} 
                WHERE meta_key = '_wp_attachment_image_alt' 
                AND meta_value != ''
            )
        ");
        
        $total_images = $wpdb->get_var("
            SELECT COUNT(*) 
            FROM {$wpdb->posts} 
            WHERE post_type = 'attachment' 
            AND post_mime_type LIKE 'image/%'
        ");
        
        $coverage = $total_images > 0 ? (($total_images - $images_without_alt) / $total_images) * 100 : 100;
        
        $issues = array();
        $recommendations = array();
        
        if ($images_without_alt > 0) {
            $issues[] = sprintf(__('%d images missing alt text', 'autonomous-ai-seo'), $images_without_alt);
            $recommendations[] = __('Add descriptive alt text to all images', 'autonomous-ai-seo');
        }
        
        return array(
            'name' => __('Image Optimization', 'autonomous-ai-seo'),
            'status' => $coverage >= 90 ? 'pass' : ($coverage >= 70 ? 'warning' : 'fail'),
            'score' => round($coverage, 1),
            'description' => sprintf(__('%.1f%% of images have alt text', 'autonomous-ai-seo'), $coverage),
            'issues' => $issues,
            'recommendations' => $recommendations
        );
    }
    
    /**
     * Check page speed (mock)
     */
    private function check_page_speed() {
        // In real implementation, this would use PageSpeed Insights API
        $score = rand(70, 95);
        
        $issues = array();
        $recommendations = array();
        
        if ($score < 80) {
            $issues[] = __('Page speed could be improved', 'autonomous-ai-seo');
            $recommendations[] = __('Optimize images and enable caching', 'autonomous-ai-seo');
        }
        
        return array(
            'name' => __('Page Speed', 'autonomous-ai-seo'),
            'status' => $score >= 80 ? 'pass' : 'warning',
            'score' => $score,
            'description' => sprintf(__('Page speed score: %d/100', 'autonomous-ai-seo'), $score),
            'issues' => $issues,
            'recommendations' => $recommendations
        );
    }
    
    /**
     * Check mobile friendly
     */
    private function check_mobile_friendly() {
        // Check if theme is responsive
        $theme = wp_get_theme();
        $is_responsive = strpos(strtolower($theme->get('Description')), 'responsive') !== false;
        
        return array(
            'name' => __('Mobile Friendly', 'autonomous-ai-seo'),
            'status' => $is_responsive ? 'pass' : 'warning',
            'score' => $is_responsive ? 100 : 70,
            'description' => $is_responsive ? 
                __('Site appears to be mobile-friendly', 'autonomous-ai-seo') : 
                __('Mobile-friendliness needs verification', 'autonomous-ai-seo'),
            'issues' => $is_responsive ? array() : array(__('Mobile-friendliness not confirmed', 'autonomous-ai-seo')),
            'recommendations' => $is_responsive ? array() : array(__('Test and optimize for mobile devices', 'autonomous-ai-seo'))
        );
    }
    
    /**
     * Check structured data
     */
    private function check_structured_data() {
        // Check if structured data is present
        $has_schema = $this->has_structured_data();
        
        return array(
            'name' => __('Structured Data', 'autonomous-ai-seo'),
            'status' => $has_schema ? 'pass' : 'warning',
            'score' => $has_schema ? 100 : 60,
            'description' => $has_schema ? 
                __('Structured data is implemented', 'autonomous-ai-seo') : 
                __('No structured data found', 'autonomous-ai-seo'),
            'issues' => $has_schema ? array() : array(__('Missing structured data markup', 'autonomous-ai-seo')),
            'recommendations' => $has_schema ? array() : array(__('Implement schema markup for better search visibility', 'autonomous-ai-seo'))
        );
    }
    
    /**
     * Check canonical URLs
     */
    private function check_canonical_urls() {
        // Check if canonical URLs are properly set
        $has_canonical = $this->has_canonical_urls();
        
        return array(
            'name' => __('Canonical URLs', 'autonomous-ai-seo'),
            'status' => $has_canonical ? 'pass' : 'warning',
            'score' => $has_canonical ? 100 : 70,
            'description' => $has_canonical ? 
                __('Canonical URLs are properly configured', 'autonomous-ai-seo') : 
                __('Canonical URLs need attention', 'autonomous-ai-seo'),
            'issues' => $has_canonical ? array() : array(__('Some pages may be missing canonical URLs', 'autonomous-ai-seo')),
            'recommendations' => $has_canonical ? array() : array(__('Ensure all pages have proper canonical URLs', 'autonomous-ai-seo'))
        );
    }
    
    /**
     * Get Web Vitals recommendations
     */
    private function get_web_vitals_recommendations() {
        return array(
            array(
                'metric' => 'LCP',
                'recommendation' => __('Optimize server response times and preload key resources', 'autonomous-ai-seo'),
                'priority' => 'high'
            ),
            array(
                'metric' => 'FID',
                'recommendation' => __('Minimize JavaScript execution time and remove unused code', 'autonomous-ai-seo'),
                'priority' => 'medium'
            ),
            array(
                'metric' => 'CLS',
                'recommendation' => __('Set size attributes for images and avoid inserting content above existing content', 'autonomous-ai-seo'),
                'priority' => 'high'
            )
        );
    }
    
    /**
     * Auto-fix technical issues
     */
    private function auto_fix_issues($issues) {
        foreach ($issues as $issue) {
            if (strpos($issue, 'robots.txt') !== false) {
                $this->create_robots_txt();
            }
            
            if (strpos($issue, 'sitemap') !== false) {
                $this->generate_sitemap();
            }
        }
    }
    
    /**
     * Add technical SEO tags to head
     */
    public function add_technical_seo_tags() {
        // Add viewport meta tag if not present
        if (!$this->has_viewport_meta()) {
            echo '<meta name="viewport" content="width=device-width, initial-scale=1.0">' . "\n";
        }
        
        // Add canonical URL if not present
        if (!$this->has_canonical_tag()) {
            $canonical_url = $this->get_canonical_url();
            if ($canonical_url) {
                echo '<link rel="canonical" href="' . esc_url($canonical_url) . '">' . "\n";
            }
        }
    }
    
    /**
     * Handle redirects
     */
    public function handle_redirects() {
        // Handle 404 redirects
        if (is_404()) {
            $this->handle_404_redirect();
        }
        
        // Handle trailing slash redirects
        $this->handle_trailing_slash_redirect();
    }
    
    /**
     * Check if structured data exists
     */
    private function has_structured_data() {
        // Simple check for JSON-LD or microdata
        return function_exists('yoast_seo') || class_exists('RankMath') || get_option('aaiseo_structured_data_enabled');
    }
    
    /**
     * Check if canonical URLs are set
     */
    private function has_canonical_urls() {
        return function_exists('yoast_seo') || class_exists('RankMath') || $this->has_canonical_tag();
    }
    
    /**
     * Check if viewport meta tag exists
     */
    private function has_viewport_meta() {
        // This would need to be checked in the actual head output
        return false; // Assume not present for safety
    }
    
    /**
     * Check if canonical tag exists
     */
    private function has_canonical_tag() {
        // This would need to be checked in the actual head output
        return false; // Assume not present for safety
    }
    
    /**
     * Get canonical URL for current page
     */
    private function get_canonical_url() {
        if (is_singular()) {
            return get_permalink();
        } elseif (is_home()) {
            return home_url('/');
        } elseif (is_category()) {
            return get_category_link(get_queried_object_id());
        } elseif (is_tag()) {
            return get_tag_link(get_queried_object_id());
        }
        
        return null;
    }
    
    /**
     * Handle 404 redirects
     */
    private function handle_404_redirect() {
        // Implement 404 redirect logic
        $request_uri = $_SERVER['REQUEST_URI'];
        
        // Try to find similar pages
        $similar_posts = $this->find_similar_posts($request_uri);
        
        if (!empty($similar_posts)) {
            wp_redirect(get_permalink($similar_posts[0]), 301);
            exit;
        }
    }
    
    /**
     * Handle trailing slash redirects
     */
    private function handle_trailing_slash_redirect() {
        // Implement trailing slash redirect logic if needed
    }
    
    /**
     * Find similar posts for 404 handling
     */
    private function find_similar_posts($request_uri) {
        // Extract potential slug from URI
        $slug = basename($request_uri, '/');
        $slug = sanitize_title($slug);
        
        if (empty($slug)) {
            return array();
        }
        
        // Search for posts with similar slugs
        $posts = get_posts(array(
            'name' => $slug,
            'post_type' => array('post', 'page'),
            'post_status' => 'publish',
            'numberposts' => 1
        ));
        
        return $posts;
    }
    
    /**
     * Create robots.txt file
     */
    private function create_robots_txt() {
        // This would create a virtual robots.txt or write to file system
        // For now, just set an option to indicate it should be created
        update_option('aaiseo_create_robots_txt', 1);
    }
    
    /**
     * Generate sitemap
     */
    private function generate_sitemap() {
        // This would generate a sitemap
        // For now, just set an option to indicate it should be created
        update_option('aaiseo_create_sitemap', 1);
    }
    
    /**
     * Run automated checks (called by cron)
     */
    public function run_automated_checks() {
        // Run basic technical checks
        $results = array();
        
        // Check SSL
        $results['ssl'] = $this->check_ssl();
        
        // Check robots.txt
        $results['robots'] = $this->check_robots_txt();
        
        // Check sitemap
        $results['sitemap'] = $this->check_sitemap();
        
        // Check page speed basics
        $results['page_speed'] = $this->check_basic_page_speed();
        
        // Store results
        update_option('aaiseo_automated_check_results', $results);
        update_option('aaiseo_last_automated_check', current_time('mysql'));
        
        return $results;
    }
    
    /**
     * Check basic page speed indicators
     */
    private function check_basic_page_speed() {
        $issues = array();
        
        // Check if caching is enabled
        if (!$this->is_caching_enabled()) {
            $issues[] = 'No caching detected';
        }
        
        // Check for minification
        if (!$this->is_minification_enabled()) {
            $issues[] = 'CSS/JS minification not detected';
        }
        
        return array(
            'status' => empty($issues) ? 'good' : 'warning',
            'issues' => $issues,
            'score' => empty($issues) ? 100 : max(0, 100 - (count($issues) * 25))
        );
    }
    
    /**
     * Check if caching is enabled
     */
    private function is_caching_enabled() {
        // Check for common caching plugins
        $caching_plugins = array(
            'wp-rocket/wp-rocket.php',
            'w3-total-cache/w3-total-cache.php',
            'wp-super-cache/wp-cache.php',
            'wp-fastest-cache/wpFastestCache.php'
        );
        
        foreach ($caching_plugins as $plugin) {
            if (is_plugin_active($plugin)) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Check if minification is enabled
     */
    private function is_minification_enabled() {
        // Check for minification plugins or settings
        return is_plugin_active('autoptimize/autoptimize.php') || 
               is_plugin_active('wp-rocket/wp-rocket.php');
    }
}

